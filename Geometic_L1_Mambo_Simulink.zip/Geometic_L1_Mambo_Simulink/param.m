% /*
% * Copyright 2010 University of Illinois Board of Trustees.
% * Licensed under the “Non-exclusive Research Use License for L1 Adaptive Control Software” license (the "License"); 
% * You may not use this file except in compliance with the License. 
% * The License is included in the distribution as License.txt file.
% 
% * Software distributed under the License is distributed on an "AS IS", 
% * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
% * See the License for the specific language governing permissions and limitations under the License. 
% */

addpath('tools')
% addpath('Please enter the address of the Vicon folder')

polytraj = csvread('fastbiggerflatfigure8.csv',1,0);


% physical parameters of airframe
gravity = 9.81;   % [m/s/s]
mass    = 0.085;  % [kg]   %was 0.077, 0.085 with kx 0.5, almost no steady state error.
Jxx     = 0.0000582857; % [kg-m2]
Jyy     = 0.0000716914; % [kg-m2]
Jzz     = 0.0001; % [kg-m2]
J       =[Jxx 0 0;0 Jyy 0;0 0 Jzz];


% initial conditions    

R0 = eye(3);
Ts =  0.005;

% Set of parameters with time delay margin 0.003
mass = 0.075;
m = mass;
kpx = 0.62;
kpy = 0.45;
kpz = 0.69;
kv = 0.1;
kvz = 0.15;
kRx = 0.0105;
kRy = 0.0105;
kRz = 0.002;
kwz = 0.0005;
kOmega = 0.0017;
kx = [kpx 0 0;0 kpy 0;0 0 kpz];
kv = [kv 0 0;0 kv 0;0 0 kvz];
kOmega = [kOmega 0 0;0 kOmega 0;0 0 kwz]*1.3;
kR = [0.015 0 0;0 0.015 0;0 0 0.002];




%% L1 Control Gains
kad = 1;
As = [-5*eye(3),zeros(3,3);zeros(3,3),[-10 -10 -10].*eye(3)];
phi = inv(As) * (expm(As*Ts*kad) - eye(6));
mu = expm(As*Ts*kad);
adaptationgain = inv(phi) * mu;









