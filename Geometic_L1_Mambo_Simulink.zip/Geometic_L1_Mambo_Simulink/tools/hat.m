function ss = hat(vec)

%vector to skew symmetric

switch length(vec)
    
    case 3
        ss = [
            0, -vec(3), vec(2);
            vec(3), 0, -vec(1);
            -vec(2), vec(1), 0];
        
    case 1
        ss = [
            0, vec; 
            -vec, 0];
end

end