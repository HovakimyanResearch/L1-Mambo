function vec = vee(ss)

%skew symmetric to vector

switch numel(ss)
    
    case 4
        
      
        vec = ss(1,2);

    case 9

     
        vec = [ss(3,2); ss(1,3); ss(2,1)];
end



end