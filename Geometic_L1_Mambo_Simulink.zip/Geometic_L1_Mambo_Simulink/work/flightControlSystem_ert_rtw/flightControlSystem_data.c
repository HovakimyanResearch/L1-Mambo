/*
 * flightControlSystem_data.c
 *
 * Code generation for model "flightControlSystem".
 *
 * Model version              : 1.73
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Wed Feb 16 01:14:32 2022
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: ARM Compatible->ARM 9
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "flightControlSystem.h"
#include "flightControlSystem_private.h"

/* Block parameters (default storage) */
P_flightControlSystem_T flightControlSystem_P = {
  /* Variable: Vehicle
   * Referenced by: '<S13>/ThrustToMotorCommand'
   */
  {
    {
      0.0,
      1.0
    },

    {
      -71.3232,

      {
        0.0
      }
    },

    {
      0.063,

      { 5.82857e-5, 0.0, 0.0, 0.0, 7.16914e-5, 0.0, 0.0, 0.0, 0.0001 },
      0.0624,
      0.044123463146040563,
      -0.015876,
      0.0,
      0.0,
      0.01
    },

    {
      2.0,
      0.033,
      0.008,
      0.0,
      0.000375,
      1.0209375000000001e-7,
      0.0,
      0.0,
      1.0209375000000001e-7,
      0.0107,
      0.00078263752785053692,
      0.15433206602850458,
      0.25481807079117214,
      0.11868238913561441,
      -0.13613568165555773,
      0.15271630954950383,
      5.5,
      0.0034211943997592849,
      0.605147136,
      4.7199903669109095e-8,
      1.1392838555498841e-10,
      4.7199903669109095e-8
    },

    {
      500.0,
      10.0,
      13840.8,
      1530.72683064892
    }
  },

  /* Variable: As
   * Referenced by: '<S17>/L1 State Predictor'
   */
  { -5.0, -0.0, -0.0, 0.0, 0.0, 0.0, -0.0, -5.0, -0.0, 0.0, 0.0, 0.0, -0.0, -0.0,
    -5.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -10.0, -0.0, -0.0, 0.0, 0.0, 0.0, -0.0,
    -10.0, -0.0, 0.0, 0.0, 0.0, -0.0, -0.0, -10.0 },

  /* Variable: J
   * Referenced by:
   *   '<S5>/Moment controller'
   *   '<S6>/L1 Adaptation Law'
   *   '<S17>/L1 State Predictor'
   */
  { 5.82857E-5, 0.0, 0.0, 0.0, 7.16914E-5, 0.0, 0.0, 0.0, 0.0001 },

  /* Variable: Ts
   * Referenced by: '<S17>/L1 State Predictor'
   */
  0.005,

  /* Variable: adaptationgain
   * Referenced by: '<S6>/L1 Adaptation Law'
   */
  { 197.51041655816087, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 197.51041655816087, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 197.51041655816087, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    195.0416649306589, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 195.0416649306589, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 195.0416649306589 },

  /* Variable: gravity
   * Referenced by: '<S8>/Force controller  (MATLAB Function)'
   */
  9.81,

  /* Variable: kOmega
   * Referenced by: '<S5>/Moment controller'
   */
  { 0.00221, 0.0, 0.0, 0.0, 0.00221, 0.0, 0.0, 0.0, 0.00065000000000000008 },

  /* Variable: kR
   * Referenced by: '<S5>/Moment controller'
   */
  { 0.015, 0.0, 0.0, 0.0, 0.015, 0.0, 0.0, 0.0, 0.002 },

  /* Variable: kv
   * Referenced by: '<S8>/Force controller  (MATLAB Function)'
   */
  { 0.1, 0.0, 0.0, 0.0, 0.1, 0.0, 0.0, 0.0, 0.15 },

  /* Variable: kx
   * Referenced by: '<S8>/Force controller  (MATLAB Function)'
   */
  { 0.62, 0.0, 0.0, 0.0, 0.45, 0.0, 0.0, 0.0, 0.69 },

  /* Variable: m
   * Referenced by: '<S6>/L1 Adaptation Law'
   */
  0.075,

  /* Variable: mass
   * Referenced by:
   *   '<S8>/Force controller  (MATLAB Function)'
   *   '<S17>/L1 State Predictor'
   */
  0.075,

  /* Variable: polytraj
   * Referenced by: '<S3>/MATLAB Function'
   */
  { 2.68838, 3.09951, 2.83567, 2.83567, 3.15261, 2.70838, 0.0, 0.8, 0.8, 0.0,
    -0.8, -0.8, 0.0, 0.277254, -0.302971, -0.308034, -0.220825, 0.373457, 0.0,
    -0.0824515, -0.0244911, -1.77147E-15, 0.0244911, 0.0824515, 0.0, 0.0282627,
    0.00988952, -0.00132518, 0.00988952, -0.0282627, 0.254441, -0.000186435,
    0.0523107, -0.00398292, -0.0245753, 0.073755, -0.200391, -0.0159682,
    -0.0447387, 0.00660033, 0.0230791, -0.0889091, 0.0563228, 0.006276,
    0.0130205, -0.00242308, -0.00667022, 0.0323314, -0.00553097, -0.000687123,
    -0.00130131, 0.000278681, 0.000624162, -0.00376768, 0.0, 1.0, -1.0, 0.0, 1.0,
    -1.0, 0.0, 0.0524215, -0.395969, 0.884651, -0.560225, 0.107839, 0.0,
    -0.31776, 0.254516, 3.1472E-15, -0.254516, 0.31776, 0.0, -0.0439959,
    0.0207542, -0.046427, 0.0368963, -0.0389111, 0.42611, -0.0808848, -0.0227646,
    0.0281171, -0.0211986, 0.166185, -0.348335, 0.0914289, 0.0212805, -0.0449736,
    0.0329223, -0.198156, 0.100437, -0.0261177, -0.00824191, 0.0169437,
    -0.0101269, 0.069964, -0.0101083, 0.00242645, 0.000989136, -0.00192051,
    0.000944544, -0.00797842, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  /* Start of '<Root>/Flight Control System' */
  {
    /* Mask Parameter: LowPassFilterDiscreteorContinuous3_K
     * Referenced by: '<S20>/K'
     */
    1.0,

    /* Mask Parameter: LowPassFilterDiscreteorContinuous2_K
     * Referenced by: '<S19>/K'
     */
    1.0,

    /* Mask Parameter: LowPassFilterDiscreteorContinuous1_K
     * Referenced by: '<S18>/K'
     */
    1.0,

    /* Mask Parameter: LowPassFilterDiscreteorContinuous1_T
     * Referenced by: '<S21>/Time constant'
     */
    0.083333333333333329,

    /* Mask Parameter: LowPassFilterDiscreteorContinuous2_T
     * Referenced by: '<S27>/Time constant'
     */
    0.25,

    /* Mask Parameter: LowPassFilterDiscreteorContinuous3_T
     * Referenced by: '<S33>/Time constant'
     */
    0.16666666666666666,

    /* Mask Parameter: LowPassFilterDiscreteorContinuous1_x0
     * Referenced by: '<S25>/Constant'
     */
    0.0,

    /* Mask Parameter: LowPassFilterDiscreteorContinuous2_x0
     * Referenced by: '<S31>/Constant'
     */
    0.0,

    /* Mask Parameter: LowPassFilterDiscreteorContinuous3_x0
     * Referenced by: '<S37>/Constant'
     */
    0.0,

    /* Mask Parameter: CompareToConstant_const
     * Referenced by: '<S46>/Constant'
     */
    6.867F,

    /* Mask Parameter: CompareToConstant1_const
     * Referenced by: '<S47>/Constant'
     */
    12.753F,

    /* Mask Parameter: WrapToZero_Threshold
     * Referenced by: '<S218>/FixPt Switch'
     */
    4294967295U,

    /* Mask Parameter: CompareToConstant_const_p
     * Referenced by: '<S214>/Constant'
     */
    1U,

    /* Expression: 0
     * Referenced by: '<S212>/Constant'
     */
    0.0,

    /* Expression: pInitialization.M
     * Referenced by: '<S155>/KalmanGainM'
     */
    { 0.99999023110589169, 0.0, 0.0, 4.6181651786725251, 0.0, 0.0, 0.0,
      0.9999902137542509, 0.0, 0.0, 4.2711287385285654, 0.0, 0.0, 0.0,
      0.99999030074102924, 0.0, 0.0, 6.01088259678848 },

    /* Expression: pInitialization.L
     * Referenced by: '<S155>/KalmanGainL'
     */
    { 1.0230810569992541, 2.8459846551446069E-17, 7.07579061167296E-17,
      4.6181651786725153, 5.2962243304527146E-15, 8.2972058249177434E-16,
      -8.7345095445710171E-18, 1.0213458574468937, -3.7773897960256146E-18,
      -1.723760775903471E-15, 4.27112873852856, 1.4186125028627594E-16,
      1.2094452797235627E-17, -3.2913891790555537E-17, 1.030044713724972,
      7.9344678041014017E-17, -5.5404488557817719E-15, 6.0108825967884849 },

    /* Expression: 2
     * Referenced by: '<S3>/Constant'
     */
    2.0,

    /* Expression: pInitialization.M
     * Referenced by: '<S104>/KalmanGainM'
     */
    { 0.0011869299883620552, -3.2868164179443354E-5 },

    /* Expression: pInitialization.M
     * Referenced by: '<S52>/KalmanGainM'
     */
    { 0.0011869299883620552, -3.2868164179443354E-5 },

    /* Expression: 0.0
     * Referenced by: '<S17>/Delay2'
     */
    0.0,

    /* Expression: 0
     * Referenced by: '<S24>/Constant'
     */
    0.0,

    /* Computed Parameter: Integrator_gainval
     * Referenced by: '<S26>/Integrator'
     */
    0.005,

    /* Expression: antiwindupUpperLimit
     * Referenced by: '<S26>/Integrator'
     */
    1.5,

    /* Expression: antiwindupLowerLimit
     * Referenced by: '<S26>/Integrator'
     */
    -1.5,

    /* Expression: windupUpperLimit
     * Referenced by: '<S26>/Saturation'
     */
    0.0,

    /* Expression: windupLowerLimit
     * Referenced by: '<S26>/Saturation'
     */
    0.0,

    /* Expression: 0
     * Referenced by: '<S30>/Constant'
     */
    0.0,

    /* Computed Parameter: Integrator_gainval_d
     * Referenced by: '<S32>/Integrator'
     */
    0.005,

    /* Expression: antiwindupUpperLimit
     * Referenced by: '<S32>/Integrator'
     */
    0.02,

    /* Expression: antiwindupLowerLimit
     * Referenced by: '<S32>/Integrator'
     */
    -0.02,

    /* Expression: windupUpperLimit
     * Referenced by: '<S32>/Saturation'
     */
    0.0,

    /* Expression: windupLowerLimit
     * Referenced by: '<S32>/Saturation'
     */
    0.0,

    /* Expression: 0
     * Referenced by: '<S15>/Constant'
     */
    0.0,

    /* Expression: 0
     * Referenced by: '<S15>/Constant1'
     */
    0.0,

    /* Expression: 0
     * Referenced by: '<S15>/Switch'
     */
    0.0,

    /* Expression: 0
     * Referenced by: '<S15>/Switch1'
     */
    0.0,

    /* Expression: 0
     * Referenced by: '<S36>/Constant'
     */
    0.0,

    /* Computed Parameter: Integrator_gainval_a
     * Referenced by: '<S38>/Integrator'
     */
    0.005,

    /* Expression: antiwindupUpperLimit
     * Referenced by: '<S38>/Integrator'
     */
    0.02,

    /* Expression: antiwindupLowerLimit
     * Referenced by: '<S38>/Integrator'
     */
    -0.02,

    /* Expression: windupUpperLimit
     * Referenced by: '<S38>/Saturation'
     */
    0.0,

    /* Expression: windupLowerLimit
     * Referenced by: '<S38>/Saturation'
     */
    0.0,

    /* Expression: pInitialization.L
     * Referenced by: '<S104>/KalmanGainL'
     */
    { 0.0011870943291829544, -3.2868164179443428E-5 },

    /* Expression: pInitialization.L
     * Referenced by: '<S52>/KalmanGainL'
     */
    { 0.0011870943291829544, -3.2868164179443428E-5 },

    /* Expression: pInitialization.Z
     * Referenced by: '<S155>/CovarianceZ'
     */
    { 9.9999023110589173E-9, 0.0, 0.0, 4.6181651786725248E-8, 0.0, 0.0, 0.0,
      9.9999021375425074E-9, 0.0, 0.0, 4.2711287385285655E-8, 0.0, 0.0, 0.0,
      9.9999030074102933E-9, 0.0, 0.0, 6.01088259678848E-8,
      4.6181651786725248E-8, 0.0, 0.0, 0.94547448524913114, 0.0, 0.0, 0.0,
      4.2711287385285655E-8, 0.0, 0.0, 0.87287547230499984, 0.0, 0.0, 0.0,
      6.0108825967884815E-8, 0.0, 0.0, 1.2394399023133829 },

    /* Expression: pInitialization.Z
     * Referenced by: '<S52>/CovarianceZ'
     */
    { 1097.3834951572255, -30.388465402591859, -30.388465402591855,
      7.2223686232128914 },

    /* Expression: pInitialization.Z
     * Referenced by: '<S104>/CovarianceZ'
     */
    { 1097.3834951572255, -30.388465402591859, -30.388465402591855,
      7.2223686232128914 },

    /* Expression: 0
     * Referenced by: '<S1>/Constant'
     */
    0.0,

    /* Computed Parameter: UDPReceive1_Port
     * Referenced by: '<S4>/UDP Receive1'
     */
    29000,

    /* Computed Parameter: Lykyhatkk1_Y0
     * Referenced by: '<S204>/L*(y[k]-yhat[k|k-1])'
     */
    0.0F,

    /* Computed Parameter: deltax_Y0
     * Referenced by: '<S206>/deltax'
     */
    0.0F,

    /* Computed Parameter: Gain_Gain
     * Referenced by: '<S212>/Gain'
     */
    0.00228F,

    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S216>/Out1'
     */
    0.0F,

    /* Computed Parameter: A_Value
     * Referenced by: '<S42>/A'
     */
    { 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F,
      0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.005F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F,
      0.0F, 0.005F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.005F, 0.0F, 0.0F, 1.0F
    },

    /* Computed Parameter: C_Value
     * Referenced by: '<S42>/C'
     */
    { 1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F,
      0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F },

    /* Computed Parameter: B_Value
     * Referenced by: '<S42>/B'
     */
    { 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F,
      0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F },

    /* Expression: Controller.Q2Ts
     * Referenced by: '<S10>/TorqueTotalThrustToThrustPerMotor'
     */
    { 0.25F, 0.25F, 0.25F, 0.25F, 103.573624F, -103.573624F, 103.573624F,
      -103.573624F, -5.66592F, -5.66592F, 5.66592F, 5.66592F, -5.66592F,
      5.66592F, 5.66592F, -5.66592F },

    /* Computed Parameter: Delay_InitialCondition
     * Referenced by: '<S44>/Delay'
     */
    { 1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 1.0F },

    /* Computed Parameter: Gain1_Gain
     * Referenced by: '<S4>/Gain1'
     */
    -1.0F,

    /* Computed Parameter: Gain_Gain_m
     * Referenced by: '<S4>/Gain'
     */
    -1.0F,

    /* Computed Parameter: Assumingthatthepreflightcalibrationwasdoneatlevelorientation_Bi
     * Referenced by: '<S45>/Assuming that the  preflight calibration was done at level orientation'
     */
    { 0.0F, 0.0F, 9.81F, 0.0F, 0.0F, 0.0F },

    /* Computed Parameter: inverseIMU_gain_Gain
     * Referenced by: '<S45>/inverseIMU_gain'
     */
    { 0.994075298F, 0.996184587F, 1.00549F, 1.00139189F, 0.993601203F, 1.00003F
    },

    /* Computed Parameter: FIR_IMUaccel_InitialStates
     * Referenced by: '<S45>/FIR_IMUaccel'
     */
    0.0F,

    /* Computed Parameter: FIR_IMUaccel_Coefficients
     * Referenced by: '<S45>/FIR_IMUaccel'
     */
    { 0.0264077242F, 0.140531361F, 0.33306092F, 0.33306092F, 0.140531361F,
      0.0264077242F },

    /* Computed Parameter: Gain3_Gain
     * Referenced by: '<S44>/Gain3'
     */
    0.15F,

    /* Computed Parameter: LPFFcutoff40Hz1_NumCoef
     * Referenced by: '<S45>/LPF Fcutoff = 40Hz1'
     */
    { 1.0F, 1.0F },

    /* Computed Parameter: LPFFcutoff40Hz1_DenCoef
     * Referenced by: '<S45>/LPF Fcutoff = 40Hz1'
     */
    { 2.5915494F, -0.591549456F },

    /* Computed Parameter: LPFFcutoff40Hz1_InitialStates
     * Referenced by: '<S45>/LPF Fcutoff = 40Hz1'
     */
    0.0F,

    /* Computed Parameter: LPFFcutoff40Hz_NumCoef
     * Referenced by: '<S45>/LPF Fcutoff = 40Hz'
     */
    { 1.0F, 1.0F },

    /* Computed Parameter: LPFFcutoff40Hz_DenCoef
     * Referenced by: '<S45>/LPF Fcutoff = 40Hz'
     */
    { 2.5915494F, -0.591549456F },

    /* Computed Parameter: LPFFcutoff40Hz_InitialStates
     * Referenced by: '<S45>/LPF Fcutoff = 40Hz'
     */
    0.0F,

    /* Computed Parameter: IIR_IMUgyro_r_NumCoef
     * Referenced by: '<S45>/IIR_IMUgyro_r'
     */
    { 0.282124132F, 1.27253926F, 2.42084408F, 2.42084408F, 1.27253926F,
      0.282124132F },

    /* Computed Parameter: IIR_IMUgyro_r_DenCoef
     * Referenced by: '<S45>/IIR_IMUgyro_r'
     */
    { 1.0F, 2.22871494F, 2.52446198F, 1.57725322F, 0.54102242F, 0.0795623958F },

    /* Computed Parameter: IIR_IMUgyro_r_InitialStates
     * Referenced by: '<S45>/IIR_IMUgyro_r'
     */
    0.0F,

    /* Computed Parameter: D_Value
     * Referenced by: '<S42>/D'
     */
    { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F },

    /* Computed Parameter: X0_Value
     * Referenced by: '<S42>/X0'
     */
    { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F },

    /* Computed Parameter: X0_Value_f
     * Referenced by: '<S103>/X0'
     */
    { 0.0F, 0.0F },

    /* Computed Parameter: Constant_Value_l
     * Referenced by: '<S50>/Constant'
     */
    2.0F,

    /* Computed Parameter: C_Value_g
     * Referenced by: '<S103>/C'
     */
    { 1.0F, 0.0F },

    /* Computed Parameter: X0_Value_j
     * Referenced by: '<S51>/X0'
     */
    { 0.0F, 0.0F },

    /* Computed Parameter: Gain2_Gain
     * Referenced by: '<S48>/Gain2'
     */
    0.101936802F,

    /* Computed Parameter: C_Value_c
     * Referenced by: '<S51>/C'
     */
    { 1.0F, 0.0F },

    /* Computed Parameter: Constant_Value_h
     * Referenced by: '<S41>/Constant'
     */
    0.0F,

    /* Computed Parameter: Gain1_Gain_i
     * Referenced by: '<S5>/Gain1'
     */
    -1.0F,

    /* Computed Parameter: Saturation5_UpperSat
     * Referenced by: '<S13>/Saturation5'
     */
    800.0F,

    /* Expression: Vehicle.Motor.minLimit
     * Referenced by: '<S13>/Saturation5'
     */
    10.0F,

    /* Computed Parameter: MotorDirections_Gain
     * Referenced by: '<S13>/MotorDirections'
     */
    { 1.0F, -1.0F, 1.0F, -1.0F },

    /* Computed Parameter: A_Value_n
     * Referenced by: '<S51>/A'
     */
    { 1.0F, 0.0F, -0.005F, 1.0F },

    /* Computed Parameter: A_Value_n4
     * Referenced by: '<S103>/A'
     */
    { 1.0F, 0.0F, -0.005F, 1.0F },

    /* Computed Parameter: B_Value_p
     * Referenced by: '<S103>/B'
     */
    { 0.005F, 0.0F },

    /* Computed Parameter: D_Value_n
     * Referenced by: '<S103>/D'
     */
    0.0F,

    /* Computed Parameter: B_Value_o
     * Referenced by: '<S51>/B'
     */
    { 0.005F, 0.0F },

    /* Computed Parameter: D_Value_c
     * Referenced by: '<S51>/D'
     */
    0.0F,

    /* Computed Parameter: P0_Value
     * Referenced by: '<S42>/P0'
     */
    { 0.00102364738F, 0.0F, 0.0F, 0.00472741853F, 0.0F, 0.0F, 0.0F,
      0.00102183234F, 0.0F, 0.0F, 0.00436442F, 0.0F, 0.0F, 0.0F, 0.00103099656F,
      0.0F, 0.0F, 0.00619725976F, 0.00472741853F, 0.0F, 0.0F, 0.967306495F, 0.0F,
      0.0F, 0.0F, 0.00436442F, 0.0F, 0.0F, 0.891516447F, 0.0F, 0.0F, 0.0F,
      0.00619725976F, 0.0F, 0.0F, 1.27669096F },

    /* Computed Parameter: G_Value
     * Referenced by: '<S42>/G'
     */
    { 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F,
      0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F,
      0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F },

    /* Computed Parameter: Q_Value
     * Referenced by: '<S42>/Q'
     */
    { 0.001F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.001F, 0.0F, 0.0F, 0.0F, 0.0F,
      0.0F, 0.0F, 0.001F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.021832F, 0.0F,
      0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.018641F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F,
      0.0F, 0.037251F },

    /* Computed Parameter: H_Value
     * Referenced by: '<S42>/H'
     */
    { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F,
      0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F },

    /* Computed Parameter: N_Value
     * Referenced by: '<S42>/N'
     */
    { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F,
      0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F },

    /* Computed Parameter: R_Value
     * Referenced by: '<S42>/R'
     */
    { 1.0E-8F, 0.0F, 0.0F, 0.0F, 1.0E-8F, 0.0F, 0.0F, 0.0F, 1.0E-8F },

    /* Computed Parameter: P0_Value_e
     * Referenced by: '<S51>/P0'
     */
    { 1098.6875F, -30.4245777F, -30.4245777F, 7.22336864F },

    /* Computed Parameter: G_Value_n
     * Referenced by: '<S51>/G'
     */
    { 1.0F, 0.0F, 0.0F, 1.0F },

    /* Computed Parameter: Q_Value_c
     * Referenced by: '<S51>/Q'
     */
    { 1.0F, 0.0F, 0.0F, 0.001F },

    /* Computed Parameter: P0_Value_c
     * Referenced by: '<S103>/P0'
     */
    { 1098.6875F, -30.4245777F, -30.4245777F, 7.22336864F },

    /* Computed Parameter: G_Value_nz
     * Referenced by: '<S103>/G'
     */
    { 1.0F, 0.0F, 0.0F, 1.0F },

    /* Computed Parameter: Q_Value_l
     * Referenced by: '<S103>/Q'
     */
    { 1.0F, 0.0F, 0.0F, 0.001F },

    /* Computed Parameter: H_Value_e
     * Referenced by: '<S51>/H'
     */
    { 0.0F, 0.0F },

    /* Computed Parameter: N_Value_d
     * Referenced by: '<S51>/N'
     */
    { 0.0F, 0.0F },

    /* Computed Parameter: H_Value_j
     * Referenced by: '<S103>/H'
     */
    { 0.0F, 0.0F },

    /* Computed Parameter: N_Value_f
     * Referenced by: '<S103>/N'
     */
    { 0.0F, 0.0F },

    /* Computed Parameter: R_Value_j
     * Referenced by: '<S51>/R'
     */
    924556.188F,

    /* Computed Parameter: R_Value_o
     * Referenced by: '<S103>/R'
     */
    924556.188F,

    /* Computed Parameter: Output_InitialCondition
     * Referenced by: '<S215>/Output'
     */
    0U,

    /* Computed Parameter: FixPtConstant_Value
     * Referenced by: '<S217>/FixPt Constant'
     */
    1U,

    /* Computed Parameter: Constant_Value_n
     * Referenced by: '<S218>/Constant'
     */
    0U,

    /* Expression: true()
     * Referenced by: '<S42>/Enable'
     */
    1,

    /* Computed Parameter: controlModePosVsOrient_Value
     * Referenced by: '<S1>/controlModePosVsOrient'
     */
    1,

    /* Computed Parameter: Disabletemperaturecompensation_CurrentSetting
     * Referenced by: '<S212>/Disable temperature compensation'
     */
    1U,

    /* Start of '<S130>/Enabled Subsystem' */
    {
      /* Computed Parameter: deltax_Y0
       * Referenced by: '<S154>/deltax'
       */
      0.0F
    }
    ,

    /* End of '<S130>/Enabled Subsystem' */

    /* Start of '<S123>/MeasurementUpdate' */
    {
      /* Computed Parameter: Lykyhatkk1_Y0
       * Referenced by: '<S152>/L*(y[k]-yhat[k|k-1])'
       */
      0.0F
    }
    ,

    /* End of '<S123>/MeasurementUpdate' */

    /* Start of '<S78>/Enabled Subsystem' */
    {
      /* Computed Parameter: deltax_Y0
       * Referenced by: '<S102>/deltax'
       */
      0.0F
    }
    ,

    /* End of '<S78>/Enabled Subsystem' */

    /* Start of '<S71>/MeasurementUpdate' */
    {
      /* Computed Parameter: Lykyhatkk1_Y0
       * Referenced by: '<S100>/L*(y[k]-yhat[k|k-1])'
       */
      0.0F
    }
    /* End of '<S71>/MeasurementUpdate' */
  }
  /* End of '<Root>/Flight Control System' */
};
