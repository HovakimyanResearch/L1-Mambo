/*
 * flightControlSystem.c
 *
 * Code generation for model "flightControlSystem".
 *
 * Model version              : 1.73
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Wed Feb 16 01:14:32 2022
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: ARM Compatible->ARM 9
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "flightControlSystem.h"
#include "flightControlSystem_private.h"

/* Exported block signals */
CommandBus cmd_inport;                 /* '<Root>/AC cmd' */
SensorsBus sensor_inport;              /* '<Root>/Sensors' */
real32_T motors_outport[4];            /* '<S13>/MotorDirections' */
uint8_T flag_outport;                  /* '<S1>/Data Type Conversion' */

/* Block signals (default storage) */
B_flightControlSystem_T flightControlSystem_B;

/* Block states (default storage) */
DW_flightControlSystem_T flightControlSystem_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_flightControlSystem_T flightControlSystem_PrevZCX;

/* External outputs (root outports fed by signals with default storage) */
ExtY_flightControlSystem_T flightControlSystem_Y;

/* Real-time model */
static RT_MODEL_flightControlSystem_T flightControlSystem_M_;
RT_MODEL_flightControlSystem_T *const flightControlSystem_M =
  &flightControlSystem_M_;

/* Forward declaration for local functions */
static void flightControlSystem_atan2(const real32_T y_data[], const int32_T
  y_size[3], const real32_T x_data[], const int32_T x_size[3], real32_T r_data[],
  int32_T r_size[3]);
static void flightControlSystem_flip(real_T x[8]);
static void flightControlSystem_polyder(real_T a_data[], int32_T a_size[2]);
static real_T flightControlSystem_polyval(const real_T p_data[], const int32_T
  p_size[2], real_T x);
static real_T flightControlSystem_polyval_f(const real_T p[8], real_T x);
static void flightControlSystem_polyder_i(const real_T u_data[], const int32_T
  u_size[2], real_T a_data[], int32_T a_size[2]);
static void flightControlSystem_polyder_iv(const real_T u[8], real_T a_data[],
  int32_T a_size[2]);
static void flightControlSystem_inv(const real_T x[9], real_T y[9],
  B_FlightControlSystem_flightControlSystem_T *localB);

/*
 * System initialize for enable system:
 *    '<S71>/MeasurementUpdate'
 *    '<S123>/MeasurementUpdate'
 */
void flightControlSystem_MeasurementUpdate_Init
  (B_MeasurementUpdate_flightControlSystem_T *localB,
   P_MeasurementUpdate_flightControlSystem_T *localP)
{
  /* SystemInitialize for Product: '<S100>/Product3' incorporates:
   *  Outport: '<S100>/L*(y[k]-yhat[k|k-1])'
   */
  localB->Product3[0] = localP->Lykyhatkk1_Y0;
  localB->Product3[1] = localP->Lykyhatkk1_Y0;
}

/*
 * Disable for enable system:
 *    '<S71>/MeasurementUpdate'
 *    '<S123>/MeasurementUpdate'
 */
void flightControlSystem_MeasurementUpdate_Disable
  (B_MeasurementUpdate_flightControlSystem_T *localB,
   DW_MeasurementUpdate_flightControlSystem_T *localDW,
   P_MeasurementUpdate_flightControlSystem_T *localP)
{
  /* Disable for Product: '<S100>/Product3' incorporates:
   *  Outport: '<S100>/L*(y[k]-yhat[k|k-1])'
   */
  localB->Product3[0] = localP->Lykyhatkk1_Y0;
  localB->Product3[1] = localP->Lykyhatkk1_Y0;
  localDW->MeasurementUpdate_MODE = false;
}

/*
 * Start for enable system:
 *    '<S71>/MeasurementUpdate'
 *    '<S123>/MeasurementUpdate'
 */
void flightControlSystem_MeasurementUpdate_Start
  (DW_MeasurementUpdate_flightControlSystem_T *localDW)
{
  localDW->MeasurementUpdate_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S71>/MeasurementUpdate'
 *    '<S123>/MeasurementUpdate'
 */
void flightControlSystem_MeasurementUpdate(boolean_T rtu_Enable, const real32_T
  rtu_Lk[2], real32_T rtu_yk, const real32_T rtu_Ck[2], const real32_T
  rtu_xhatkk1[2], real32_T rtu_Dk, real32_T rtu_uk,
  B_MeasurementUpdate_flightControlSystem_T *localB,
  DW_MeasurementUpdate_flightControlSystem_T *localDW,
  P_MeasurementUpdate_flightControlSystem_T *localP)
{
  real32_T rtb_Sum_do;

  /* Outputs for Enabled SubSystem: '<S71>/MeasurementUpdate' incorporates:
   *  EnablePort: '<S100>/Enable'
   */
  if (rtu_Enable) {
    localDW->MeasurementUpdate_MODE = true;

    /* Sum: '<S100>/Sum' incorporates:
     *  Product: '<S100>/C[k]*xhat[k|k-1]'
     *  Product: '<S100>/D[k]*u[k]'
     *  Sum: '<S100>/Add1'
     */
    rtb_Sum_do = rtu_yk - ((rtu_Ck[0] * rtu_xhatkk1[0] + rtu_Ck[1] *
      rtu_xhatkk1[1]) + rtu_Dk * rtu_uk);

    /* Product: '<S100>/Product3' */
    localB->Product3[0] = rtu_Lk[0] * rtb_Sum_do;
    localB->Product3[1] = rtu_Lk[1] * rtb_Sum_do;
  } else {
    if (localDW->MeasurementUpdate_MODE) {
      flightControlSystem_MeasurementUpdate_Disable(localB, localDW, localP);
    }
  }

  /* End of Outputs for SubSystem: '<S71>/MeasurementUpdate' */
}

/*
 * System initialize for enable system:
 *    '<S78>/Enabled Subsystem'
 *    '<S130>/Enabled Subsystem'
 */
void flightControlSystem_EnabledSubsystem_Init
  (B_EnabledSubsystem_flightControlSystem_T *localB,
   P_EnabledSubsystem_flightControlSystem_T *localP)
{
  /* SystemInitialize for Product: '<S102>/Product2' incorporates:
   *  Outport: '<S102>/deltax'
   */
  localB->Product2[0] = localP->deltax_Y0;
  localB->Product2[1] = localP->deltax_Y0;
}

/*
 * Disable for enable system:
 *    '<S78>/Enabled Subsystem'
 *    '<S130>/Enabled Subsystem'
 */
void flightControlSystem_EnabledSubsystem_Disable
  (B_EnabledSubsystem_flightControlSystem_T *localB,
   DW_EnabledSubsystem_flightControlSystem_T *localDW,
   P_EnabledSubsystem_flightControlSystem_T *localP)
{
  /* Disable for Product: '<S102>/Product2' incorporates:
   *  Outport: '<S102>/deltax'
   */
  localB->Product2[0] = localP->deltax_Y0;
  localB->Product2[1] = localP->deltax_Y0;
  localDW->EnabledSubsystem_MODE = false;
}

/*
 * Start for enable system:
 *    '<S78>/Enabled Subsystem'
 *    '<S130>/Enabled Subsystem'
 */
void flightControlSystem_EnabledSubsystem_Start
  (DW_EnabledSubsystem_flightControlSystem_T *localDW)
{
  localDW->EnabledSubsystem_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S78>/Enabled Subsystem'
 *    '<S130>/Enabled Subsystem'
 */
void flightControlSystem_EnabledSubsystem(boolean_T rtu_Enable, const real32_T
  rtu_Mk[2], const real32_T rtu_Ck[2], real32_T rtu_yk, const real32_T
  rtu_xhatkk1[2], B_EnabledSubsystem_flightControlSystem_T *localB,
  DW_EnabledSubsystem_flightControlSystem_T *localDW,
  P_EnabledSubsystem_flightControlSystem_T *localP)
{
  real32_T rtb_Add1_o;

  /* Outputs for Enabled SubSystem: '<S78>/Enabled Subsystem' incorporates:
   *  EnablePort: '<S102>/Enable'
   */
  if (rtu_Enable) {
    localDW->EnabledSubsystem_MODE = true;

    /* Sum: '<S102>/Add1' incorporates:
     *  Product: '<S102>/Product'
     */
    rtb_Add1_o = rtu_yk - (rtu_Ck[0] * rtu_xhatkk1[0] + rtu_Ck[1] * rtu_xhatkk1
      [1]);

    /* Product: '<S102>/Product2' */
    localB->Product2[0] = rtu_Mk[0] * rtb_Add1_o;
    localB->Product2[1] = rtu_Mk[1] * rtb_Add1_o;
  } else {
    if (localDW->EnabledSubsystem_MODE) {
      flightControlSystem_EnabledSubsystem_Disable(localB, localDW, localP);
    }
  }

  /* End of Outputs for SubSystem: '<S78>/Enabled Subsystem' */
}

real32_T rt_atan2f_snf(real32_T u0, real32_T u1)
{
  int32_T u0_0;
  int32_T u1_0;
  real32_T y;
  if (rtIsNaNF(u0) || rtIsNaNF(u1)) {
    y = (rtNaNF);
  } else if (rtIsInfF(u0) && rtIsInfF(u1)) {
    if (u0 > 0.0F) {
      u0_0 = 1;
    } else {
      u0_0 = -1;
    }

    if (u1 > 0.0F) {
      u1_0 = 1;
    } else {
      u1_0 = -1;
    }

    y = atan2f((real32_T)u0_0, (real32_T)u1_0);
  } else if (u1 == 0.0F) {
    if (u0 > 0.0F) {
      y = RT_PIF / 2.0F;
    } else if (u0 < 0.0F) {
      y = -(RT_PIF / 2.0F);
    } else {
      y = 0.0F;
    }
  } else {
    y = atan2f(u0, u1);
  }

  return y;
}

/* Function for MATLAB Function: '<S44>/MATLAB Function4' */
static void flightControlSystem_atan2(const real32_T y_data[], const int32_T
  y_size[3], const real32_T x_data[], const int32_T x_size[3], real32_T r_data[],
  int32_T r_size[3])
{
  int32_T tmp;
  real32_T z1_data;
  int8_T csz_idx_2;
  if (y_size[2] <= x_size[2]) {
    csz_idx_2 = (int8_T)y_size[2];
    tmp = (int8_T)y_size[2];
  } else {
    csz_idx_2 = 0;
    tmp = 0;
  }

  if (0 <= tmp - 1) {
    memcpy(&z1_data, &r_data[0], ((tmp - 1) + 1) * sizeof(real32_T));
  }

  if (0 <= csz_idx_2 - 1) {
    z1_data = rt_atan2f_snf(y_data[0], x_data[0]);
  }

  r_size[0] = 1;
  r_size[1] = 1;
  r_size[2] = csz_idx_2;
  if (0 <= tmp - 1) {
    memcpy(&r_data[0], &z1_data, ((tmp - 1) + 1) * sizeof(real32_T));
  }
}

/* Function for MATLAB Function: '<S3>/MATLAB Function' */
static void flightControlSystem_flip(real_T x[8])
{
  real_T tmp;
  tmp = x[0];
  x[0] = x[7];
  x[7] = tmp;
  tmp = x[1];
  x[1] = x[6];
  x[6] = tmp;
  tmp = x[2];
  x[2] = x[5];
  x[5] = tmp;
  tmp = x[3];
  x[3] = x[4];
  x[4] = tmp;
}

/* Function for MATLAB Function: '<S3>/MATLAB Function' */
static void flightControlSystem_polyder(real_T a_data[], int32_T a_size[2])
{
  static const real_T x[8] = { -0.1563, 1.0938, -2.625, 2.1875, 0.0, 0.0, 0.0,
    0.0 };

  int32_T c_k;
  int32_T nlead0;
  nlead0 = 0;
  c_k = 0;
  while ((c_k < 6) && (x[c_k] == 0.0)) {
    nlead0++;
    c_k++;
  }

  a_size[0] = 1;
  a_size[1] = 7 - nlead0;
  for (c_k = 0; c_k <= 6 - nlead0; c_k++) {
    a_data[c_k] = x[c_k + nlead0];
  }

  for (c_k = 0; c_k <= 5 - nlead0; c_k++) {
    a_data[c_k] *= (real_T)(6 - (nlead0 + c_k)) + 1.0;
  }
}

/* Function for MATLAB Function: '<S3>/MATLAB Function' */
static real_T flightControlSystem_polyval(const real_T p_data[], const int32_T
  p_size[2], real_T x)
{
  real_T y;
  int32_T k;
  if (p_size[1] != 0) {
    y = p_data[0];
    for (k = 0; k <= p_size[1] - 2; k++) {
      y = x * y + p_data[k + 1];
    }
  }

  return y;
}

/* Function for MATLAB Function: '<S3>/MATLAB Function' */
static real_T flightControlSystem_polyval_f(const real_T p[8], real_T x)
{
  real_T y;
  int32_T k;
  y = p[0];
  for (k = 0; k < 7; k++) {
    y = x * y + p[k + 1];
  }

  return y;
}

/* Function for MATLAB Function: '<S3>/MATLAB Function' */
static void flightControlSystem_polyder_i(const real_T u_data[], const int32_T
  u_size[2], real_T a_data[], int32_T a_size[2])
{
  real_T tmp;
  int32_T b_k;
  int32_T nlead0;
  int32_T nymax;
  if (u_size[1] < 2) {
    nymax = 1;
  } else {
    nymax = u_size[1] - 1;
  }

  a_size[0] = 1;
  a_size[1] = nymax;
  if ((u_size[1] == 0) || (u_size[1] == 1)) {
    a_data[0] = 0.0;
  } else {
    nlead0 = 0;
    b_k = 0;
    while ((b_k <= nymax - 2) && (u_data[b_k] == 0.0)) {
      nlead0++;
      b_k++;
    }

    nymax -= nlead0;
    a_size[0] = 1;
    a_size[1] = nymax;
    for (b_k = 0; b_k < nymax; b_k++) {
      a_data[b_k] = u_data[b_k + nlead0];
    }
  }

  nlead0 = a_size[1];
  for (nymax = 0; nymax <= nlead0 - 2; nymax++) {
    a_data[nymax] *= (real_T)((nlead0 - nymax) - 1) + 1.0;
  }

  if (u_size[1] != 0) {
    tmp = u_data[u_size[1] - 1];
    if (rtIsInf(tmp) || rtIsNaN(tmp)) {
      a_data[a_size[1] - 1] = (rtNaN);
    }
  }
}

/* Function for MATLAB Function: '<S3>/MATLAB Function' */
static void flightControlSystem_polyder_iv(const real_T u[8], real_T a_data[],
  int32_T a_size[2])
{
  int32_T c_k;
  int32_T nlead0;
  nlead0 = 0;
  c_k = 0;
  while ((c_k < 6) && (u[c_k] == 0.0)) {
    nlead0++;
    c_k++;
  }

  a_size[0] = 1;
  a_size[1] = 7 - nlead0;
  for (c_k = 0; c_k <= 6 - nlead0; c_k++) {
    a_data[c_k] = u[c_k + nlead0];
  }

  for (c_k = 0; c_k <= 5 - nlead0; c_k++) {
    a_data[c_k] *= (real_T)(6 - (nlead0 + c_k)) + 1.0;
  }

  if (rtIsInf(u[7]) || rtIsNaN(u[7])) {
    a_data[6 - nlead0] = (rtNaN);
  }
}

real32_T rt_powf_snf(real32_T u0, real32_T u1)
{
  real32_T tmp;
  real32_T tmp_0;
  real32_T y;
  if (rtIsNaNF(u0) || rtIsNaNF(u1)) {
    y = (rtNaNF);
  } else {
    tmp = fabsf(u0);
    tmp_0 = fabsf(u1);
    if (rtIsInfF(u1)) {
      if (tmp == 1.0F) {
        y = 1.0F;
      } else if (tmp > 1.0F) {
        if (u1 > 0.0F) {
          y = (rtInfF);
        } else {
          y = 0.0F;
        }
      } else if (u1 > 0.0F) {
        y = 0.0F;
      } else {
        y = (rtInfF);
      }
    } else if (tmp_0 == 0.0F) {
      y = 1.0F;
    } else if (tmp_0 == 1.0F) {
      if (u1 > 0.0F) {
        y = u0;
      } else {
        y = 1.0F / u0;
      }
    } else if (u1 == 2.0F) {
      y = u0 * u0;
    } else if ((u1 == 0.5F) && (u0 >= 0.0F)) {
      y = sqrtf(u0);
    } else if ((u0 < 0.0F) && (u1 > floorf(u1))) {
      y = (rtNaNF);
    } else {
      y = powf(u0, u1);
    }
  }

  return y;
}

/* Function for MATLAB Function: '<S17>/L1 State Predictor' */
static void flightControlSystem_inv(const real_T x[9], real_T y[9],
  B_FlightControlSystem_flightControlSystem_T *localB)
{
  int32_T itmp;
  int32_T p1;
  int32_T p2;
  int32_T p3;
  memcpy(&localB->b_x[0], &x[0], 9U * sizeof(real_T));
  p1 = 0;
  p2 = 3;
  p3 = 6;
  localB->absx11 = fabs(x[0]);
  localB->absx21 = fabs(x[1]);
  localB->absx31 = fabs(x[2]);
  if ((localB->absx21 > localB->absx11) && (localB->absx21 > localB->absx31)) {
    p1 = 3;
    p2 = 0;
    localB->b_x[0] = x[1];
    localB->b_x[1] = x[0];
    localB->b_x[3] = x[4];
    localB->b_x[4] = x[3];
    localB->b_x[6] = x[7];
    localB->b_x[7] = x[6];
  } else {
    if (localB->absx31 > localB->absx11) {
      p1 = 6;
      p3 = 0;
      localB->b_x[0] = x[2];
      localB->b_x[2] = x[0];
      localB->b_x[3] = x[5];
      localB->b_x[5] = x[3];
      localB->b_x[6] = x[8];
      localB->b_x[8] = x[6];
    }
  }

  localB->absx11 = localB->b_x[1] / localB->b_x[0];
  localB->b_x[1] = localB->absx11;
  localB->absx21 = localB->b_x[2] / localB->b_x[0];
  localB->b_x[2] = localB->absx21;
  localB->b_x[4] -= localB->absx11 * localB->b_x[3];
  localB->b_x[5] -= localB->absx21 * localB->b_x[3];
  localB->b_x[7] -= localB->absx11 * localB->b_x[6];
  localB->b_x[8] -= localB->absx21 * localB->b_x[6];
  if (fabs(localB->b_x[5]) > fabs(localB->b_x[4])) {
    itmp = p2;
    p2 = p3;
    p3 = itmp;
    localB->b_x[1] = localB->absx21;
    localB->b_x[2] = localB->absx11;
    localB->absx11 = localB->b_x[4];
    localB->b_x[4] = localB->b_x[5];
    localB->b_x[5] = localB->absx11;
    localB->absx11 = localB->b_x[7];
    localB->b_x[7] = localB->b_x[8];
    localB->b_x[8] = localB->absx11;
  }

  localB->absx11 = localB->b_x[5] / localB->b_x[4];
  localB->b_x[8] -= localB->absx11 * localB->b_x[7];
  localB->absx21 = (localB->absx11 * localB->b_x[1] - localB->b_x[2]) /
    localB->b_x[8];
  localB->absx31 = -(localB->b_x[7] * localB->absx21 + localB->b_x[1]) /
    localB->b_x[4];
  y[p1] = ((1.0 - localB->b_x[3] * localB->absx31) - localB->b_x[6] *
           localB->absx21) / localB->b_x[0];
  y[p1 + 1] = localB->absx31;
  y[p1 + 2] = localB->absx21;
  localB->absx21 = -localB->absx11 / localB->b_x[8];
  localB->absx31 = (1.0 - localB->b_x[7] * localB->absx21) / localB->b_x[4];
  y[p2] = -(localB->b_x[3] * localB->absx31 + localB->b_x[6] * localB->absx21) /
    localB->b_x[0];
  y[p2 + 1] = localB->absx31;
  y[p2 + 2] = localB->absx21;
  localB->absx21 = 1.0 / localB->b_x[8];
  localB->absx31 = -localB->b_x[7] * localB->absx21 / localB->b_x[4];
  y[p3] = -(localB->b_x[3] * localB->absx31 + localB->b_x[6] * localB->absx21) /
    localB->b_x[0];
  y[p3 + 1] = localB->absx31;
  y[p3 + 2] = localB->absx21;
}

/* System initialize for atomic system: '<Root>/Flight Control System' */
void flightControlSystem_FlightControlSystem_Init
  (B_FlightControlSystem_flightControlSystem_T *localB,
   DW_FlightControlSystem_flightControlSystem_T *localDW,
   P_FlightControlSystem_flightControlSystem_T *localP)
{
  int32_T i;

  /* InitializeConditions for Delay: '<S44>/Delay' */
  for (i = 0; i < 9; i++) {
    localDW->Delay_DSTATE[i] = localP->Delay_InitialCondition[i];
  }

  /* End of InitializeConditions for Delay: '<S44>/Delay' */

  /* InitializeConditions for DiscreteFir: '<S45>/FIR_IMUaccel' */
  localDW->FIR_IMUaccel_circBuf = 0;
  for (i = 0; i < 15; i++) {
    localDW->FIR_IMUaccel_states[i] = localP->FIR_IMUaccel_InitialStates;
  }

  /* End of InitializeConditions for DiscreteFir: '<S45>/FIR_IMUaccel' */

  /* InitializeConditions for DiscreteTransferFcn: '<S45>/LPF Fcutoff = 40Hz1' */
  localDW->LPFFcutoff40Hz1_states = localP->LPFFcutoff40Hz1_InitialStates;

  /* InitializeConditions for DiscreteTransferFcn: '<S45>/LPF Fcutoff = 40Hz' */
  localDW->LPFFcutoff40Hz_states = localP->LPFFcutoff40Hz_InitialStates;

  /* InitializeConditions for DiscreteFilter: '<S45>/IIR_IMUgyro_r' */
  for (i = 0; i < 5; i++) {
    localDW->IIR_IMUgyro_r_states[i] = localP->IIR_IMUgyro_r_InitialStates;
  }

  /* End of InitializeConditions for DiscreteFilter: '<S45>/IIR_IMUgyro_r' */

  /* InitializeConditions for UnitDelay: '<S215>/Output' */
  localDW->Output_DSTATE = localP->Output_InitialCondition;

  /* InitializeConditions for Delay: '<S42>/MemoryX' */
  localDW->icLoad = 1U;

  /* InitializeConditions for Delay: '<S103>/MemoryX' */
  localDW->icLoad_p = 1U;

  /* InitializeConditions for Delay: '<S51>/MemoryX' */
  localDW->icLoad_i = 1U;

  /* InitializeConditions for Delay: '<S17>/Delay2' */
  for (i = 0; i < 6; i++) {
    localDW->Delay2_DSTATE[i] = localP->Delay2_InitialCondition;
  }

  /* End of InitializeConditions for Delay: '<S17>/Delay2' */

  /* InitializeConditions for DiscreteIntegrator: '<S26>/Integrator' */
  localDW->Integrator_DSTATE = localB->Constant;
  if (localDW->Integrator_DSTATE >= localP->Integrator_UpperSat) {
    localDW->Integrator_DSTATE = localP->Integrator_UpperSat;
  } else {
    if (localDW->Integrator_DSTATE <= localP->Integrator_LowerSat) {
      localDW->Integrator_DSTATE = localP->Integrator_LowerSat;
    }
  }

  localDW->Integrator_PrevResetState = 0;

  /* End of InitializeConditions for DiscreteIntegrator: '<S26>/Integrator' */

  /* InitializeConditions for DiscreteIntegrator: '<S32>/Integrator' */
  localDW->Integrator_PrevResetState_o = 0;
  localDW->Integrator_DSTATE_f[0] = localB->Constant_k;
  if (localDW->Integrator_DSTATE_f[0] >= localP->Integrator_UpperSat_o) {
    localDW->Integrator_DSTATE_f[0] = localP->Integrator_UpperSat_o;
  } else {
    if (localDW->Integrator_DSTATE_f[0] <= localP->Integrator_LowerSat_p) {
      localDW->Integrator_DSTATE_f[0] = localP->Integrator_LowerSat_p;
    }
  }

  /* InitializeConditions for DiscreteIntegrator: '<S38>/Integrator' */
  localDW->Integrator_DSTATE_m[0] = localB->Constant_c;
  if (localDW->Integrator_DSTATE_m[0] >= localP->Integrator_UpperSat_l) {
    localDW->Integrator_DSTATE_m[0] = localP->Integrator_UpperSat_l;
  } else {
    if (localDW->Integrator_DSTATE_m[0] <= localP->Integrator_LowerSat_c) {
      localDW->Integrator_DSTATE_m[0] = localP->Integrator_LowerSat_c;
    }
  }

  /* InitializeConditions for DiscreteIntegrator: '<S32>/Integrator' */
  localDW->Integrator_DSTATE_f[1] = localB->Constant_k;
  if (localDW->Integrator_DSTATE_f[1] >= localP->Integrator_UpperSat_o) {
    localDW->Integrator_DSTATE_f[1] = localP->Integrator_UpperSat_o;
  } else {
    if (localDW->Integrator_DSTATE_f[1] <= localP->Integrator_LowerSat_p) {
      localDW->Integrator_DSTATE_f[1] = localP->Integrator_LowerSat_p;
    }
  }

  /* InitializeConditions for DiscreteIntegrator: '<S38>/Integrator' */
  localDW->Integrator_DSTATE_m[1] = localB->Constant_c;
  if (localDW->Integrator_DSTATE_m[1] >= localP->Integrator_UpperSat_l) {
    localDW->Integrator_DSTATE_m[1] = localP->Integrator_UpperSat_l;
  } else {
    if (localDW->Integrator_DSTATE_m[1] <= localP->Integrator_LowerSat_c) {
      localDW->Integrator_DSTATE_m[1] = localP->Integrator_LowerSat_c;
    }
  }

  /* InitializeConditions for DiscreteIntegrator: '<S32>/Integrator' */
  localDW->Integrator_DSTATE_f[2] = localB->Constant_k;
  if (localDW->Integrator_DSTATE_f[2] >= localP->Integrator_UpperSat_o) {
    localDW->Integrator_DSTATE_f[2] = localP->Integrator_UpperSat_o;
  } else {
    if (localDW->Integrator_DSTATE_f[2] <= localP->Integrator_LowerSat_p) {
      localDW->Integrator_DSTATE_f[2] = localP->Integrator_LowerSat_p;
    }
  }

  /* InitializeConditions for DiscreteIntegrator: '<S38>/Integrator' */
  localDW->Integrator_DSTATE_m[2] = localB->Constant_c;
  if (localDW->Integrator_DSTATE_m[2] >= localP->Integrator_UpperSat_l) {
    localDW->Integrator_DSTATE_m[2] = localP->Integrator_UpperSat_l;
  } else {
    if (localDW->Integrator_DSTATE_m[2] <= localP->Integrator_LowerSat_c) {
      localDW->Integrator_DSTATE_m[2] = localP->Integrator_LowerSat_c;
    }
  }

  localDW->Integrator_PrevResetState_l = 0;

  /* SystemInitialize for Triggered SubSystem: '<S212>/Triggered Subsystem' */
  /* SystemInitialize for Outport: '<S216>/Out1' incorporates:
   *  Inport: '<S216>/In1'
   */
  localB->In1 = localP->Out1_Y0;

  /* End of SystemInitialize for SubSystem: '<S212>/Triggered Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S182>/Enabled Subsystem' */
  for (i = 0; i < 6; i++) {
    /* SystemInitialize for Product: '<S206>/Product2' incorporates:
     *  Outport: '<S206>/deltax'
     */
    localB->Product2[i] = localP->deltax_Y0;
  }

  /* End of SystemInitialize for SubSystem: '<S182>/Enabled Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S130>/Enabled Subsystem' */
  flightControlSystem_EnabledSubsystem_Init(&localB->EnabledSubsystem_m,
    &localP->EnabledSubsystem_m);

  /* End of SystemInitialize for SubSystem: '<S130>/Enabled Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S78>/Enabled Subsystem' */
  flightControlSystem_EnabledSubsystem_Init(&localB->EnabledSubsystem,
    &localP->EnabledSubsystem);

  /* End of SystemInitialize for SubSystem: '<S78>/Enabled Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S175>/MeasurementUpdate' */
  for (i = 0; i < 6; i++) {
    /* SystemInitialize for Product: '<S204>/Product3' incorporates:
     *  Outport: '<S204>/L*(y[k]-yhat[k|k-1])'
     */
    localB->Product3[i] = localP->Lykyhatkk1_Y0;
  }

  /* End of SystemInitialize for SubSystem: '<S175>/MeasurementUpdate' */

  /* SystemInitialize for Enabled SubSystem: '<S123>/MeasurementUpdate' */
  flightControlSystem_MeasurementUpdate_Init(&localB->MeasurementUpdate_o,
    &localP->MeasurementUpdate_o);

  /* End of SystemInitialize for SubSystem: '<S123>/MeasurementUpdate' */

  /* SystemInitialize for Enabled SubSystem: '<S71>/MeasurementUpdate' */
  flightControlSystem_MeasurementUpdate_Init(&localB->MeasurementUpdate,
    &localP->MeasurementUpdate);

  /* End of SystemInitialize for SubSystem: '<S71>/MeasurementUpdate' */
}

/* Start for atomic system: '<Root>/Flight Control System' */
void flightControlSystem_FlightControlSystem_Start
  (RT_MODEL_flightControlSystem_T * const flightControlSystem_M,
   B_FlightControlSystem_flightControlSystem_T *localB,
   DW_FlightControlSystem_flightControlSystem_T *localDW,
   P_FlightControlSystem_flightControlSystem_T *localP)
{
  char_T *sErr;

  /* Start for S-Function (sdspFromNetwork): '<S4>/UDP Receive1' */
  sErr = GetErrorBuffer(&localDW->UDPReceive1_NetworkLib[0U]);
  CreateUDPInterface(&localDW->UDPReceive1_NetworkLib[0U]);
  if (*sErr == 0) {
    LibCreate_Network(&localDW->UDPReceive1_NetworkLib[0U], 0, "0.0.0.0",
                      localP->UDPReceive1_Port, "0.0.0.0", -1, 8192, 8, 0);
  }

  if (*sErr == 0) {
    LibStart(&localDW->UDPReceive1_NetworkLib[0U]);
  }

  if (*sErr != 0) {
    DestroyUDPInterface(&localDW->UDPReceive1_NetworkLib[0U]);
    if (*sErr != 0) {
      rtmSetErrorStatus(flightControlSystem_M, sErr);
      rtmSetStopRequested(flightControlSystem_M, 1);
    }
  }

  /* End of Start for S-Function (sdspFromNetwork): '<S4>/UDP Receive1' */

  /* Start for Enabled SubSystem: '<S182>/Enabled Subsystem' */
  localDW->EnabledSubsystem_MODE = false;

  /* End of Start for SubSystem: '<S182>/Enabled Subsystem' */

  /* Start for Enabled SubSystem: '<S130>/Enabled Subsystem' */
  flightControlSystem_EnabledSubsystem_Start(&localDW->EnabledSubsystem_m);

  /* End of Start for SubSystem: '<S130>/Enabled Subsystem' */

  /* Start for Enabled SubSystem: '<S78>/Enabled Subsystem' */
  flightControlSystem_EnabledSubsystem_Start(&localDW->EnabledSubsystem);

  /* End of Start for SubSystem: '<S78>/Enabled Subsystem' */

  /* Start for Probe: '<S21>/Probe' */
  localB->Probe[0] = 0.005;
  localB->Probe[1] = 0.0;

  /* Start for Constant: '<S25>/Constant' */
  localB->Constant = localP->LowPassFilterDiscreteorContinuous1_x0;

  /* Start for Probe: '<S27>/Probe' */
  localB->Probe_h[0] = 0.005;
  localB->Probe_h[1] = 0.0;

  /* Start for Constant: '<S31>/Constant' */
  localB->Constant_k = localP->LowPassFilterDiscreteorContinuous2_x0;

  /* Start for Enabled SubSystem: '<S175>/MeasurementUpdate' */
  localDW->MeasurementUpdate_MODE = false;

  /* End of Start for SubSystem: '<S175>/MeasurementUpdate' */

  /* Start for Probe: '<S33>/Probe' */
  localB->Probe_j[0] = 0.005;
  localB->Probe_j[1] = 0.0;

  /* Start for Constant: '<S37>/Constant' */
  localB->Constant_c = localP->LowPassFilterDiscreteorContinuous3_x0;

  /* Start for Enabled SubSystem: '<S123>/MeasurementUpdate' */
  flightControlSystem_MeasurementUpdate_Start(&localDW->MeasurementUpdate_o);

  /* End of Start for SubSystem: '<S123>/MeasurementUpdate' */

  /* Start for Enabled SubSystem: '<S71>/MeasurementUpdate' */
  flightControlSystem_MeasurementUpdate_Start(&localDW->MeasurementUpdate);

  /* End of Start for SubSystem: '<S71>/MeasurementUpdate' */
}

/* Outputs for atomic system: '<Root>/Flight Control System' */
void flightControlSystem_FlightControlSystem(RT_MODEL_flightControlSystem_T *
  const flightControlSystem_M, const CommandBus *rtu_ReferenceValueServerCmds,
  const SensorsBus *rtu_Sensors, B_FlightControlSystem_flightControlSystem_T
  *localB, DW_FlightControlSystem_flightControlSystem_T *localDW,
  P_FlightControlSystem_flightControlSystem_T *localP,
  ZCE_FlightControlSystem_flightControlSystem_T *localZCE)
{
  /* local block i/o variables */
  uint32_T rtb_Output;
  real32_T rtb_single1;
  real32_T rtb_DataTypeConversion1_b;
  real32_T rtb_Conversion_j;
  real32_T rtb_Conversion_lf;
  real32_T rtb_Conversion_n;
  boolean_T rtb_DataTypeConversionEnable;
  boolean_T rtb_DataTypeConversionEnable_f;
  static const real_T a[9] = { 6.123233995736766E-17, -1.0, -0.0, 1.0,
    6.123233995736766E-17, 0.0, 0.0, -0.0, 1.0 };

  static const real_T p[8] = { -0.1563, 1.0938, -2.625, 2.1875, 0.0, 0.0, 0.0,
    0.0 };

  static const int8_T b[36] = { -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1,
    0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1 };

  char_T *sErr;
  int8_T x_tmp[3];
  boolean_T rtb_Compare;
  for (localB->i = 0; localB->i < 18; localB->i++) {
    /* DataTypeConversion: '<S199>/Conversion' incorporates:
     *  Constant: '<S155>/KalmanGainM'
     */
    localB->Conversion[localB->i] = (real32_T)localP->KalmanGainM_Value
      [localB->i];
  }

  for (localB->i = 0; localB->i < 18; localB->i++) {
    /* DataTypeConversion: '<S198>/Conversion' incorporates:
     *  Constant: '<S155>/KalmanGainL'
     */
    localB->Conversion_b[localB->i] = (real32_T)localP->KalmanGainL_Value
      [localB->i];
  }

  /* Constant: '<S10>/TorqueTotalThrustToThrustPerMotor' */
  memcpy(&localB->TorqueTotalThrustToThrustPerMotor[0],
         &localP->TorqueTotalThrustToThrustPerMotor_Value[0], sizeof(real32_T) <<
         4U);

  /* Delay: '<S44>/Delay' */
  for (localB->i = 0; localB->i < 9; localB->i++) {
    localB->Delay[localB->i] = localDW->Delay_DSTATE[localB->i];
  }

  /* End of Delay: '<S44>/Delay' */

  /* S-Function (sdspFromNetwork): '<S4>/UDP Receive1' */
  sErr = GetErrorBuffer(&localDW->UDPReceive1_NetworkLib[0U]);
  localB->samplesRead = 4;
  LibOutputs_Network(&localDW->UDPReceive1_NetworkLib[0U],
                     &localB->UDPReceive1_o1[0U], &localB->samplesRead);
  if (*sErr != 0) {
    rtmSetErrorStatus(flightControlSystem_M, sErr);
    rtmSetStopRequested(flightControlSystem_M, 1);
  }

  /* S-Function (sdspFromNetwork): '<S4>/UDP Receive1' */
  localB->UDPReceive1_o2 = (uint16_T)localB->samplesRead;

  /* DataTypeConversion: '<S4>/Data Type Conversion' incorporates:
   *  S-Function (sdspFromNetwork): '<S4>/UDP Receive1'
   */
  localB->DataTypeConversion[0] = (real32_T)localB->UDPReceive1_o1[0];
  localB->DataTypeConversion[1] = (real32_T)localB->UDPReceive1_o1[1];
  localB->DataTypeConversion[2] = (real32_T)localB->UDPReceive1_o1[2];
  localB->DataTypeConversion[3] = (real32_T)localB->UDPReceive1_o1[3];

  /* Gain: '<S4>/Gain1' */
  localB->Gain1 = localP->Gain1_Gain * localB->DataTypeConversion[1];

  /* Gain: '<S4>/Gain' */
  localB->Gain = localP->Gain_Gain_m * localB->DataTypeConversion[2];

  /* Bias: '<S45>/Assuming that the  preflight calibration was done at level orientation' incorporates:
   *  DataTypeConversion: '<S45>/Data Type Conversion'
   */
  for (localB->i = 0; localB->i < 6; localB->i++) {
    localB->Add[localB->i] = rtu_Sensors->SensorCalibration[localB->i] +
      localP->
      Assumingthatthepreflightcalibrationwasdoneatlevelorientation_Bi[localB->i];
  }

  /* End of Bias: '<S45>/Assuming that the  preflight calibration was done at level orientation' */

  /* Sum: '<S45>/Sum1' */
  localB->rtb_Add_l = localB->Add[0];
  localB->rtb_Add_d = localB->Add[1];
  localB->r = localB->Add[2];
  localB->sy = localB->Add[3];
  localB->rtb_Add_dy = localB->Add[4];
  localB->rtb_Add_lx = localB->Add[5];
  localB->Add[0] = rtu_Sensors->HALSensors.HAL_acc_SI.x - localB->rtb_Add_l;
  localB->Add[1] = rtu_Sensors->HALSensors.HAL_acc_SI.y - localB->rtb_Add_d;
  localB->Add[2] = rtu_Sensors->HALSensors.HAL_acc_SI.z - localB->r;
  localB->Add[3] = rtu_Sensors->HALSensors.HAL_gyro_SI.x - localB->sy;
  localB->Add[4] = rtu_Sensors->HALSensors.HAL_gyro_SI.y - localB->rtb_Add_dy;
  localB->Add[5] = rtu_Sensors->HALSensors.HAL_gyro_SI.z - localB->rtb_Add_lx;
  for (localB->i = 0; localB->i < 6; localB->i++) {
    /* Gain: '<S45>/inverseIMU_gain' */
    localB->inverseIMU_gain[localB->i] = localP->inverseIMU_gain_Gain[localB->i]
      * localB->Add[localB->i];
  }

  /* DiscreteFir: '<S45>/FIR_IMUaccel' */
  localB->rtb_Add_l = localB->inverseIMU_gain[0] *
    localP->FIR_IMUaccel_Coefficients[0];
  localB->i = 1;
  localB->j = localDW->FIR_IMUaccel_circBuf;
  while (localB->j < 5) {
    localB->rtb_Add_l += localDW->FIR_IMUaccel_states[localB->j] *
      localP->FIR_IMUaccel_Coefficients[localB->i];
    localB->i++;
    localB->j++;
  }

  localB->j = 0;
  while (localB->j < localDW->FIR_IMUaccel_circBuf) {
    localB->rtb_Add_l += localDW->FIR_IMUaccel_states[localB->j] *
      localP->FIR_IMUaccel_Coefficients[localB->i];
    localB->i++;
    localB->j++;
  }

  localB->FIR_IMUaccel[0] = localB->rtb_Add_l;
  localB->rtb_Add_l = localB->inverseIMU_gain[1] *
    localP->FIR_IMUaccel_Coefficients[0];
  localB->i = 1;
  localB->j = localDW->FIR_IMUaccel_circBuf;
  while (localB->j < 5) {
    localB->rtb_Add_l += localDW->FIR_IMUaccel_states[localB->j + 5] *
      localP->FIR_IMUaccel_Coefficients[localB->i];
    localB->i++;
    localB->j++;
  }

  localB->j = 0;
  while (localB->j < localDW->FIR_IMUaccel_circBuf) {
    localB->rtb_Add_l += localDW->FIR_IMUaccel_states[localB->j + 5] *
      localP->FIR_IMUaccel_Coefficients[localB->i];
    localB->i++;
    localB->j++;
  }

  localB->FIR_IMUaccel[1] = localB->rtb_Add_l;
  localB->rtb_Add_l = localB->inverseIMU_gain[2] *
    localP->FIR_IMUaccel_Coefficients[0];
  localB->i = 1;
  localB->j = localDW->FIR_IMUaccel_circBuf;
  while (localB->j < 5) {
    localB->rtb_Add_l += localDW->FIR_IMUaccel_states[localB->j + 10] *
      localP->FIR_IMUaccel_Coefficients[localB->i];
    localB->i++;
    localB->j++;
  }

  localB->j = 0;
  while (localB->j < localDW->FIR_IMUaccel_circBuf) {
    localB->rtb_Add_l += localDW->FIR_IMUaccel_states[localB->j + 10] *
      localP->FIR_IMUaccel_Coefficients[localB->i];
    localB->i++;
    localB->j++;
  }

  localB->FIR_IMUaccel[2] = localB->rtb_Add_l;

  /* End of DiscreteFir: '<S45>/FIR_IMUaccel' */

  /* MATLAB Function: '<S44>/MATLAB Function' incorporates:
   *  MATLAB Function: '<S2>/MATLAB Function2'
   *  MATLAB Function: '<S4>/MATLAB Function'
   *  SignalConversion generated from: '<S207>/ SFunction '
   */
  localB->rtb_Add_l = localB->FIR_IMUaccel[2] * localB->FIR_IMUaccel[2];
  localB->st[1] = atanf(localB->FIR_IMUaccel[0] / (localB->FIR_IMUaccel[1] *
    localB->FIR_IMUaccel[1] + localB->rtb_Add_l));
  localB->st[2] = atanf(localB->FIR_IMUaccel[1] / (localB->FIR_IMUaccel[0] *
    localB->FIR_IMUaccel[0] + localB->rtb_Add_l));
  localB->rtb_Add_l = sinf(localB->DataTypeConversion[3]);
  localB->rtb_Add_d = cosf(localB->DataTypeConversion[3]);
  localB->ct[1] = cosf(localB->st[1]);
  localB->st[1] = sinf(localB->st[1]);
  localB->r = cosf(localB->st[2]);
  localB->sy = sinf(localB->st[2]);
  localB->y_a[0] = localB->ct[1] * localB->rtb_Add_d;
  localB->rtb_Add_dy = localB->sy * localB->st[1];
  localB->y_a[3] = localB->rtb_Add_dy * localB->rtb_Add_d - localB->r *
    localB->rtb_Add_l;
  localB->rtb_Add_lx = localB->r * localB->st[1];
  localB->y_a[6] = localB->rtb_Add_lx * localB->rtb_Add_d + localB->sy *
    localB->rtb_Add_l;
  localB->y_a[1] = localB->ct[1] * localB->rtb_Add_l;
  localB->y_a[4] = localB->rtb_Add_dy * localB->rtb_Add_l + localB->r *
    localB->rtb_Add_d;
  localB->y_a[7] = localB->rtb_Add_lx * localB->rtb_Add_l - localB->sy *
    localB->rtb_Add_d;
  localB->y_a[2] = -localB->st[1];
  localB->y_a[5] = localB->sy * localB->ct[1];
  localB->y_a[8] = localB->r * localB->ct[1];

  /* MATLAB Function: '<S44>/MATLAB Function2' incorporates:
   *  Delay: '<S44>/Delay'
   */
  for (localB->j = 0; localB->j < 3; localB->j++) {
    for (localB->i = 0; localB->i < 3; localB->i++) {
      localB->Rw_tmp = localB->i + 3 * localB->j;
      localB->Rw[localB->Rw_tmp] = 0.0F;
      localB->Rw[localB->Rw_tmp] += localB->Delay[3 * localB->i] * localB->y_a[3
        * localB->j];
      localB->Rw[localB->Rw_tmp] += localB->Delay[3 * localB->i + 1] *
        localB->y_a[3 * localB->j + 1];
      localB->Rw[localB->Rw_tmp] += localB->Delay[3 * localB->i + 2] *
        localB->y_a[3 * localB->j + 2];
    }
  }

  /* DiscreteTransferFcn: '<S45>/LPF Fcutoff = 40Hz1' */
  localDW->LPFFcutoff40Hz1_tmp = (localB->inverseIMU_gain[3] -
    localP->LPFFcutoff40Hz1_DenCoef[1] * localDW->LPFFcutoff40Hz1_states) /
    localP->LPFFcutoff40Hz1_DenCoef[0];

  /* DiscreteTransferFcn: '<S45>/LPF Fcutoff = 40Hz1' */
  localB->p = localP->LPFFcutoff40Hz1_NumCoef[0] * localDW->LPFFcutoff40Hz1_tmp
    + localP->LPFFcutoff40Hz1_NumCoef[1] * localDW->LPFFcutoff40Hz1_states;

  /* DiscreteTransferFcn: '<S45>/LPF Fcutoff = 40Hz' */
  localDW->LPFFcutoff40Hz_tmp = (localB->inverseIMU_gain[4] -
    localP->LPFFcutoff40Hz_DenCoef[1] * localDW->LPFFcutoff40Hz_states) /
    localP->LPFFcutoff40Hz_DenCoef[0];

  /* DiscreteTransferFcn: '<S45>/LPF Fcutoff = 40Hz' */
  localB->q = localP->LPFFcutoff40Hz_NumCoef[0] * localDW->LPFFcutoff40Hz_tmp +
    localP->LPFFcutoff40Hz_NumCoef[1] * localDW->LPFFcutoff40Hz_states;

  /* DiscreteFilter: '<S45>/IIR_IMUgyro_r' */
  localDW->IIR_IMUgyro_r_tmp = 0.0F;
  localB->r = localB->inverseIMU_gain[5];
  localB->i = 1;
  for (localB->j = 0; localB->j < 5; localB->j++) {
    localB->r -= localP->IIR_IMUgyro_r_DenCoef[localB->i] *
      localDW->IIR_IMUgyro_r_states[localB->j];
    localB->i++;
  }

  localDW->IIR_IMUgyro_r_tmp = localB->r / localP->IIR_IMUgyro_r_DenCoef[0];
  localB->r = localP->IIR_IMUgyro_r_NumCoef[0] * localDW->IIR_IMUgyro_r_tmp;
  localB->i = 1;
  for (localB->j = 0; localB->j < 5; localB->j++) {
    localB->r += localP->IIR_IMUgyro_r_NumCoef[localB->i] *
      localDW->IIR_IMUgyro_r_states[localB->j];
    localB->i++;
  }

  /* UnitDelay: '<S215>/Output' */
  rtb_Output = localDW->Output_DSTATE;

  /* RelationalOperator: '<S214>/Compare' incorporates:
   *  Constant: '<S214>/Constant'
   */
  rtb_Compare = (rtb_Output == localP->CompareToConstant_const_p);

  /* Outputs for Triggered SubSystem: '<S212>/Triggered Subsystem' incorporates:
   *  TriggerPort: '<S216>/Trigger'
   */
  if (((localZCE->TriggeredSubsystem_Trig_ZCE == 1) != (int32_T)rtb_Compare) &&
      (localZCE->TriggeredSubsystem_Trig_ZCE != 3)) {
    /* Inport: '<S216>/In1' */
    localB->In1 = rtu_Sensors->HALSensors.HAL_gyro_SI.temperature;
  }

  localZCE->TriggeredSubsystem_Trig_ZCE = rtb_Compare;

  /* End of Outputs for SubSystem: '<S212>/Triggered Subsystem' */

  /* ManualSwitch: '<S212>/Disable temperature compensation' incorporates:
   *  Constant: '<S212>/Constant'
   *  Gain: '<S212>/Gain'
   *  Sum: '<S212>/Subtract'
   */
  if (localP->Disabletemperaturecompensation_CurrentSetting == 1) {
    localB->scale = (rtu_Sensors->HALSensors.HAL_gyro_SI.temperature -
                     localB->In1) * localP->Gain_Gain;
  } else {
    localB->scale = localP->Constant_Value;
  }

  /* End of ManualSwitch: '<S212>/Disable temperature compensation' */

  /* Sum: '<S212>/Subtract1' incorporates:
   *  DataTypeConversion: '<S212>/Data Type Conversion1'
   *  DiscreteFilter: '<S45>/IIR_IMUgyro_r'
   */
  localB->r -= (real32_T)localB->scale;

  /* MATLAB Function: '<S44>/MATLAB Function1' incorporates:
   *  Delay: '<S44>/Delay'
   *  SignalConversion generated from: '<S208>/ SFunction '
   */
  for (localB->j = 0; localB->j < 3; localB->j++) {
    localB->ct[localB->j] = localB->Delay[localB->j + 6] * localB->r +
      (localB->Delay[localB->j + 3] * localB->q + localB->Delay[localB->j] *
       localB->p);
  }

  localB->y_a[0] = 0.0F;
  localB->y_a[3] = -localB->ct[2];
  localB->y_a[6] = localB->ct[1];
  localB->y_a[1] = localB->ct[2];
  localB->y_a[4] = 0.0F;
  localB->y_a[7] = -localB->ct[0];
  localB->y_a[2] = -localB->ct[1];
  localB->y_a[5] = localB->ct[0];
  localB->y_a[8] = 0.0F;

  /* End of MATLAB Function: '<S44>/MATLAB Function1' */
  for (localB->j = 0; localB->j < 3; localB->j++) {
    /* Sum: '<S44>/Sum' incorporates:
     *  Gain: '<S44>/Gain3'
     *  MATLAB Function: '<S44>/MATLAB Function2'
     */
    localB->fv1[3 * localB->j] = (localB->Rw[3 * localB->j] - localB->Rw
      [localB->j]) * 0.5F * localP->Gain3_Gain + localB->y_a[3 * localB->j];

    /* MATLAB Function: '<S44>/MATLAB Function2' incorporates:
     *  MATLAB Function: '<S44>/MATLAB Function3'
     *  Sum: '<S44>/Sum'
     */
    localB->i = 3 * localB->j + 1;

    /* Sum: '<S44>/Sum' incorporates:
     *  Gain: '<S44>/Gain3'
     *  MATLAB Function: '<S44>/MATLAB Function2'
     */
    localB->fv1[localB->i] = (localB->Rw[localB->i] - localB->Rw[localB->j + 3])
      * 0.5F * localP->Gain3_Gain + localB->y_a[localB->i];

    /* MATLAB Function: '<S44>/MATLAB Function2' incorporates:
     *  MATLAB Function: '<S44>/MATLAB Function3'
     *  Sum: '<S44>/Sum'
     */
    localB->Rw_tmp = 3 * localB->j + 2;

    /* Sum: '<S44>/Sum' incorporates:
     *  Gain: '<S44>/Gain3'
     *  MATLAB Function: '<S44>/MATLAB Function2'
     */
    localB->fv1[localB->Rw_tmp] = (localB->Rw[localB->Rw_tmp] - localB->
      Rw[localB->j + 6]) * 0.5F * localP->Gain3_Gain + localB->y_a
      [localB->Rw_tmp];

    /* MATLAB Function: '<S44>/MATLAB Function3' incorporates:
     *  Delay: '<S44>/Delay'
     */
    for (localB->b_tmp = 0; localB->b_tmp < 3; localB->b_tmp++) {
      localB->rtb_Delay_tmp = localB->b_tmp + 3 * localB->j;
      localB->rtb_Delay_k[localB->rtb_Delay_tmp] = 0.0F;
      localB->rtb_Delay_k[localB->rtb_Delay_tmp] += localB->fv1[3 * localB->j] *
        localB->Delay[localB->b_tmp];
      localB->rtb_Delay_k[localB->rtb_Delay_tmp] += localB->fv1[localB->i] *
        localB->Delay[localB->b_tmp + 3];
      localB->rtb_Delay_k[localB->rtb_Delay_tmp] += localB->fv1[localB->Rw_tmp] *
        localB->Delay[localB->b_tmp + 6];
    }
  }

  /* MATLAB Function: '<S44>/MATLAB Function3' incorporates:
   *  Delay: '<S44>/Delay'
   */
  for (localB->j = 0; localB->j < 9; localB->j++) {
    localB->DataTypeConversion1[localB->j] = localB->rtb_Delay_k[localB->j] *
      0.005F + localB->Delay[localB->j];
  }

  /* MATLAB Function: '<S44>/MATLAB Function4' */
  localB->sy = sqrtf(localB->DataTypeConversion1[0] *
                     localB->DataTypeConversion1[0] +
                     localB->DataTypeConversion1[1] *
                     localB->DataTypeConversion1[1]);
  localB->rtb_y_idx_0 = rt_atan2f_snf(localB->DataTypeConversion1[5],
    localB->DataTypeConversion1[8]);
  localB->rtb_y_idx_1 = rt_atan2f_snf(-localB->DataTypeConversion1[2],
    localB->sy);
  if (localB->sy < 1.1920929E-6F) {
    localB->tmp_size[0] = 1;
    localB->tmp_size[1] = 1;
    localB->tmp_size[2] = 1;
    localB->tmp_size_p[0] = 1;
    localB->tmp_size_p[1] = 1;
    localB->tmp_size_p[2] = 1;
    localB->tmp_size_f[0] = 1;
    localB->tmp_size_f[1] = 1;
    localB->tmp_size_f[2] = 1;
    localB->tmp_data_o = -localB->DataTypeConversion1[7];
    localB->tmp_data_b = localB->DataTypeConversion1[4];
    localB->tmp_data_bs = -localB->DataTypeConversion1[2];
    flightControlSystem_atan2(&localB->tmp_data_o, localB->tmp_size,
      &localB->tmp_data_b, localB->tmp_size_p, &localB->tmp_data_n,
      localB->tmp_size_c);
    localB->sy_size[0] = 1;
    localB->sy_size[1] = 1;
    localB->sy_size[2] = 1;
    localB->tmp_data_b = localB->sy;
    flightControlSystem_atan2(&localB->tmp_data_bs, localB->tmp_size_f,
      &localB->tmp_data_b, localB->sy_size, &localB->tmp_data_o,
      localB->tmp_size);
    localB->i = localB->tmp_size_c[2];
    for (localB->j = 0; localB->j < localB->i; localB->j++) {
      localB->rtb_y_idx_0 = localB->tmp_data_n;
    }

    localB->i = localB->tmp_size[2];
    for (localB->j = 0; localB->j < localB->i; localB->j++) {
      localB->rtb_y_idx_1 = localB->tmp_data_o;
    }
  }

  /* DigitalClock: '<S3>/Digital Clock' */
  localB->DigitalClock = flightControlSystem_M->Timing.taskTime0;

  /* MATLAB Function: '<S2>/MATLAB Function2' incorporates:
   *  MATLAB Function: '<S44>/MATLAB Function4'
   *  MATLAB Function: '<S4>/MATLAB Function'
   */
  localB->sy = sinf(localB->rtb_y_idx_1);
  localB->rtb_Add_dy = cosf(localB->rtb_y_idx_1);
  localB->rtb_Add_lx = cosf(localB->rtb_y_idx_0);
  localB->st_tmp_d = sinf(localB->rtb_y_idx_0);
  localB->R[0] = localB->rtb_Add_dy * localB->rtb_Add_d;
  localB->Gain1_g = localB->st_tmp_d * localB->sy;
  localB->R[3] = localB->Gain1_g * localB->rtb_Add_d - localB->rtb_Add_lx *
    localB->rtb_Add_l;
  localB->DataTypeConversion_p = localB->rtb_Add_lx * localB->sy;
  localB->R[6] = localB->DataTypeConversion_p * localB->rtb_Add_d +
    localB->st_tmp_d * localB->rtb_Add_l;
  localB->R[1] = localB->rtb_Add_dy * localB->rtb_Add_l;
  localB->R[4] = localB->Gain1_g * localB->rtb_Add_l + localB->rtb_Add_lx *
    localB->rtb_Add_d;
  localB->R[7] = localB->DataTypeConversion_p * localB->rtb_Add_l -
    localB->st_tmp_d * localB->rtb_Add_d;
  localB->R[2] = -localB->sy;
  localB->R[5] = localB->st_tmp_d * localB->rtb_Add_dy;
  localB->R[8] = localB->rtb_Add_lx * localB->rtb_Add_dy;

  /* MATLAB Function: '<S3>/MATLAB Function' incorporates:
   *  Constant: '<S3>/Constant'
   */
  if (localP->Constant_Value_e == 0.0) {
    if (localB->DigitalClock < 2.0) {
      localB->rtb_b1d_idx_2 = -0.1563;
      for (localB->j = 0; localB->j < 7; localB->j++) {
        localB->rtb_b1d_idx_2 = localB->DigitalClock * localB->rtb_b1d_idx_2 +
          p[localB->j + 1];
      }

      localB->xd[0] = 0.0;
      localB->xd[1] = 0.0;
      localB->xd[2] = -localB->rtb_b1d_idx_2;
      flightControlSystem_polyder(localB->i_data, localB->i_size);
      localB->scale = flightControlSystem_polyval(localB->i_data, localB->i_size,
        localB->DigitalClock);
      localB->xd_1dot[0] = 0.0;
      localB->xd_1dot[1] = 0.0;
      localB->xd_1dot[2] = -localB->scale;
      flightControlSystem_polyder_i(localB->i_data, localB->i_size,
        localB->tmp_data_c, localB->tmp_size_m);
      localB->scale = flightControlSystem_polyval(localB->tmp_data_c,
        localB->tmp_size_m, localB->DigitalClock);
      localB->xd_2dot[0] = 0.0;
      localB->xd_2dot[1] = 0.0;
      localB->xd_2dot[2] = -localB->scale;
    } else {
      localB->xd[0] = 0.0;
      localB->xd_1dot[0] = 0.0;
      localB->xd_2dot[0] = 0.0;
      localB->xd[1] = 0.0;
      localB->xd_1dot[1] = 0.0;
      localB->xd_2dot[1] = 0.0;
      localB->xd[2] = -1.0;
      localB->xd_1dot[2] = 0.0;
      localB->xd_2dot[2] = 0.0;
    }
  } else if (localP->Constant_Value_e == 1.0) {
    if (localB->DigitalClock < 2.0) {
      localB->rtb_b1d_idx_2 = -0.1563;
      for (localB->j = 0; localB->j < 7; localB->j++) {
        localB->rtb_b1d_idx_2 = localB->DigitalClock * localB->rtb_b1d_idx_2 +
          p[localB->j + 1];
      }

      localB->xd[0] = 0.0;
      localB->xd[1] = 0.0;
      localB->xd[2] = -localB->rtb_b1d_idx_2;
      flightControlSystem_polyder(localB->tmp_data, localB->tmp_size_m);
      localB->scale = flightControlSystem_polyval(localB->tmp_data,
        localB->tmp_size_m, localB->DigitalClock);
      localB->xd_1dot[0] = 0.0;
      localB->xd_1dot[1] = 0.0;
      localB->xd_1dot[2] = -localB->scale;
      flightControlSystem_polyder(localB->tmp_data, localB->tmp_size_m);
      flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
        localB->tmp_data_c, localB->tmp_size_n);
      localB->scale = flightControlSystem_polyval(localB->tmp_data_c,
        localB->tmp_size_n, localB->DigitalClock);
      localB->xd_2dot[0] = 0.0;
      localB->xd_2dot[1] = 0.0;
      localB->xd_2dot[2] = -localB->scale;
    } else if (localB->DigitalClock < 5.0) {
      localB->xd[0] = 0.0;
      localB->xd_1dot[0] = 0.0;
      localB->xd_2dot[0] = 0.0;
      localB->xd[1] = 0.0;
      localB->xd_1dot[1] = 0.0;
      localB->xd_2dot[1] = 0.0;
      localB->xd[2] = -1.0;
      localB->xd_1dot[2] = 0.0;
      localB->xd_2dot[2] = 0.0;
    } else if (localB->DigitalClock < flightControlSystem_P.polytraj[0] + 5.0) {
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1) *
          6];
      }

      flightControlSystem_flip(localB->f);
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->g[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9) *
          6];
      }

      flightControlSystem_flip(localB->g);
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->h[localB->j] = flightControlSystem_P.polytraj[(localB->j + 17) *
          6];
      }

      flightControlSystem_flip(localB->h);
      localB->xd[0] = flightControlSystem_polyval_f(localB->f,
        localB->DigitalClock - 5.0);
      localB->xd[1] = flightControlSystem_polyval_f(localB->g,
        localB->DigitalClock - 5.0);
      localB->xd[2] = flightControlSystem_polyval_f(localB->h,
        localB->DigitalClock - 5.0);
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1) *
          6];
      }

      flightControlSystem_flip(localB->f);
      flightControlSystem_polyder_iv(localB->f, localB->i_data, localB->i_size);
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9) *
          6];
      }

      flightControlSystem_flip(localB->f);
      flightControlSystem_polyder_iv(localB->f, localB->j_data, localB->j_size);
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 17) *
          6];
      }

      flightControlSystem_flip(localB->f);
      flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
        localB->tmp_size_m);
      localB->xd_1dot[0] = flightControlSystem_polyval(localB->i_data,
        localB->i_size, localB->DigitalClock - 5.0);
      localB->xd_1dot[1] = flightControlSystem_polyval(localB->j_data,
        localB->j_size, localB->DigitalClock - 5.0);
      localB->xd_1dot[2] = flightControlSystem_polyval(localB->tmp_data,
        localB->tmp_size_m, localB->DigitalClock - 5.0);
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1) *
          6];
      }

      flightControlSystem_flip(localB->f);
      flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
        localB->tmp_size_m);
      flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
        localB->DTC3, localB->i_size);
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9) *
          6];
      }

      flightControlSystem_flip(localB->f);
      flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
        localB->tmp_size_m);
      flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
        localB->n_data, localB->j_size);
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 17) *
          6];
      }

      flightControlSystem_flip(localB->f);
      flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
        localB->tmp_size_m);
      flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
        localB->tmp_data_c, localB->tmp_size_n);
      localB->xd_2dot[0] = flightControlSystem_polyval(localB->DTC3,
        localB->i_size, localB->DigitalClock - 5.0);
      localB->xd_2dot[1] = flightControlSystem_polyval(localB->n_data,
        localB->j_size, localB->DigitalClock - 5.0);
      localB->xd_2dot[2] = flightControlSystem_polyval(localB->tmp_data_c,
        localB->tmp_size_n, localB->DigitalClock - 5.0);
    } else {
      localB->scale = (flightControlSystem_P.polytraj[0] + 5.0) +
        flightControlSystem_P.polytraj[1];
      if (localB->DigitalClock < localB->scale) {
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1) *
            6 + 1];
        }

        flightControlSystem_flip(localB->f);
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->g[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9) *
            6 + 1];
        }

        flightControlSystem_flip(localB->g);
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->h[localB->j] = flightControlSystem_P.polytraj[(localB->j + 17)
            * 6 + 1];
        }

        flightControlSystem_flip(localB->h);
        localB->t = localB->DigitalClock - (flightControlSystem_P.polytraj[0] +
          5.0);
        localB->xd[0] = flightControlSystem_polyval_f(localB->f, localB->t);
        localB->xd[1] = flightControlSystem_polyval_f(localB->g, localB->t);
        localB->xd[2] = flightControlSystem_polyval_f(localB->h, localB->t);
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1) *
            6 + 1];
        }

        flightControlSystem_flip(localB->f);
        flightControlSystem_polyder_iv(localB->f, localB->i_data, localB->i_size);
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9) *
            6 + 1];
        }

        flightControlSystem_flip(localB->f);
        flightControlSystem_polyder_iv(localB->f, localB->j_data, localB->j_size);
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 17)
            * 6 + 1];
        }

        flightControlSystem_flip(localB->f);
        flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
          localB->tmp_size_m);
        localB->xd_1dot[0] = flightControlSystem_polyval(localB->i_data,
          localB->i_size, localB->t);
        localB->xd_1dot[1] = flightControlSystem_polyval(localB->j_data,
          localB->j_size, localB->t);
        localB->xd_1dot[2] = flightControlSystem_polyval(localB->tmp_data,
          localB->tmp_size_m, localB->t);
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1) *
            6 + 1];
        }

        flightControlSystem_flip(localB->f);
        flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
          localB->tmp_size_m);
        flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
          localB->DTC3, localB->i_size);
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9) *
            6 + 1];
        }

        flightControlSystem_flip(localB->f);
        flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
          localB->tmp_size_m);
        flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
          localB->n_data, localB->j_size);
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 17)
            * 6 + 1];
        }

        flightControlSystem_flip(localB->f);
        flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
          localB->tmp_size_m);
        flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
          localB->tmp_data_c, localB->tmp_size_n);
        localB->xd_2dot[0] = flightControlSystem_polyval(localB->DTC3,
          localB->i_size, localB->t);
        localB->xd_2dot[1] = flightControlSystem_polyval(localB->n_data,
          localB->j_size, localB->t);
        localB->xd_2dot[2] = flightControlSystem_polyval(localB->tmp_data_c,
          localB->tmp_size_n, localB->t);
      } else {
        localB->rtb_b1d_idx_2 = localB->scale + flightControlSystem_P.polytraj[2];
        if (localB->DigitalClock < localB->rtb_b1d_idx_2) {
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1)
              * 6 + 2];
          }

          flightControlSystem_flip(localB->f);
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->g[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9)
              * 6 + 2];
          }

          flightControlSystem_flip(localB->g);
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->h[localB->j] = flightControlSystem_P.polytraj[(localB->j +
              17) * 6 + 2];
          }

          flightControlSystem_flip(localB->h);
          localB->t = localB->DigitalClock - localB->scale;
          localB->xd[0] = flightControlSystem_polyval_f(localB->f, localB->t);
          localB->xd[1] = flightControlSystem_polyval_f(localB->g, localB->t);
          localB->xd[2] = flightControlSystem_polyval_f(localB->h, localB->t);
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1)
              * 6 + 2];
          }

          flightControlSystem_flip(localB->f);
          flightControlSystem_polyder_iv(localB->f, localB->i_data,
            localB->i_size);
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9)
              * 6 + 2];
          }

          flightControlSystem_flip(localB->f);
          flightControlSystem_polyder_iv(localB->f, localB->j_data,
            localB->j_size);
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
              17) * 6 + 2];
          }

          flightControlSystem_flip(localB->f);
          flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
            localB->tmp_size_m);
          localB->xd_1dot[0] = flightControlSystem_polyval(localB->i_data,
            localB->i_size, localB->t);
          localB->xd_1dot[1] = flightControlSystem_polyval(localB->j_data,
            localB->j_size, localB->t);
          localB->xd_1dot[2] = flightControlSystem_polyval(localB->tmp_data,
            localB->tmp_size_m, localB->t);
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1)
              * 6 + 2];
          }

          flightControlSystem_flip(localB->f);
          flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
            localB->tmp_size_m);
          flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
            localB->DTC3, localB->i_size);
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9)
              * 6 + 2];
          }

          flightControlSystem_flip(localB->f);
          flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
            localB->tmp_size_m);
          flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
            localB->n_data, localB->j_size);
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
              17) * 6 + 2];
          }

          flightControlSystem_flip(localB->f);
          flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
            localB->tmp_size_m);
          flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
            localB->tmp_data_c, localB->tmp_size_n);
          localB->xd_2dot[0] = flightControlSystem_polyval(localB->DTC3,
            localB->i_size, localB->t);
          localB->xd_2dot[1] = flightControlSystem_polyval(localB->n_data,
            localB->j_size, localB->t);
          localB->xd_2dot[2] = flightControlSystem_polyval(localB->tmp_data_c,
            localB->tmp_size_n, localB->t);
        } else {
          localB->scale = localB->rtb_b1d_idx_2 +
            flightControlSystem_P.polytraj[3];
          if (localB->DigitalClock < localB->scale) {
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                1) * 6 + 3];
            }

            flightControlSystem_flip(localB->f);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->g[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                9) * 6 + 3];
            }

            flightControlSystem_flip(localB->g);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->h[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                17) * 6 + 3];
            }

            flightControlSystem_flip(localB->h);
            localB->t = localB->DigitalClock - localB->rtb_b1d_idx_2;
            localB->xd[0] = flightControlSystem_polyval_f(localB->f, localB->t);
            localB->xd[1] = flightControlSystem_polyval_f(localB->g, localB->t);
            localB->xd[2] = flightControlSystem_polyval_f(localB->h, localB->t);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                1) * 6 + 3];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->i_data,
              localB->i_size);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                9) * 6 + 3];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->j_data,
              localB->j_size);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                17) * 6 + 3];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
              localB->tmp_size_m);
            localB->xd_1dot[0] = flightControlSystem_polyval(localB->i_data,
              localB->i_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
            localB->xd_1dot[1] = flightControlSystem_polyval(localB->j_data,
              localB->j_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
            localB->xd_1dot[2] = flightControlSystem_polyval(localB->tmp_data,
              localB->tmp_size_m, localB->t);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                1) * 6 + 3];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
              localB->tmp_size_m);
            flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
              localB->DTC3, localB->i_size);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                9) * 6 + 3];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
              localB->tmp_size_m);
            flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
              localB->n_data, localB->j_size);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                17) * 6 + 3];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
              localB->tmp_size_m);
            flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
              localB->tmp_data_c, localB->tmp_size_n);
            localB->xd_2dot[0] = flightControlSystem_polyval(localB->DTC3,
              localB->i_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
            localB->xd_2dot[1] = flightControlSystem_polyval(localB->n_data,
              localB->j_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
            localB->xd_2dot[2] = flightControlSystem_polyval(localB->tmp_data_c,
              localB->tmp_size_n, localB->t);
          } else {
            localB->rtb_b1d_idx_2 = localB->scale +
              flightControlSystem_P.polytraj[4];
            if (localB->DigitalClock < localB->rtb_b1d_idx_2) {
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 1) * 6 + 4];
              }

              flightControlSystem_flip(localB->f);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->g[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 9) * 6 + 4];
              }

              flightControlSystem_flip(localB->g);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->h[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 17) * 6 + 4];
              }

              flightControlSystem_flip(localB->h);
              localB->t = localB->DigitalClock - localB->scale;
              localB->xd[0] = flightControlSystem_polyval_f(localB->f, localB->t);
              localB->xd[1] = flightControlSystem_polyval_f(localB->g, localB->t);
              localB->xd[2] = flightControlSystem_polyval_f(localB->h, localB->t);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 1) * 6 + 4];
              }

              flightControlSystem_flip(localB->f);
              flightControlSystem_polyder_iv(localB->f, localB->i_data,
                localB->i_size);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 9) * 6 + 4];
              }

              flightControlSystem_flip(localB->f);
              flightControlSystem_polyder_iv(localB->f, localB->j_data,
                localB->j_size);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 17) * 6 + 4];
              }

              flightControlSystem_flip(localB->f);
              flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
                localB->tmp_size_m);
              localB->xd_1dot[0] = flightControlSystem_polyval(localB->i_data,
                localB->i_size, localB->DigitalClock - localB->scale);
              localB->xd_1dot[1] = flightControlSystem_polyval(localB->j_data,
                localB->j_size, localB->DigitalClock - localB->scale);
              localB->xd_1dot[2] = flightControlSystem_polyval(localB->tmp_data,
                localB->tmp_size_m, localB->t);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 1) * 6 + 4];
              }

              flightControlSystem_flip(localB->f);
              flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
                localB->tmp_size_m);
              flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
                localB->DTC3, localB->i_size);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 9) * 6 + 4];
              }

              flightControlSystem_flip(localB->f);
              flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
                localB->tmp_size_m);
              flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
                localB->n_data, localB->j_size);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 17) * 6 + 4];
              }

              flightControlSystem_flip(localB->f);
              flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
                localB->tmp_size_m);
              flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
                localB->tmp_data_c, localB->tmp_size_n);
              localB->xd_2dot[0] = flightControlSystem_polyval(localB->DTC3,
                localB->i_size, localB->DigitalClock - localB->scale);
              localB->xd_2dot[1] = flightControlSystem_polyval(localB->n_data,
                localB->j_size, localB->DigitalClock - localB->scale);
              localB->xd_2dot[2] = flightControlSystem_polyval
                (localB->tmp_data_c, localB->tmp_size_n, localB->t);
            } else if (localB->DigitalClock < localB->rtb_b1d_idx_2 +
                       flightControlSystem_P.polytraj[5]) {
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 1) * 6 + 5];
              }

              flightControlSystem_flip(localB->f);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->g[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 9) * 6 + 5];
              }

              flightControlSystem_flip(localB->g);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->h[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 17) * 6 + 5];
              }

              flightControlSystem_flip(localB->h);
              localB->t = localB->DigitalClock - localB->rtb_b1d_idx_2;
              localB->xd[0] = flightControlSystem_polyval_f(localB->f, localB->t);
              localB->xd[1] = flightControlSystem_polyval_f(localB->g, localB->t);
              localB->xd[2] = flightControlSystem_polyval_f(localB->h, localB->t);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 1) * 6 + 5];
              }

              flightControlSystem_flip(localB->f);
              flightControlSystem_polyder_iv(localB->f, localB->i_data,
                localB->i_size);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 9) * 6 + 5];
              }

              flightControlSystem_flip(localB->f);
              flightControlSystem_polyder_iv(localB->f, localB->j_data,
                localB->j_size);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 17) * 6 + 5];
              }

              flightControlSystem_flip(localB->f);
              flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
                localB->tmp_size_m);
              localB->xd_1dot[0] = flightControlSystem_polyval(localB->i_data,
                localB->i_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
              localB->xd_1dot[1] = flightControlSystem_polyval(localB->j_data,
                localB->j_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
              localB->xd_1dot[2] = flightControlSystem_polyval(localB->tmp_data,
                localB->tmp_size_m, localB->t);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 1) * 6 + 5];
              }

              flightControlSystem_flip(localB->f);
              flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
                localB->tmp_size_m);
              flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
                localB->DTC3, localB->i_size);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 9) * 6 + 5];
              }

              flightControlSystem_flip(localB->f);
              flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
                localB->tmp_size_m);
              flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
                localB->n_data, localB->j_size);
              for (localB->j = 0; localB->j < 8; localB->j++) {
                localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j
                  + 17) * 6 + 5];
              }

              flightControlSystem_flip(localB->f);
              flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
                localB->tmp_size_m);
              flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
                localB->tmp_data_c, localB->tmp_size_n);
              localB->xd_2dot[0] = flightControlSystem_polyval(localB->DTC3,
                localB->i_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
              localB->xd_2dot[1] = flightControlSystem_polyval(localB->n_data,
                localB->j_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
              localB->xd_2dot[2] = flightControlSystem_polyval
                (localB->tmp_data_c, localB->tmp_size_n, localB->t);
            } else if (localB->DigitalClock < 23.0) {
              localB->xd[0] = 0.0;
              localB->xd_1dot[0] = 0.0;
              localB->xd_2dot[0] = 0.0;
              localB->xd[1] = 0.0;
              localB->xd_1dot[1] = 0.0;
              localB->xd_2dot[1] = 0.0;
              localB->xd[2] = -1.0;
              localB->xd_1dot[2] = 0.0;
              localB->xd_2dot[2] = 0.0;
            } else {
              localB->xd[0] = 0.0;
              localB->xd[1] = 0.0;
              localB->xd[2] = (localB->DigitalClock - 23.0) * 0.2 + -1.0;
              localB->xd_1dot[0] = 0.0;
              localB->xd_2dot[0] = 0.0;
              localB->xd_1dot[1] = 0.0;
              localB->xd_2dot[1] = 0.0;
              localB->xd_1dot[2] = 0.2;
              localB->xd_2dot[2] = 0.0;
            }
          }
        }
      }
    }

    for (localB->j = 0; localB->j < 3; localB->j++) {
      localB->a[localB->j] = a[localB->j + 6] * localB->xd[2] + (a[localB->j + 3]
        * localB->xd[1] + a[localB->j] * localB->xd[0]);
    }

    for (localB->j = 0; localB->j < 3; localB->j++) {
      localB->xd[localB->j] = localB->a[localB->j];
      localB->a_c[localB->j] = a[localB->j + 6] * localB->xd_1dot[2] + (a
        [localB->j + 3] * localB->xd_1dot[1] + a[localB->j] * localB->xd_1dot[0]);
    }

    for (localB->j = 0; localB->j < 3; localB->j++) {
      localB->xd_1dot[localB->j] = localB->a_c[localB->j];
      localB->a[localB->j] = a[localB->j + 6] * localB->xd_2dot[2] + (a
        [localB->j + 3] * localB->xd_2dot[1] + a[localB->j] * localB->xd_2dot[0]);
    }

    localB->xd_2dot[0] = localB->a[0];
    localB->xd_2dot[1] = localB->a[1];
    localB->xd_2dot[2] = localB->a[2];
  } else if (localP->Constant_Value_e == 2.0) {
    if (localB->DigitalClock < 2.0) {
      localB->scale = -0.1563;
      for (localB->j = 0; localB->j < 7; localB->j++) {
        localB->scale = localB->DigitalClock * localB->scale + p[localB->j + 1];
      }

      localB->xd[0] = 0.0;
      localB->xd[1] = 0.0;
      localB->xd[2] = -localB->scale;
      flightControlSystem_polyder(localB->tmp_data, localB->tmp_size_m);
      localB->scale = flightControlSystem_polyval(localB->tmp_data,
        localB->tmp_size_m, localB->DigitalClock);
      localB->xd_1dot[0] = 0.0;
      localB->xd_1dot[1] = 0.0;
      localB->xd_1dot[2] = -localB->scale;
      flightControlSystem_polyder(localB->tmp_data, localB->tmp_size_m);
      flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
        localB->tmp_data_c, localB->tmp_size_n);
      localB->scale = flightControlSystem_polyval(localB->tmp_data_c,
        localB->tmp_size_n, localB->DigitalClock);
      localB->xd_2dot[0] = 0.0;
      localB->xd_2dot[1] = 0.0;
      localB->xd_2dot[2] = -localB->scale;
    } else if (localB->DigitalClock < 5.0) {
      localB->xd[0] = 0.0;
      localB->xd_1dot[0] = 0.0;
      localB->xd_2dot[0] = 0.0;
      localB->xd[1] = 0.0;
      localB->xd_1dot[1] = 0.0;
      localB->xd_2dot[1] = 0.0;
      localB->xd[2] = -1.0;
      localB->xd_1dot[2] = 0.0;
      localB->xd_2dot[2] = 0.0;
    } else if (localB->DigitalClock < 7.0) {
      localB->scale = -0.1563;
      for (localB->j = 0; localB->j < 7; localB->j++) {
        localB->scale = (localB->DigitalClock - 5.0) * localB->scale + p
          [localB->j + 1];
      }

      localB->xd[0] = 0.0;
      localB->xd[1] = localB->scale;
      localB->xd[2] = -1.0;
      flightControlSystem_polyder(localB->tmp_data, localB->tmp_size_m);
      localB->xd_1dot[1] = flightControlSystem_polyval(localB->tmp_data,
        localB->tmp_size_m, localB->DigitalClock - 5.0);
      localB->xd_1dot[0] = 0.0;
      localB->xd_1dot[2] = 0.0;
      flightControlSystem_polyder(localB->tmp_data, localB->tmp_size_m);
      flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
        localB->tmp_data_c, localB->tmp_size_n);
      localB->xd_2dot[1] = flightControlSystem_polyval(localB->tmp_data_c,
        localB->tmp_size_n, localB->DigitalClock - 5.0);
      localB->xd_2dot[0] = 0.0;
      localB->xd_2dot[2] = 0.0;
    } else if (localB->DigitalClock < 10.0) {
      localB->xd[0] = 0.0;
      localB->xd_1dot[0] = 0.0;
      localB->xd_2dot[0] = 0.0;
      localB->xd[1] = 1.0;
      localB->xd_1dot[1] = 0.0;
      localB->xd_2dot[1] = 0.0;
      localB->xd[2] = -1.0;
      localB->xd_1dot[2] = 0.0;
      localB->xd_2dot[2] = 0.0;
    } else if (localB->DigitalClock < 30.0) {
      localB->scale = (localB->DigitalClock - 10.0) * 1.0471975511965976;
      localB->t = cos(localB->scale);
      localB->scale = sin(localB->scale);
      localB->xd[0] = localB->scale;
      localB->xd[1] = localB->t;
      localB->xd[2] = -1.0;
      localB->xd_1dot[0] = 1.0471975511965976 * localB->t;
      localB->xd_1dot[1] = -1.0471975511965976 * localB->scale;
      localB->xd_1dot[2] = 0.0;
      localB->xd_2dot[0] = -1.0966227112321509 * localB->scale;
      localB->xd_2dot[1] = -1.0966227112321509 * localB->t;
      localB->xd_2dot[2] = 0.0;
    } else {
      localB->xd[0] = 0.86602540378444026;
      localB->xd[1] = -0.49999999999999722;
      localB->xd[2] = (localB->DigitalClock - 30.0) * 0.2 + -1.0;
      localB->xd_1dot[0] = 0.0;
      localB->xd_2dot[0] = 0.0;
      localB->xd_1dot[1] = 0.0;
      localB->xd_2dot[1] = 0.0;
      localB->xd_1dot[2] = 0.2;
      localB->xd_2dot[2] = 0.0;
    }
  } else if (localB->DigitalClock < 2.0) {
    localB->scale = -0.1563;
    for (localB->j = 0; localB->j < 7; localB->j++) {
      localB->scale = localB->DigitalClock * localB->scale + p[localB->j + 1];
    }

    localB->xd[0] = 0.0;
    localB->xd[1] = 0.0;
    localB->xd[2] = -localB->scale * 0.2;
    flightControlSystem_polyder(localB->tmp_data, localB->tmp_size_m);
    localB->scale = flightControlSystem_polyval(localB->tmp_data,
      localB->tmp_size_m, localB->DigitalClock);
    localB->xd_1dot[0] = 0.0;
    localB->xd_1dot[1] = 0.0;
    localB->xd_1dot[2] = -localB->scale * 0.2;
    flightControlSystem_polyder(localB->tmp_data, localB->tmp_size_m);
    flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
      localB->tmp_data_c, localB->tmp_size_n);
    localB->scale = flightControlSystem_polyval(localB->tmp_data_c,
      localB->tmp_size_n, localB->DigitalClock);
    localB->xd_2dot[0] = 0.0;
    localB->xd_2dot[1] = 0.0;
    localB->xd_2dot[2] = -localB->scale * 0.2;
  } else if (localB->DigitalClock < 5.0) {
    localB->xd[0] = 0.0;
    localB->xd_1dot[0] = 0.0;
    localB->xd_2dot[0] = 0.0;
    localB->xd[1] = 0.0;
    localB->xd_1dot[1] = 0.0;
    localB->xd_2dot[1] = 0.0;
    localB->xd[2] = -0.2;
    localB->xd_1dot[2] = 0.0;
    localB->xd_2dot[2] = 0.0;
  } else if (localB->DigitalClock < flightControlSystem_P.polytraj[0] + 5.0) {
    for (localB->j = 0; localB->j < 8; localB->j++) {
      localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1) * 6];
    }

    flightControlSystem_flip(localB->f);
    for (localB->j = 0; localB->j < 8; localB->j++) {
      localB->g[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9) * 6];
    }

    flightControlSystem_flip(localB->g);
    for (localB->j = 0; localB->j < 8; localB->j++) {
      localB->h[localB->j] = flightControlSystem_P.polytraj[(localB->j + 17) * 6];
    }

    flightControlSystem_flip(localB->h);
    localB->xd[0] = flightControlSystem_polyval_f(localB->f,
      localB->DigitalClock - 5.0);
    localB->xd[1] = flightControlSystem_polyval_f(localB->g,
      localB->DigitalClock - 5.0);
    localB->xd[2] = flightControlSystem_polyval_f(localB->h,
      localB->DigitalClock - 5.0) * 0.2;
    for (localB->j = 0; localB->j < 8; localB->j++) {
      localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1) * 6];
    }

    flightControlSystem_flip(localB->f);
    flightControlSystem_polyder_iv(localB->f, localB->i_data, localB->i_size);
    for (localB->j = 0; localB->j < 8; localB->j++) {
      localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9) * 6];
    }

    flightControlSystem_flip(localB->f);
    flightControlSystem_polyder_iv(localB->f, localB->j_data, localB->j_size);
    for (localB->j = 0; localB->j < 8; localB->j++) {
      localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 17) * 6];
    }

    flightControlSystem_flip(localB->f);
    flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
      localB->tmp_size_m);
    localB->xd_1dot[0] = flightControlSystem_polyval(localB->i_data,
      localB->i_size, localB->DigitalClock - 5.0);
    localB->xd_1dot[1] = flightControlSystem_polyval(localB->j_data,
      localB->j_size, localB->DigitalClock - 5.0);
    localB->scale = flightControlSystem_polyval(localB->tmp_data,
      localB->tmp_size_m, localB->DigitalClock - 5.0);
    localB->xd_1dot[2] = localB->scale * 0.2;
    for (localB->j = 0; localB->j < 8; localB->j++) {
      localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1) * 6];
    }

    flightControlSystem_flip(localB->f);
    flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
      localB->tmp_size_m);
    flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
      localB->DTC3, localB->i_size);
    for (localB->j = 0; localB->j < 8; localB->j++) {
      localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9) * 6];
    }

    flightControlSystem_flip(localB->f);
    flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
      localB->tmp_size_m);
    flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
      localB->n_data, localB->j_size);
    for (localB->j = 0; localB->j < 8; localB->j++) {
      localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 17) * 6];
    }

    flightControlSystem_flip(localB->f);
    flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
      localB->tmp_size_m);
    flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
      localB->tmp_data_c, localB->tmp_size_n);
    localB->xd_2dot[0] = flightControlSystem_polyval(localB->DTC3,
      localB->i_size, localB->DigitalClock - 5.0);
    localB->xd_2dot[1] = flightControlSystem_polyval(localB->n_data,
      localB->j_size, localB->DigitalClock - 5.0);
    localB->scale = flightControlSystem_polyval(localB->tmp_data_c,
      localB->tmp_size_n, localB->DigitalClock - 5.0);
    localB->xd_2dot[2] = localB->scale * 0.2;
  } else {
    localB->scale = (flightControlSystem_P.polytraj[0] + 5.0) +
      flightControlSystem_P.polytraj[1];
    if (localB->DigitalClock < localB->scale) {
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1) *
          6 + 1];
      }

      flightControlSystem_flip(localB->f);
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->g[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9) *
          6 + 1];
      }

      flightControlSystem_flip(localB->g);
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->h[localB->j] = flightControlSystem_P.polytraj[(localB->j + 17) *
          6 + 1];
      }

      flightControlSystem_flip(localB->h);
      localB->t = localB->DigitalClock - (flightControlSystem_P.polytraj[0] +
        5.0);
      localB->xd[0] = flightControlSystem_polyval_f(localB->f, localB->t);
      localB->xd[1] = flightControlSystem_polyval_f(localB->g, localB->t);
      localB->xd[2] = flightControlSystem_polyval_f(localB->h, localB->t) * 0.2;
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1) *
          6 + 1];
      }

      flightControlSystem_flip(localB->f);
      flightControlSystem_polyder_iv(localB->f, localB->i_data, localB->i_size);
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9) *
          6 + 1];
      }

      flightControlSystem_flip(localB->f);
      flightControlSystem_polyder_iv(localB->f, localB->j_data, localB->j_size);
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 17) *
          6 + 1];
      }

      flightControlSystem_flip(localB->f);
      flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
        localB->tmp_size_m);
      localB->xd_1dot[0] = flightControlSystem_polyval(localB->i_data,
        localB->i_size, localB->DigitalClock - (flightControlSystem_P.polytraj[0]
        + 5.0));
      localB->xd_1dot[1] = flightControlSystem_polyval(localB->j_data,
        localB->j_size, localB->DigitalClock - (flightControlSystem_P.polytraj[0]
        + 5.0));
      localB->scale = flightControlSystem_polyval(localB->tmp_data,
        localB->tmp_size_m, localB->t);
      localB->xd_1dot[2] = localB->scale * 0.2;
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1) *
          6 + 1];
      }

      flightControlSystem_flip(localB->f);
      flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
        localB->tmp_size_m);
      flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
        localB->DTC3, localB->i_size);
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9) *
          6 + 1];
      }

      flightControlSystem_flip(localB->f);
      flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
        localB->tmp_size_m);
      flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
        localB->n_data, localB->j_size);
      for (localB->j = 0; localB->j < 8; localB->j++) {
        localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 17) *
          6 + 1];
      }

      flightControlSystem_flip(localB->f);
      flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
        localB->tmp_size_m);
      flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
        localB->tmp_data_c, localB->tmp_size_n);
      localB->xd_2dot[0] = flightControlSystem_polyval(localB->DTC3,
        localB->i_size, localB->DigitalClock - (flightControlSystem_P.polytraj[0]
        + 5.0));
      localB->xd_2dot[1] = flightControlSystem_polyval(localB->n_data,
        localB->j_size, localB->DigitalClock - (flightControlSystem_P.polytraj[0]
        + 5.0));
      localB->scale = flightControlSystem_polyval(localB->tmp_data_c,
        localB->tmp_size_n, localB->t);
      localB->xd_2dot[2] = localB->scale * 0.2;
    } else {
      localB->rtb_b1d_idx_2 = ((flightControlSystem_P.polytraj[0] + 5.0) +
        flightControlSystem_P.polytraj[1]) + flightControlSystem_P.polytraj[2];
      if (localB->DigitalClock < localB->rtb_b1d_idx_2) {
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1) *
            6 + 2];
        }

        flightControlSystem_flip(localB->f);
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->g[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9) *
            6 + 2];
        }

        flightControlSystem_flip(localB->g);
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->h[localB->j] = flightControlSystem_P.polytraj[(localB->j + 17)
            * 6 + 2];
        }

        flightControlSystem_flip(localB->h);
        localB->t = localB->DigitalClock - localB->scale;
        localB->xd[0] = flightControlSystem_polyval_f(localB->f, localB->t);
        localB->xd[1] = flightControlSystem_polyval_f(localB->g, localB->t);
        localB->xd[2] = flightControlSystem_polyval_f(localB->h, localB->t) *
          0.2;
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1) *
            6 + 2];
        }

        flightControlSystem_flip(localB->f);
        flightControlSystem_polyder_iv(localB->f, localB->i_data, localB->i_size);
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9) *
            6 + 2];
        }

        flightControlSystem_flip(localB->f);
        flightControlSystem_polyder_iv(localB->f, localB->j_data, localB->j_size);
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 17)
            * 6 + 2];
        }

        flightControlSystem_flip(localB->f);
        flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
          localB->tmp_size_m);
        localB->xd_1dot[0] = flightControlSystem_polyval(localB->i_data,
          localB->i_size, localB->DigitalClock - localB->scale);
        localB->xd_1dot[1] = flightControlSystem_polyval(localB->j_data,
          localB->j_size, localB->DigitalClock - localB->scale);
        localB->rtb_b1d_idx_2 = flightControlSystem_polyval(localB->tmp_data,
          localB->tmp_size_m, localB->t);
        localB->xd_1dot[2] = localB->rtb_b1d_idx_2 * 0.2;
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1) *
            6 + 2];
        }

        flightControlSystem_flip(localB->f);
        flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
          localB->tmp_size_m);
        flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
          localB->DTC3, localB->i_size);
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9) *
            6 + 2];
        }

        flightControlSystem_flip(localB->f);
        flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
          localB->tmp_size_m);
        flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
          localB->n_data, localB->j_size);
        for (localB->j = 0; localB->j < 8; localB->j++) {
          localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 17)
            * 6 + 2];
        }

        flightControlSystem_flip(localB->f);
        flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
          localB->tmp_size_m);
        flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
          localB->tmp_data_c, localB->tmp_size_n);
        localB->xd_2dot[0] = flightControlSystem_polyval(localB->DTC3,
          localB->i_size, localB->DigitalClock - localB->scale);
        localB->xd_2dot[1] = flightControlSystem_polyval(localB->n_data,
          localB->j_size, localB->DigitalClock - localB->scale);
        localB->scale = flightControlSystem_polyval(localB->tmp_data_c,
          localB->tmp_size_n, localB->t);
        localB->xd_2dot[2] = localB->scale * 0.2;
      } else {
        localB->scale = (((flightControlSystem_P.polytraj[0] + 5.0) +
                          flightControlSystem_P.polytraj[1]) +
                         flightControlSystem_P.polytraj[2]) +
          flightControlSystem_P.polytraj[3];
        if (localB->DigitalClock < localB->scale) {
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1)
              * 6 + 3];
          }

          flightControlSystem_flip(localB->f);
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->g[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9)
              * 6 + 3];
          }

          flightControlSystem_flip(localB->g);
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->h[localB->j] = flightControlSystem_P.polytraj[(localB->j +
              17) * 6 + 3];
          }

          flightControlSystem_flip(localB->h);
          localB->t = localB->DigitalClock - localB->rtb_b1d_idx_2;
          localB->xd[0] = flightControlSystem_polyval_f(localB->f, localB->t);
          localB->xd[1] = flightControlSystem_polyval_f(localB->g, localB->t);
          localB->xd[2] = flightControlSystem_polyval_f(localB->h, localB->t) *
            0.2;
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1)
              * 6 + 3];
          }

          flightControlSystem_flip(localB->f);
          flightControlSystem_polyder_iv(localB->f, localB->i_data,
            localB->i_size);
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9)
              * 6 + 3];
          }

          flightControlSystem_flip(localB->f);
          flightControlSystem_polyder_iv(localB->f, localB->j_data,
            localB->j_size);
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
              17) * 6 + 3];
          }

          flightControlSystem_flip(localB->f);
          flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
            localB->tmp_size_m);
          localB->xd_1dot[0] = flightControlSystem_polyval(localB->i_data,
            localB->i_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
          localB->xd_1dot[1] = flightControlSystem_polyval(localB->j_data,
            localB->j_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
          localB->scale = flightControlSystem_polyval(localB->tmp_data,
            localB->tmp_size_m, localB->t);
          localB->xd_1dot[2] = localB->scale * 0.2;
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 1)
              * 6 + 3];
          }

          flightControlSystem_flip(localB->f);
          flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
            localB->tmp_size_m);
          flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
            localB->DTC3, localB->i_size);
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j + 9)
              * 6 + 3];
          }

          flightControlSystem_flip(localB->f);
          flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
            localB->tmp_size_m);
          flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
            localB->n_data, localB->j_size);
          for (localB->j = 0; localB->j < 8; localB->j++) {
            localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
              17) * 6 + 3];
          }

          flightControlSystem_flip(localB->f);
          flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
            localB->tmp_size_m);
          flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
            localB->tmp_data_c, localB->tmp_size_n);
          localB->xd_2dot[0] = flightControlSystem_polyval(localB->DTC3,
            localB->i_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
          localB->xd_2dot[1] = flightControlSystem_polyval(localB->n_data,
            localB->j_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
          localB->scale = flightControlSystem_polyval(localB->tmp_data_c,
            localB->tmp_size_n, localB->t);
          localB->xd_2dot[2] = localB->scale * 0.2;
        } else {
          localB->rtb_b1d_idx_2 = ((((flightControlSystem_P.polytraj[0] + 5.0) +
            flightControlSystem_P.polytraj[1]) + flightControlSystem_P.polytraj
            [2]) + flightControlSystem_P.polytraj[3]) +
            flightControlSystem_P.polytraj[4];
          if (localB->DigitalClock < localB->rtb_b1d_idx_2) {
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                1) * 6 + 4];
            }

            flightControlSystem_flip(localB->f);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->g[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                9) * 6 + 4];
            }

            flightControlSystem_flip(localB->g);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->h[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                17) * 6 + 4];
            }

            flightControlSystem_flip(localB->h);
            localB->t = localB->DigitalClock - localB->scale;
            localB->xd[0] = flightControlSystem_polyval_f(localB->f, localB->t);
            localB->xd[1] = flightControlSystem_polyval_f(localB->g, localB->t);
            localB->xd[2] = flightControlSystem_polyval_f(localB->h, localB->t) *
              0.2;
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                1) * 6 + 4];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->i_data,
              localB->i_size);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                9) * 6 + 4];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->j_data,
              localB->j_size);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                17) * 6 + 4];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
              localB->tmp_size_m);
            localB->xd_1dot[0] = flightControlSystem_polyval(localB->i_data,
              localB->i_size, localB->DigitalClock - localB->scale);
            localB->xd_1dot[1] = flightControlSystem_polyval(localB->j_data,
              localB->j_size, localB->DigitalClock - localB->scale);
            localB->rtb_b1d_idx_2 = flightControlSystem_polyval(localB->tmp_data,
              localB->tmp_size_m, localB->t);
            localB->xd_1dot[2] = localB->rtb_b1d_idx_2 * 0.2;
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                1) * 6 + 4];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
              localB->tmp_size_m);
            flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
              localB->DTC3, localB->i_size);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                9) * 6 + 4];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
              localB->tmp_size_m);
            flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
              localB->n_data, localB->j_size);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                17) * 6 + 4];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
              localB->tmp_size_m);
            flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
              localB->tmp_data_c, localB->tmp_size_n);
            localB->xd_2dot[0] = flightControlSystem_polyval(localB->DTC3,
              localB->i_size, localB->DigitalClock - localB->scale);
            localB->xd_2dot[1] = flightControlSystem_polyval(localB->n_data,
              localB->j_size, localB->DigitalClock - localB->scale);
            localB->scale = flightControlSystem_polyval(localB->tmp_data_c,
              localB->tmp_size_n, localB->t);
            localB->xd_2dot[2] = localB->scale * 0.2;
          } else if (localB->DigitalClock < (((((flightControlSystem_P.polytraj
              [0] + 5.0) + flightControlSystem_P.polytraj[1]) +
                        flightControlSystem_P.polytraj[2]) +
                       flightControlSystem_P.polytraj[3]) +
                      flightControlSystem_P.polytraj[4]) +
                     flightControlSystem_P.polytraj[5]) {
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                1) * 6 + 5];
            }

            flightControlSystem_flip(localB->f);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->g[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                9) * 6 + 5];
            }

            flightControlSystem_flip(localB->g);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->h[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                17) * 6 + 5];
            }

            flightControlSystem_flip(localB->h);
            localB->t = localB->DigitalClock - localB->rtb_b1d_idx_2;
            localB->xd[0] = flightControlSystem_polyval_f(localB->f, localB->t);
            localB->xd[1] = flightControlSystem_polyval_f(localB->g, localB->t);
            localB->xd[2] = flightControlSystem_polyval_f(localB->h, localB->t) *
              0.2;
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                1) * 6 + 5];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->i_data,
              localB->i_size);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                9) * 6 + 5];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->j_data,
              localB->j_size);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                17) * 6 + 5];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
              localB->tmp_size_m);
            localB->xd_1dot[0] = flightControlSystem_polyval(localB->i_data,
              localB->i_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
            localB->xd_1dot[1] = flightControlSystem_polyval(localB->j_data,
              localB->j_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
            localB->scale = flightControlSystem_polyval(localB->tmp_data,
              localB->tmp_size_m, localB->t);
            localB->xd_1dot[2] = localB->scale * 0.2;
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                1) * 6 + 5];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
              localB->tmp_size_m);
            flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
              localB->DTC3, localB->i_size);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                9) * 6 + 5];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
              localB->tmp_size_m);
            flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
              localB->n_data, localB->j_size);
            for (localB->j = 0; localB->j < 8; localB->j++) {
              localB->f[localB->j] = flightControlSystem_P.polytraj[(localB->j +
                17) * 6 + 5];
            }

            flightControlSystem_flip(localB->f);
            flightControlSystem_polyder_iv(localB->f, localB->tmp_data,
              localB->tmp_size_m);
            flightControlSystem_polyder_i(localB->tmp_data, localB->tmp_size_m,
              localB->tmp_data_c, localB->tmp_size_n);
            localB->xd_2dot[0] = flightControlSystem_polyval(localB->DTC3,
              localB->i_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
            localB->xd_2dot[1] = flightControlSystem_polyval(localB->n_data,
              localB->j_size, localB->DigitalClock - localB->rtb_b1d_idx_2);
            localB->scale = flightControlSystem_polyval(localB->tmp_data_c,
              localB->tmp_size_n, localB->t);
            localB->xd_2dot[2] = localB->scale * 0.2;
          } else if (localB->DigitalClock < 23.0) {
            localB->xd[0] = 0.0;
            localB->xd_1dot[0] = 0.0;
            localB->xd_2dot[0] = 0.0;
            localB->xd[1] = 0.0;
            localB->xd_1dot[1] = 0.0;
            localB->xd_2dot[1] = 0.0;
            localB->xd[2] = -0.2;
            localB->xd_1dot[2] = 0.0;
            localB->xd_2dot[2] = 0.0;
          } else {
            localB->xd[0] = 0.0;
            localB->xd[1] = 0.0;
            localB->xd[2] = (localB->DigitalClock - 23.0) * 0.2 + -0.2;
            localB->xd_1dot[0] = 0.0;
            localB->xd_2dot[0] = 0.0;
            localB->xd_1dot[1] = 0.0;
            localB->xd_2dot[1] = 0.0;
            localB->xd_1dot[2] = 0.2;
            localB->xd_2dot[2] = 0.0;
          }
        }
      }
    }
  }

  /* End of MATLAB Function: '<S3>/MATLAB Function' */

  /* Delay: '<S42>/MemoryX' incorporates:
   *  Constant: '<S42>/X0'
   *  Reshape: '<S42>/ReshapeX0'
   */
  if (localDW->icLoad != 0) {
    for (localB->i = 0; localB->i < 6; localB->i++) {
      localDW->MemoryX_DSTATE[localB->i] = localP->X0_Value[localB->i];
    }
  }

  /* Reshape: '<S42>/Reshapey' */
  localB->Reshapey[0] = localB->DataTypeConversion[0];
  localB->Reshapey[1] = localB->Gain1;
  localB->Reshapey[2] = localB->Gain;

  /* Outputs for Enabled SubSystem: '<S182>/Enabled Subsystem' incorporates:
   *  EnablePort: '<S206>/Enable'
   */
  /* Constant: '<S42>/Enable' */
  if (localP->Enable_Value) {
    localDW->EnabledSubsystem_MODE = true;

    /* Sum: '<S206>/Add1' incorporates:
     *  Constant: '<S42>/C'
     *  Delay: '<S42>/MemoryX'
     *  Product: '<S206>/Product'
     */
    for (localB->j = 0; localB->j < 3; localB->j++) {
      localB->DataTypeConversion_p = 0.0F;
      for (localB->i = 0; localB->i < 6; localB->i++) {
        localB->DataTypeConversion_p += localP->C_Value[3 * localB->i +
          localB->j] * localDW->MemoryX_DSTATE[localB->i];
      }

      localB->ct[localB->j] = localB->Reshapey[localB->j] -
        localB->DataTypeConversion_p;
    }

    /* End of Sum: '<S206>/Add1' */
    for (localB->j = 0; localB->j < 6; localB->j++) {
      /* Product: '<S206>/Product2' incorporates:
       *  DataTypeConversion: '<S199>/Conversion'
       */
      localB->Product2[localB->j] = 0.0F;
      localB->Product2[localB->j] += localB->Conversion[localB->j] * localB->ct
        [0];
      localB->Product2[localB->j] += localB->Conversion[localB->j + 6] *
        localB->ct[1];
      localB->Product2[localB->j] += localB->Conversion[localB->j + 12] *
        localB->ct[2];
    }
  } else {
    if (localDW->EnabledSubsystem_MODE) {
      for (localB->i = 0; localB->i < 6; localB->i++) {
        /* Disable for Product: '<S206>/Product2' incorporates:
         *  Outport: '<S206>/deltax'
         */
        localB->Product2[localB->i] = localP->deltax_Y0;
      }

      localDW->EnabledSubsystem_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S182>/Enabled Subsystem' */

  /* Sum: '<S182>/Add' incorporates:
   *  Delay: '<S42>/MemoryX'
   */
  for (localB->i = 0; localB->i < 6; localB->i++) {
    localB->Add[localB->i] = localB->Product2[localB->i] +
      localDW->MemoryX_DSTATE[localB->i];
  }

  /* End of Sum: '<S182>/Add' */

  /* MATLAB Function: '<S8>/Force controller  (MATLAB Function)' */
  localB->a_tmp = flightControlSystem_P.mass * flightControlSystem_P.gravity;
  x_tmp[0] = 0;
  x_tmp[1] = 0;
  x_tmp[2] = 1;
  for (localB->j = 0; localB->j < 9; localB->j++) {
    localB->dv[localB->j] = -flightControlSystem_P.kx[localB->j];
  }

  /* Sum: '<S8>/Sum' incorporates:
   *  Reshape: '<S42>/Reshapexhat'
   */
  localB->rtb_Add_idx_0 = localB->Add[0] - localB->xd[0];

  /* Sum: '<S8>/Sum1' incorporates:
   *  Reshape: '<S42>/Reshapexhat'
   */
  localB->rtb_Add_idx_0_l = localB->Add[3] - localB->xd_1dot[0];

  /* Sum: '<S8>/Sum' incorporates:
   *  Reshape: '<S42>/Reshapexhat'
   */
  localB->rtb_Add_idx_1 = localB->Add[1] - localB->xd[1];

  /* Sum: '<S8>/Sum1' incorporates:
   *  Reshape: '<S42>/Reshapexhat'
   */
  localB->rtb_Add_idx_1_j = localB->Add[4] - localB->xd_1dot[1];

  /* Sum: '<S8>/Sum' incorporates:
   *  Reshape: '<S42>/Reshapexhat'
   */
  localB->rtb_Add_idx_2 = localB->Add[2] - localB->xd[2];

  /* Sum: '<S8>/Sum1' incorporates:
   *  Reshape: '<S42>/Reshapexhat'
   */
  localB->rtb_Add_idx_2_d = localB->Add[5] - localB->xd_1dot[2];

  /* MATLAB Function: '<S8>/Force controller  (MATLAB Function)' */
  localB->rtb_b1d_idx_2 = 0.0;
  localB->scale = 3.3121686421112381E-170;
  for (localB->j = 0; localB->j < 3; localB->j++) {
    localB->x_tmp = (localB->dv[localB->j + 6] * localB->rtb_Add_idx_2 +
                     (localB->dv[localB->j + 3] * localB->rtb_Add_idx_1 +
                      localB->dv[localB->j] * localB->rtb_Add_idx_0)) -
      (flightControlSystem_P.kv[localB->j + 6] * localB->rtb_Add_idx_2_d +
       (flightControlSystem_P.kv[localB->j + 3] * localB->rtb_Add_idx_1_j +
        flightControlSystem_P.kv[localB->j] * localB->rtb_Add_idx_0_l));
    localB->rtb_xd_2dot_p = flightControlSystem_P.mass * localB->xd_2dot
      [localB->j];
    localB->DigitalClock = fabs((localB->x_tmp - localB->a_tmp * (real_T)
      x_tmp[localB->j]) + localB->rtb_xd_2dot_p);
    if (localB->DigitalClock > localB->scale) {
      localB->t = localB->scale / localB->DigitalClock;
      localB->rtb_b1d_idx_2 = localB->rtb_b1d_idx_2 * localB->t * localB->t +
        1.0;
      localB->scale = localB->DigitalClock;
    } else {
      localB->t = localB->DigitalClock / localB->scale;
      localB->rtb_b1d_idx_2 += localB->t * localB->t;
    }

    localB->a[localB->j] = localB->x_tmp;
    localB->xd_2dot[localB->j] = localB->rtb_xd_2dot_p;
  }

  localB->rtb_b1d_idx_2 = localB->scale * sqrt(localB->rtb_b1d_idx_2);
  localB->Gain1_g = 0.0F;
  for (localB->j = 0; localB->j < 3; localB->j++) {
    localB->rtb_xd_2dot_p = localB->xd_2dot[localB->j];
    localB->i = x_tmp[localB->j];
    localB->x_tmp = localB->a[localB->j];
    localB->xd_1dot[localB->j] = -((localB->x_tmp - localB->a_tmp * (real_T)
      localB->i) + localB->rtb_xd_2dot_p) / localB->rtb_b1d_idx_2;
    localB->Gain1_g += (real32_T)((localB->x_tmp - localB->a_tmp * (real_T)
      localB->i) + localB->rtb_xd_2dot_p) * (localB->R[localB->j + 6] +
      (localB->R[localB->j + 3] * 0.0F + localB->R[localB->j] * 0.0F));
  }

  /* MATLAB Function: '<S8>/Rd' */
  localB->scale = 3.3121686421112381E-170;
  localB->a_tmp = localB->xd_1dot[1] * 0.0 - localB->xd_1dot[2] * 0.0;
  localB->t = localB->a_tmp / 3.3121686421112381E-170;
  localB->rtb_b1d_idx_2 = localB->t * localB->t;
  localB->rtb_Add_idx_0 = localB->xd_1dot[2] - localB->xd_1dot[0] * 0.0;
  localB->DigitalClock = fabs(localB->rtb_Add_idx_0);
  if (localB->DigitalClock > 3.3121686421112381E-170) {
    localB->t = 3.3121686421112381E-170 / localB->DigitalClock;
    localB->rtb_b1d_idx_2 = localB->rtb_b1d_idx_2 * localB->t * localB->t + 1.0;
    localB->scale = localB->DigitalClock;
  } else {
    localB->t = localB->DigitalClock / 3.3121686421112381E-170;
    localB->rtb_b1d_idx_2 += localB->t * localB->t;
  }

  localB->rtb_Add_idx_0_l = localB->xd_1dot[0] * 0.0 - localB->xd_1dot[1];
  localB->DigitalClock = fabs(localB->rtb_Add_idx_0_l);
  if (localB->DigitalClock > localB->scale) {
    localB->t = localB->scale / localB->DigitalClock;
    localB->rtb_b1d_idx_2 = localB->rtb_b1d_idx_2 * localB->t * localB->t + 1.0;
    localB->scale = localB->DigitalClock;
  } else {
    localB->t = localB->DigitalClock / localB->scale;
    localB->rtb_b1d_idx_2 += localB->t * localB->t;
  }

  localB->rtb_b1d_idx_2 = localB->scale * sqrt(localB->rtb_b1d_idx_2);
  localB->xd_2dot[0] = localB->a_tmp / localB->rtb_b1d_idx_2;
  localB->xd_2dot[1] = localB->rtb_Add_idx_0 / localB->rtb_b1d_idx_2;
  localB->xd_2dot[2] = localB->rtb_Add_idx_0_l / localB->rtb_b1d_idx_2;
  localB->Rd[0] = localB->xd_2dot[1] * localB->xd_1dot[2] - localB->xd_2dot[2] *
    localB->xd_1dot[1];
  localB->Rd[1] = localB->xd_2dot[2] * localB->xd_1dot[0] - localB->xd_2dot[0] *
    localB->xd_1dot[2];
  localB->Rd[2] = localB->xd_2dot[0] * localB->xd_1dot[1] - localB->xd_2dot[1] *
    localB->xd_1dot[0];
  localB->Rd[3] = localB->xd_2dot[0];
  localB->Rd[6] = localB->xd_1dot[0];
  localB->Rd[4] = localB->xd_2dot[1];
  localB->Rd[7] = localB->xd_1dot[1];
  localB->Rd[5] = localB->xd_2dot[2];
  localB->Rd[8] = localB->xd_1dot[2];

  /* End of MATLAB Function: '<S8>/Rd' */

  /* Delay: '<S103>/MemoryX' incorporates:
   *  Constant: '<S103>/X0'
   *  Reshape: '<S103>/ReshapeX0'
   */
  if (localDW->icLoad_p != 0) {
    localDW->MemoryX_DSTATE_e[0] = localP->X0_Value_f[0];
    localDW->MemoryX_DSTATE_e[1] = localP->X0_Value_f[1];
  }

  /* Delay: '<S103>/MemoryX' */
  localB->MemoryX_j[0] = localDW->MemoryX_DSTATE_e[0];
  localB->MemoryX_j[1] = localDW->MemoryX_DSTATE_e[1];

  /* Trigonometry: '<S49>/Trigonometric Function' incorporates:
   *  Product: '<S49>/Divide'
   */
  localB->TrigonometricFunction = atanf(localB->FIR_IMUaccel[1] /
    localB->FIR_IMUaccel[2]);

  /* Reshape: '<S103>/Reshapey' */
  localB->Reshapey_k = localB->TrigonometricFunction;

  /* Math: '<S50>/Math Function' incorporates:
   *  Constant: '<S50>/Constant'
   *  DataTypeConversion: '<S50>/Data Type Conversion2'
   */
  localB->DataTypeConversion_p = floorf(localP->Constant_Value_l);
  if ((localB->FIR_IMUaccel[0] < 0.0F) && (localP->Constant_Value_l >
       localB->DataTypeConversion_p)) {
    localB->f_l = -rt_powf_snf(-localB->FIR_IMUaccel[0],
      localP->Constant_Value_l);
  } else {
    localB->f_l = rt_powf_snf(localB->FIR_IMUaccel[0], localP->Constant_Value_l);
  }

  if ((localB->FIR_IMUaccel[1] < 0.0F) && (localP->Constant_Value_l >
       localB->DataTypeConversion_p)) {
    localB->f1 = -rt_powf_snf(-localB->FIR_IMUaccel[1], localP->Constant_Value_l);
  } else {
    localB->f1 = rt_powf_snf(localB->FIR_IMUaccel[1], localP->Constant_Value_l);
  }

  if ((localB->FIR_IMUaccel[2] < 0.0F) && (localP->Constant_Value_l >
       localB->DataTypeConversion_p)) {
    localB->DataTypeConversion_p = -rt_powf_snf(-localB->FIR_IMUaccel[2],
      localP->Constant_Value_l);
  } else {
    localB->DataTypeConversion_p = rt_powf_snf(localB->FIR_IMUaccel[2],
      localP->Constant_Value_l);
  }

  /* End of Math: '<S50>/Math Function' */

  /* Sqrt: '<S50>/Sqrt' incorporates:
   *  Sum: '<S50>/Sum of Elements'
   */
  localB->DataTypeConversion_p = sqrtf((localB->f_l + localB->f1) +
    localB->DataTypeConversion_p);

  /* Logic: '<S41>/Logical Operator' incorporates:
   *  Constant: '<S46>/Constant'
   *  Constant: '<S47>/Constant'
   *  RelationalOperator: '<S46>/Compare'
   *  RelationalOperator: '<S47>/Compare'
   */
  localB->LogicalOperator = (int16_T)((localB->DataTypeConversion_p >
    localP->CompareToConstant_const) && (localB->DataTypeConversion_p <
    localP->CompareToConstant1_const));

  /* DataTypeConversion: '<S103>/DataTypeConversionEnable' */
  rtb_DataTypeConversionEnable = (localB->LogicalOperator != 0);

  /* DataTypeConversion: '<S147>/Conversion' incorporates:
   *  Constant: '<S104>/KalmanGainM'
   */
  localB->Conversion_p[0] = (real32_T)localP->KalmanGainM_Value_p[0];
  localB->Conversion_p[1] = (real32_T)localP->KalmanGainM_Value_p[1];

  /* Outputs for Enabled SubSystem: '<S130>/Enabled Subsystem' */
  /* Constant: '<S103>/C' */
  flightControlSystem_EnabledSubsystem(rtb_DataTypeConversionEnable,
    localB->Conversion_p, localP->C_Value_g, localB->Reshapey_k,
    localB->MemoryX_j, &localB->EnabledSubsystem_m, &localDW->EnabledSubsystem_m,
    &localP->EnabledSubsystem_m);

  /* End of Outputs for SubSystem: '<S130>/Enabled Subsystem' */

  /* Delay: '<S51>/MemoryX' incorporates:
   *  Constant: '<S51>/X0'
   *  Reshape: '<S51>/ReshapeX0'
   */
  if (localDW->icLoad_i != 0) {
    localDW->MemoryX_DSTATE_p[0] = localP->X0_Value_j[0];
    localDW->MemoryX_DSTATE_p[1] = localP->X0_Value_j[1];
  }

  /* Delay: '<S51>/MemoryX' */
  localB->MemoryX_h[0] = localDW->MemoryX_DSTATE_p[0];
  localB->MemoryX_h[1] = localDW->MemoryX_DSTATE_p[1];

  /* Gain: '<S48>/Gain2' */
  localB->DataTypeConversion_p = localP->Gain2_Gain * localB->FIR_IMUaccel[0];

  /* Trigonometry: '<S48>/Trigonometric Function1' */
  if (localB->DataTypeConversion_p > 1.0F) {
    localB->DataTypeConversion_p = 1.0F;
  } else {
    if (localB->DataTypeConversion_p < -1.0F) {
      localB->DataTypeConversion_p = -1.0F;
    }
  }

  /* Trigonometry: '<S48>/Trigonometric Function1' */
  localB->TrigonometricFunction1 = asinf(localB->DataTypeConversion_p);

  /* Reshape: '<S51>/Reshapey' */
  localB->Reshapey_d = localB->TrigonometricFunction1;

  /* DataTypeConversion: '<S51>/DataTypeConversionEnable' */
  rtb_DataTypeConversionEnable_f = (localB->LogicalOperator != 0);

  /* DataTypeConversion: '<S95>/Conversion' incorporates:
   *  Constant: '<S52>/KalmanGainM'
   */
  localB->Conversion_pl[0] = (real32_T)localP->KalmanGainM_Value_j[0];
  localB->Conversion_pl[1] = (real32_T)localP->KalmanGainM_Value_j[1];

  /* Outputs for Enabled SubSystem: '<S78>/Enabled Subsystem' */
  /* Constant: '<S51>/C' */
  flightControlSystem_EnabledSubsystem(rtb_DataTypeConversionEnable_f,
    localB->Conversion_pl, localP->C_Value_c, localB->Reshapey_d,
    localB->MemoryX_h, &localB->EnabledSubsystem, &localDW->EnabledSubsystem,
    &localP->EnabledSubsystem);

  /* End of Outputs for SubSystem: '<S78>/Enabled Subsystem' */

  /* Sum: '<S41>/Subtract' incorporates:
   *  Constant: '<S41>/Constant'
   *  Sum: '<S130>/Add'
   *  Sum: '<S78>/Add'
   */
  localB->Reshapey[0] = localB->p;
  localB->Reshapey[1] = localB->q;
  localB->Reshapey[2] = localB->r;
  localB->ct[0] = localB->EnabledSubsystem_m.Product2[1] + localB->MemoryX_j[1];
  localB->ct[1] = localB->EnabledSubsystem.Product2[1] + localB->MemoryX_h[1];
  localB->ct[2] = localP->Constant_Value_h;
  for (localB->j = 0; localB->j < 3; localB->j++) {
    localB->st[localB->j] = localB->Reshapey[localB->j] - localB->ct[localB->j];

    /* MATLAB Function: '<S6>/L1 Adaptation Law' */
    localB->fv[6 * localB->j] = localB->R[localB->j + 6] * (real32_T)
      flightControlSystem_P.m;
    localB->i = 6 * (localB->j + 3);
    localB->fv[localB->i] = 0.0F;
    localB->fv[6 * localB->j + 1] = 0.0F;
    localB->fv[localB->i + 1] = (real32_T)flightControlSystem_P.J[3 * localB->j];
    localB->fv[6 * localB->j + 2] = 0.0F;
    localB->fv[localB->i + 2] = (real32_T)flightControlSystem_P.J[3 * localB->j
      + 1];
    localB->fv[6 * localB->j + 3] = 0.0F;
    localB->fv[localB->i + 3] = (real32_T)flightControlSystem_P.J[3 * localB->j
      + 2];
    localB->fv[6 * localB->j + 4] = (real32_T)flightControlSystem_P.m *
      localB->R[localB->j];
    localB->fv[localB->i + 4] = 0.0F;
    localB->fv[6 * localB->j + 5] = localB->R[localB->j + 3] * (real32_T)
      flightControlSystem_P.m;
    localB->fv[localB->i + 5] = 0.0F;
  }

  /* End of Sum: '<S41>/Subtract' */

  /* MATLAB Function: '<S6>/L1 Adaptation Law' incorporates:
   *  Delay: '<S17>/Delay2'
   *  MATLAB Function: '<S17>/L1 State Predictor'
   *  Reshape: '<S42>/Reshapexhat'
   */
  for (localB->j = 0; localB->j < 6; localB->j++) {
    for (localB->i = 0; localB->i < 6; localB->i++) {
      localB->b_tmp = localB->j + 6 * localB->i;
      localB->b[localB->b_tmp] = 0.0F;
      for (localB->Rw_tmp = 0; localB->Rw_tmp < 6; localB->Rw_tmp++) {
        localB->b[localB->b_tmp] += (real32_T)b[6 * localB->Rw_tmp + localB->j] *
          localB->fv[6 * localB->i + localB->Rw_tmp];
      }
    }

    for (localB->i = 0; localB->i < 6; localB->i++) {
      localB->b_tmp = localB->j + 6 * localB->i;
      localB->b_m[localB->b_tmp] = 0.0F;
      for (localB->Rw_tmp = 0; localB->Rw_tmp < 6; localB->Rw_tmp++) {
        localB->b_m[localB->b_tmp] += localB->b[6 * localB->Rw_tmp + localB->j] *
          (real32_T)flightControlSystem_P.adaptationgain[6 * localB->i +
          localB->Rw_tmp];
      }
    }
  }

  localB->DataTypeConversion_p = (real32_T)localDW->Delay2_DSTATE[0] -
    localB->Add[3];
  localB->fv2[0] = localB->DataTypeConversion_p;
  localB->f_l = (real32_T)localDW->Delay2_DSTATE[3] - localB->st[0];
  localB->fv2[3] = localB->f_l;
  localB->f1 = (real32_T)localDW->Delay2_DSTATE[1] - localB->Add[4];
  localB->fv2[1] = localB->f1;
  localB->f2 = (real32_T)localDW->Delay2_DSTATE[4] - localB->st[1];
  localB->fv2[4] = localB->f2;
  localB->f3 = (real32_T)localDW->Delay2_DSTATE[2] - localB->Add[5];
  localB->fv2[2] = localB->f3;
  localB->f4 = (real32_T)localDW->Delay2_DSTATE[5] - localB->st[2];
  localB->fv2[5] = localB->f4;
  for (localB->i = 0; localB->i < 6; localB->i++) {
    localB->sigma[localB->i] = 0.0F;
    for (localB->j = 0; localB->j < 6; localB->j++) {
      localB->sigma[localB->i] += localB->b_m[6 * localB->j + localB->i] *
        localB->fv2[localB->j];
    }

    /* DataTypeConversion: '<S6>/DTC3' */
    localB->DTC3[localB->i] = localB->sigma[localB->i];
  }

  /* Gain: '<S5>/Gain1' incorporates:
   *  MATLAB Function: '<S8>/Force controller  (MATLAB Function)'
   */
  localB->Gain1_g = localP->Gain1_Gain_i * -localB->Gain1_g;

  /* RelationalOperator: '<S24>/Compare' incorporates:
   *  Constant: '<S21>/Time constant'
   *  Constant: '<S24>/Constant'
   *  Sum: '<S21>/Sum1'
   */
  localB->Compare = (localP->LowPassFilterDiscreteorContinuous1_T
                     - localB->Probe[0] <= localP->Constant_Value_c);

  /* Constant: '<S25>/Constant' */
  localB->Constant = localP->LowPassFilterDiscreteorContinuous1_x0;

  /* DiscreteIntegrator: '<S26>/Integrator' */
  if (localB->Compare || (localDW->Integrator_PrevResetState != 0)) {
    localDW->Integrator_DSTATE = localB->Constant;
    if (localDW->Integrator_DSTATE >= localP->Integrator_UpperSat) {
      localDW->Integrator_DSTATE = localP->Integrator_UpperSat;
    } else {
      if (localDW->Integrator_DSTATE <= localP->Integrator_LowerSat) {
        localDW->Integrator_DSTATE = localP->Integrator_LowerSat;
      }
    }
  }

  if (localDW->Integrator_DSTATE >= localP->Integrator_UpperSat) {
    localDW->Integrator_DSTATE = localP->Integrator_UpperSat;
  } else {
    if (localDW->Integrator_DSTATE <= localP->Integrator_LowerSat) {
      localDW->Integrator_DSTATE = localP->Integrator_LowerSat;
    }
  }

  /* End of DiscreteIntegrator: '<S26>/Integrator' */

  /* Saturate: '<S26>/Saturation' */
  if (localDW->Integrator_DSTATE > localP->Saturation_UpperSat) {
    /* Saturate: '<S26>/Saturation' */
    localB->Saturation = localP->Saturation_UpperSat;
  } else if (localDW->Integrator_DSTATE < localP->Saturation_LowerSat) {
    /* Saturate: '<S26>/Saturation' */
    localB->Saturation = localP->Saturation_LowerSat;
  } else {
    /* Saturate: '<S26>/Saturation' */
    localB->Saturation = localDW->Integrator_DSTATE;
  }

  /* End of Saturate: '<S26>/Saturation' */

  /* MATLAB Function: '<S5>/Moment controller' incorporates:
   *  MATLAB Function: '<S17>/L1 State Predictor'
   */
  for (localB->j = 0; localB->j < 3; localB->j++) {
    for (localB->i = 0; localB->i < 3; localB->i++) {
      localB->Rw_tmp = localB->i + 3 * localB->j;
      localB->Rw[localB->Rw_tmp] = 0.0F;
      localB->y_a[localB->Rw_tmp] = 0.0F;
      localB->Rw[localB->Rw_tmp] += (real32_T)localB->Rd[3 * localB->i] *
        localB->R[3 * localB->j];
      localB->y_a[localB->Rw_tmp] += localB->R[3 * localB->i] * (real32_T)
        localB->Rd[3 * localB->j];
      localB->b_tmp = 3 * localB->i + 1;
      localB->rtb_Delay_tmp = 3 * localB->j + 1;
      localB->Rw[localB->Rw_tmp] += (real32_T)localB->Rd[localB->b_tmp] *
        localB->R[localB->rtb_Delay_tmp];
      localB->y_a[localB->Rw_tmp] += localB->R[localB->b_tmp] * (real32_T)
        localB->Rd[localB->rtb_Delay_tmp];
      localB->b_tmp = 3 * localB->i + 2;
      localB->rtb_Delay_tmp = 3 * localB->j + 2;
      localB->Rw[localB->Rw_tmp] += (real32_T)localB->Rd[localB->b_tmp] *
        localB->R[localB->rtb_Delay_tmp];
      localB->y_a[localB->Rw_tmp] += localB->R[localB->b_tmp] * (real32_T)
        localB->Rd[localB->rtb_Delay_tmp];
    }
  }

  for (localB->j = 0; localB->j < 9; localB->j++) {
    localB->Delay[localB->j] = localB->Rw[localB->j] - localB->y_a[localB->j];
  }

  for (localB->j = 0; localB->j < 3; localB->j++) {
    localB->ct[localB->j] = (real32_T)flightControlSystem_P.J[localB->j + 6] *
      localB->st[2] + ((real32_T)flightControlSystem_P.J[localB->j + 3] *
                       localB->st[1] + (real32_T)flightControlSystem_P.J
                       [localB->j] * localB->st[0]);
  }

  for (localB->j = 0; localB->j < 9; localB->j++) {
    localB->y_a[localB->j] = (real32_T)-flightControlSystem_P.kR[localB->j];
  }

  localB->unnamed_idx_0 = 0.5F * localB->Delay[5];
  localB->unnamed_idx_1 = 0.5F * localB->Delay[6];
  localB->unnamed_idx_2 = 0.5F * localB->Delay[1];
  localB->st_tmp = localB->st[1] * localB->ct[2] - localB->st[2] * localB->ct[1];
  localB->Reshapey[0] = localB->st_tmp;
  localB->st_tmp_h = localB->st[2] * localB->ct[0] - localB->st[0] * localB->ct
    [2];
  localB->Reshapey[1] = localB->st_tmp_h;
  localB->st_tmp_b = localB->st[0] * localB->ct[1] - localB->st[1] * localB->ct
    [0];
  localB->Reshapey[2] = localB->st_tmp_b;
  for (localB->j = 0; localB->j < 3; localB->j++) {
    localB->ct[localB->j] = ((localB->y_a[localB->j + 6] * localB->unnamed_idx_2
      + (localB->y_a[localB->j + 3] * localB->unnamed_idx_1 + localB->y_a
         [localB->j] * localB->unnamed_idx_0)) - ((real32_T)
      flightControlSystem_P.kOmega[localB->j + 6] * localB->st[2] + ((real32_T)
      flightControlSystem_P.kOmega[localB->j + 3] * localB->st[1] + (real32_T)
      flightControlSystem_P.kOmega[localB->j] * localB->st[0]))) +
      localB->Reshapey[localB->j];
  }

  /* End of MATLAB Function: '<S5>/Moment controller' */

  /* RelationalOperator: '<S30>/Compare' incorporates:
   *  Constant: '<S27>/Time constant'
   *  Constant: '<S30>/Constant'
   *  Sum: '<S27>/Sum1'
   */
  localB->Compare_a = (localP->LowPassFilterDiscreteorContinuous2_T
                       - localB->Probe_h[0] <= localP->Constant_Value_k);

  /* Constant: '<S31>/Constant' */
  localB->Constant_k = localP->LowPassFilterDiscreteorContinuous2_x0;

  /* DiscreteIntegrator: '<S32>/Integrator' */
  if (localB->Compare_a || (localDW->Integrator_PrevResetState_o != 0)) {
    localDW->Integrator_DSTATE_f[0] = localB->Constant_k;
    if (localDW->Integrator_DSTATE_f[0] >= localP->Integrator_UpperSat_o) {
      localDW->Integrator_DSTATE_f[0] = localP->Integrator_UpperSat_o;
    } else {
      if (localDW->Integrator_DSTATE_f[0] <= localP->Integrator_LowerSat_p) {
        localDW->Integrator_DSTATE_f[0] = localP->Integrator_LowerSat_p;
      }
    }

    localDW->Integrator_DSTATE_f[1] = localB->Constant_k;
    if (localDW->Integrator_DSTATE_f[1] >= localP->Integrator_UpperSat_o) {
      localDW->Integrator_DSTATE_f[1] = localP->Integrator_UpperSat_o;
    } else {
      if (localDW->Integrator_DSTATE_f[1] <= localP->Integrator_LowerSat_p) {
        localDW->Integrator_DSTATE_f[1] = localP->Integrator_LowerSat_p;
      }
    }

    localDW->Integrator_DSTATE_f[2] = localB->Constant_k;
    if (localDW->Integrator_DSTATE_f[2] >= localP->Integrator_UpperSat_o) {
      localDW->Integrator_DSTATE_f[2] = localP->Integrator_UpperSat_o;
    } else {
      if (localDW->Integrator_DSTATE_f[2] <= localP->Integrator_LowerSat_p) {
        localDW->Integrator_DSTATE_f[2] = localP->Integrator_LowerSat_p;
      }
    }
  }

  if (localDW->Integrator_DSTATE_f[0] >= localP->Integrator_UpperSat_o) {
    localDW->Integrator_DSTATE_f[0] = localP->Integrator_UpperSat_o;
  } else {
    if (localDW->Integrator_DSTATE_f[0] <= localP->Integrator_LowerSat_p) {
      localDW->Integrator_DSTATE_f[0] = localP->Integrator_LowerSat_p;
    }
  }

  if (localDW->Integrator_DSTATE_f[1] >= localP->Integrator_UpperSat_o) {
    localDW->Integrator_DSTATE_f[1] = localP->Integrator_UpperSat_o;
  } else {
    if (localDW->Integrator_DSTATE_f[1] <= localP->Integrator_LowerSat_p) {
      localDW->Integrator_DSTATE_f[1] = localP->Integrator_LowerSat_p;
    }
  }

  if (localDW->Integrator_DSTATE_f[2] >= localP->Integrator_UpperSat_o) {
    localDW->Integrator_DSTATE_f[2] = localP->Integrator_UpperSat_o;
  } else {
    if (localDW->Integrator_DSTATE_f[2] <= localP->Integrator_LowerSat_p) {
      localDW->Integrator_DSTATE_f[2] = localP->Integrator_LowerSat_p;
    }
  }

  /* Saturate: '<S32>/Saturation' incorporates:
   *  DiscreteIntegrator: '<S32>/Integrator'
   */
  if (localDW->Integrator_DSTATE_f[0] > localP->Saturation_UpperSat_d) {
    /* Saturate: '<S32>/Saturation' */
    localB->Saturation_d[0] = localP->Saturation_UpperSat_d;
  } else if (localDW->Integrator_DSTATE_f[0] < localP->Saturation_LowerSat_f) {
    /* Saturate: '<S32>/Saturation' */
    localB->Saturation_d[0] = localP->Saturation_LowerSat_f;
  } else {
    /* Saturate: '<S32>/Saturation' */
    localB->Saturation_d[0] = localDW->Integrator_DSTATE_f[0];
  }

  if (localDW->Integrator_DSTATE_f[1] > localP->Saturation_UpperSat_d) {
    /* Saturate: '<S32>/Saturation' */
    localB->Saturation_d[1] = localP->Saturation_UpperSat_d;
  } else if (localDW->Integrator_DSTATE_f[1] < localP->Saturation_LowerSat_f) {
    /* Saturate: '<S32>/Saturation' */
    localB->Saturation_d[1] = localP->Saturation_LowerSat_f;
  } else {
    /* Saturate: '<S32>/Saturation' */
    localB->Saturation_d[1] = localDW->Integrator_DSTATE_f[1];
  }

  if (localDW->Integrator_DSTATE_f[2] > localP->Saturation_UpperSat_d) {
    /* Saturate: '<S32>/Saturation' */
    localB->Saturation_d[2] = localP->Saturation_UpperSat_d;
  } else if (localDW->Integrator_DSTATE_f[2] < localP->Saturation_LowerSat_f) {
    /* Saturate: '<S32>/Saturation' */
    localB->Saturation_d[2] = localP->Saturation_LowerSat_f;
  } else {
    /* Saturate: '<S32>/Saturation' */
    localB->Saturation_d[2] = localDW->Integrator_DSTATE_f[2];
  }

  /* End of Saturate: '<S32>/Saturation' */

  /* MATLAB Function: '<S17>/L1 State Predictor' */
  localB->y = (real32_T)(1.0 / flightControlSystem_P.mass) * localB->Gain1_g;
  localB->scale = 1.0 / flightControlSystem_P.mass;
  localB->DigitalClock = 1.0 / flightControlSystem_P.mass;
  localB->t = 1.0 / flightControlSystem_P.mass;
  flightControlSystem_inv(flightControlSystem_P.J, localB->dv, localB);
  for (localB->j = 0; localB->j < 9; localB->j++) {
    localB->Delay[localB->j] = (real32_T)localB->dv[localB->j];
  }

  for (localB->j = 0; localB->j < 3; localB->j++) {
    localB->c_a[localB->j] = localB->R[localB->j + 6] * (real32_T)localB->scale;
    localB->unnamed_idx_0 = localB->Delay[localB->j];
    localB->i = 6 * (localB->j + 1);
    localB->c_a[localB->i] = 0.0F;
    localB->unnamed_idx_1 = localB->unnamed_idx_0 * localB->ct[0];
    localB->unnamed_idx_2 = localB->unnamed_idx_0 * localB->st_tmp;
    localB->unnamed_idx_0 = localB->Delay[localB->j + 3];
    localB->c_a[localB->i + 1] = 0.0F;
    localB->unnamed_idx_1 += localB->unnamed_idx_0 * localB->ct[1];
    localB->unnamed_idx_2 += localB->unnamed_idx_0 * localB->st_tmp_h;
    localB->unnamed_idx_0 = localB->Delay[localB->j + 6];
    localB->c_a[localB->i + 2] = 0.0F;
    localB->unnamed_idx_1 += localB->unnamed_idx_0 * localB->ct[2];
    localB->unnamed_idx_2 += localB->unnamed_idx_0 * localB->st_tmp_b;
    localB->c_a[localB->j + 3] = 0.0F;
    localB->c_a[localB->i + 3] = localB->Delay[3 * localB->j];
    localB->c_a[localB->i + 4] = localB->Delay[3 * localB->j + 1];
    localB->c_a[localB->i + 5] = localB->Delay[3 * localB->j + 2];
    localB->st[localB->j] = localB->unnamed_idx_1;
    localB->Reshapey[localB->j] = localB->unnamed_idx_2;
  }

  /* SignalConversion generated from: '<S39>/ SFunction ' incorporates:
   *  MATLAB Function: '<S17>/L1 State Predictor'
   */
  localB->unnamed_idx_0 = (real32_T)(localB->Saturation + localB->DTC3[0]);
  localB->unnamed_idx_1 = (real32_T)(localB->Saturation_d[0] + localB->DTC3[1]);
  localB->unnamed_idx_2 = (real32_T)(localB->Saturation_d[1] + localB->DTC3[2]);
  localB->st_tmp = (real32_T)(localB->Saturation_d[2] + localB->DTC3[3]);

  /* MATLAB Function: '<S17>/L1 State Predictor' incorporates:
   *  MATLAB Function: '<S2>/MATLAB Function2'
   */
  localB->c[0] = localB->y * localB->R[6];
  localB->c[3] = localB->st[0] - localB->Reshapey[0];
  localB->c[1] = localB->y * localB->R[7];
  localB->c[4] = localB->st[1] - localB->Reshapey[1];
  localB->c[2] = localB->y * localB->R[8] + 9.81F;
  localB->c[5] = localB->st[2] - localB->Reshapey[2];
  for (localB->j = 0; localB->j < 6; localB->j++) {
    localB->y = localB->c_a[localB->j + 18] * localB->st_tmp + (localB->
      c_a[localB->j + 12] * localB->unnamed_idx_2 + (localB->c_a[localB->j + 6] *
      localB->unnamed_idx_1 + localB->c_a[localB->j] * localB->unnamed_idx_0));
    localB->c_a_b[localB->j] = localB->y;
  }

  localB->d_a[0] = (real32_T)localB->DigitalClock * localB->R[0];
  localB->d_a[6] = (real32_T)localB->t * localB->R[3];
  localB->d_a[1] = (real32_T)localB->DigitalClock * localB->R[1];
  localB->d_a[7] = (real32_T)localB->t * localB->R[4];
  localB->d_a[2] = (real32_T)localB->DigitalClock * -localB->sy;
  localB->d_a[8] = (real32_T)localB->t * localB->R[5];
  for (localB->j = 0; localB->j < 2; localB->j++) {
    localB->d_a[6 * localB->j + 3] = 0.0F;
    localB->d_a[6 * localB->j + 4] = 0.0F;
    localB->d_a[6 * localB->j + 5] = 0.0F;
  }

  localB->fv2[0] = localB->DataTypeConversion_p;
  localB->fv2[3] = localB->f_l;
  localB->fv2[1] = localB->f1;
  localB->fv2[4] = localB->f2;
  localB->fv2[2] = localB->f3;
  localB->fv2[5] = localB->f4;
  for (localB->j = 0; localB->j < 6; localB->j++) {
    localB->fv3[localB->j] = 0.0F;
    for (localB->i = 0; localB->i < 6; localB->i++) {
      localB->fv3[localB->j] += (real32_T)flightControlSystem_P.As[6 * localB->i
        + localB->j] * localB->fv2[localB->i];
    }

    /* DataTypeConversion: '<S17>/DTC1' incorporates:
     *  Delay: '<S17>/Delay2'
     */
    localB->DTC1[localB->j] = (((localB->d_a[localB->j + 6] * (real32_T)
      localB->DTC3[5] + localB->d_a[localB->j] * (real32_T)localB->DTC3[4]) +
      (localB->c[localB->j] + localB->c_a_b[localB->j])) + localB->fv3[localB->j])
      * (real32_T)flightControlSystem_P.Ts + (real32_T)localDW->
      Delay2_DSTATE[localB->j];
  }

  /* SignalConversion generated from: '<S43>/ SFunction ' incorporates:
   *  MATLAB Function: '<S44>/MATLAB Function4'
   *  MATLAB Function: '<S4>/MATLAB Function'
   */
  localB->Add[0] = localB->FIR_IMUaccel[0];
  localB->Add[1] = localB->FIR_IMUaccel[1];
  localB->Add[2] = localB->FIR_IMUaccel[2];
  localB->Add[3] = localB->DataTypeConversion[3];
  localB->Add[4] = localB->rtb_y_idx_1;
  localB->Add[5] = localB->rtb_y_idx_0;

  /* MATLAB Function: '<S4>/MATLAB Function' */
  localB->dcmm[0] = localB->rtb_Add_dy * localB->rtb_Add_d;
  localB->rtb_y_idx_0 = localB->st_tmp_d * localB->sy;
  localB->dcmm[3] = localB->rtb_y_idx_0 * localB->rtb_Add_d - localB->rtb_Add_lx
    * localB->rtb_Add_l;
  localB->rtb_y_idx_1 = localB->rtb_Add_lx * localB->sy;
  localB->dcmm[6] = localB->rtb_y_idx_1 * localB->rtb_Add_d + localB->st_tmp_d *
    localB->rtb_Add_l;
  localB->dcmm[1] = localB->rtb_Add_dy * localB->rtb_Add_l;
  localB->dcmm[4] = localB->rtb_y_idx_0 * localB->rtb_Add_l + localB->rtb_Add_lx
    * localB->rtb_Add_d;
  localB->dcmm[7] = localB->rtb_y_idx_1 * localB->rtb_Add_l - localB->st_tmp_d *
    localB->rtb_Add_d;
  localB->dcmm[2] = -localB->sy;
  localB->dcmm[5] = localB->st_tmp_d * localB->rtb_Add_dy;
  localB->dcmm[8] = localB->rtb_Add_lx * localB->rtb_Add_dy;
  for (localB->j = 0; localB->j < 3; localB->j++) {
    localB->Reshapey[localB->j] = localB->Add[localB->j] - ((localB->dcmm[3 *
      localB->j + 1] * 0.0F + localB->dcmm[3 * localB->j] * 0.0F) + localB->
      dcmm[3 * localB->j + 2] * -9.81F);
  }

  for (localB->j = 0; localB->j < 3; localB->j++) {
    localB->st[localB->j] = localB->dcmm[localB->j + 6] * localB->Reshapey[2] +
      (localB->dcmm[localB->j + 3] * localB->Reshapey[1] + localB->dcmm
       [localB->j] * localB->Reshapey[0]);
  }

  localB->acc[0] = localB->st[0] * 0.005F;
  localB->acc[1] = localB->st[1] * 0.005F;
  localB->acc[2] = localB->st[2] * 0.005F;
  for (localB->i = 0; localB->i < 6; localB->i++) {
    /* DataTypeConversion: '<S171>/Conversion' incorporates:
     *  Delay: '<S42>/MemoryX'
     */
    localB->Conversion_e[localB->i] = localDW->MemoryX_DSTATE[localB->i];
  }

  /* Outputs for Enabled SubSystem: '<S175>/MeasurementUpdate' incorporates:
   *  EnablePort: '<S204>/Enable'
   */
  /* Constant: '<S42>/Enable' */
  if (localP->Enable_Value) {
    localDW->MeasurementUpdate_MODE = true;

    /* Product: '<S204>/C[k]*xhat[k|k-1]' incorporates:
     *  Constant: '<S42>/C'
     */
    for (localB->j = 0; localB->j < 3; localB->j++) {
      localB->Reshapey[localB->j] = 0.0F;
      for (localB->i = 0; localB->i < 6; localB->i++) {
        localB->Reshapey[localB->j] += localP->C_Value[3 * localB->i + localB->j]
          * localB->Conversion_e[localB->i];
      }
    }

    /* End of Product: '<S204>/C[k]*xhat[k|k-1]' */

    /* Product: '<S204>/D[k]*u[k]' incorporates:
     *  Constant: '<S42>/D'
     *  Reshape: '<S42>/Reshapeu'
     */
    for (localB->j = 0; localB->j < 3; localB->j++) {
      localB->st[localB->j] = localP->D_Value[localB->j + 6] * localB->acc[2] +
        (localP->D_Value[localB->j + 3] * localB->acc[1] + localP->
         D_Value[localB->j] * localB->acc[0]);
    }

    /* End of Product: '<S204>/D[k]*u[k]' */

    /* Sum: '<S204>/Sum' incorporates:
     *  Reshape: '<S42>/Reshapey'
     *  Sum: '<S204>/Add1'
     */
    localB->rtb_Add_l = localB->DataTypeConversion[0] - (localB->Reshapey[0] +
      localB->st[0]);
    localB->rtb_Add_d = localB->Gain1 - (localB->Reshapey[1] + localB->st[1]);
    localB->sy = localB->Gain - (localB->Reshapey[2] + localB->st[2]);
    for (localB->j = 0; localB->j < 6; localB->j++) {
      /* Product: '<S204>/Product3' incorporates:
       *  DataTypeConversion: '<S198>/Conversion'
       */
      localB->Product3[localB->j] = 0.0F;
      localB->Product3[localB->j] += localB->Conversion_b[localB->j] *
        localB->rtb_Add_l;
      localB->Product3[localB->j] += localB->Conversion_b[localB->j + 6] *
        localB->rtb_Add_d;
      localB->Product3[localB->j] += localB->Conversion_b[localB->j + 12] *
        localB->sy;
    }
  } else {
    if (localDW->MeasurementUpdate_MODE) {
      for (localB->i = 0; localB->i < 6; localB->i++) {
        /* Disable for Product: '<S204>/Product3' incorporates:
         *  Outport: '<S204>/L*(y[k]-yhat[k|k-1])'
         */
        localB->Product3[localB->i] = localP->Lykyhatkk1_Y0;
      }

      localDW->MeasurementUpdate_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S175>/MeasurementUpdate' */

  /* Product: '<S175>/B[k]*u[k]' incorporates:
   *  Constant: '<S42>/B'
   *  Reshape: '<S42>/Reshapeu'
   */
  for (localB->j = 0; localB->j < 6; localB->j++) {
    localB->fv2[localB->j] = localP->B_Value[localB->j + 12] * localB->acc[2] +
      (localP->B_Value[localB->j + 6] * localB->acc[1] + localP->B_Value
       [localB->j] * localB->acc[0]);
  }

  /* End of Product: '<S175>/B[k]*u[k]' */

  /* Product: '<S175>/A[k]*xhat[k|k-1]' incorporates:
   *  Constant: '<S42>/A'
   */
  for (localB->j = 0; localB->j < 6; localB->j++) {
    localB->fv3[localB->j] = 0.0F;
    for (localB->i = 0; localB->i < 6; localB->i++) {
      localB->fv3[localB->j] += localP->A_Value[6 * localB->i + localB->j] *
        localB->Conversion_e[localB->i];
    }
  }

  /* End of Product: '<S175>/A[k]*xhat[k|k-1]' */
  for (localB->j = 0; localB->j < 6; localB->j++) {
    /* Reshape: '<S175>/Reshape' incorporates:
     *  Sum: '<S175>/Add'
     */
    localB->Reshape[localB->j] = (localB->fv2[localB->j] + localB->fv3[localB->j])
      + localB->Product3[localB->j];
  }

  /* Switch: '<S15>/Switch1' incorporates:
   *  Constant: '<S15>/Constant'
   *  Constant: '<S15>/Constant1'
   */
  if (localP->Constant_Value_g > localP->Switch1_Threshold) {
    localB->scale = localB->Saturation_d[0];
  } else {
    localB->scale = localP->Constant1_Value;
  }

  /* Sum: '<S5>/Sum3' */
  localB->DigitalClock = localB->ct[0] + localB->scale;

  /* Switch: '<S15>/Switch1' incorporates:
   *  Constant: '<S15>/Constant'
   *  Constant: '<S15>/Constant1'
   */
  if (localP->Constant_Value_g > localP->Switch1_Threshold) {
    localB->scale = localB->Saturation_d[1];
  } else {
    localB->scale = localP->Constant1_Value;
  }

  /* Sum: '<S5>/Sum3' */
  localB->t = localB->ct[1] + localB->scale;

  /* Switch: '<S15>/Switch1' incorporates:
   *  Constant: '<S15>/Constant'
   *  Constant: '<S15>/Constant1'
   */
  if (localP->Constant_Value_g > localP->Switch1_Threshold) {
    localB->scale = localB->Saturation_d[2];
  } else {
    localB->scale = localP->Constant1_Value;
  }

  /* Sum: '<S5>/Sum3' */
  localB->rtb_b1d_idx_2 = localB->ct[2] + localB->scale;

  /* Sum: '<S5>/Sum2' incorporates:
   *  Constant: '<S15>/Constant'
   *  Constant: '<S15>/Constant1'
   *  Switch: '<S15>/Switch'
   */
  if (localP->Constant_Value_g > localP->Switch_Threshold) {
    localB->scale = localB->Saturation;
  } else {
    localB->scale = localP->Constant1_Value;
  }

  /* SignalConversion generated from: '<S10>/Product' incorporates:
   *  Sum: '<S5>/Sum2'
   */
  localB->scale += localB->Gain1_g;

  /* Product: '<S10>/Product' incorporates:
   *  Constant: '<S10>/TorqueTotalThrustToThrustPerMotor'
   *  SignalConversion generated from: '<S10>/Product'
   */
  for (localB->j = 0; localB->j < 4; localB->j++) {
    localB->a_tmp = localB->TorqueTotalThrustToThrustPerMotor[localB->j + 12] *
      localB->DigitalClock + (localB->TorqueTotalThrustToThrustPerMotor
      [localB->j + 8] * localB->t + (localB->
      TorqueTotalThrustToThrustPerMotor[localB->j + 4] * localB->rtb_b1d_idx_2 +
      localB->TorqueTotalThrustToThrustPerMotor[localB->j] * localB->scale));
    localB->rtb_TorqueTotalThrustToThrustPe[localB->j] = localB->a_tmp;
  }

  /* End of Product: '<S10>/Product' */

  /* Saturate: '<S13>/Saturation5' incorporates:
   *  Gain: '<S13>/MotorDirections'
   *  Gain: '<S13>/ThrustToMotorCommand'
   */
  localB->scale = -flightControlSystem_P.Vehicle.Motor.thrustToMotorCommand *
    localB->rtb_TorqueTotalThrustToThrustPe[0];
  if (localB->scale > localP->Saturation5_UpperSat) {
    localB->scale = localP->Saturation5_UpperSat;
  } else {
    if (localB->scale < localP->Saturation5_LowerSat) {
      localB->scale = localP->Saturation5_LowerSat;
    }
  }

  /* Gain: '<S13>/MotorDirections' incorporates:
   *  Saturate: '<S13>/Saturation5'
   */
  motors_outport[0] = localP->MotorDirections_Gain[0] * (real32_T)localB->scale;

  /* Saturate: '<S13>/Saturation5' incorporates:
   *  Gain: '<S13>/MotorDirections'
   *  Gain: '<S13>/ThrustToMotorCommand'
   */
  localB->scale = -flightControlSystem_P.Vehicle.Motor.thrustToMotorCommand *
    localB->rtb_TorqueTotalThrustToThrustPe[1];
  if (localB->scale > localP->Saturation5_UpperSat) {
    localB->scale = localP->Saturation5_UpperSat;
  } else {
    if (localB->scale < localP->Saturation5_LowerSat) {
      localB->scale = localP->Saturation5_LowerSat;
    }
  }

  /* Gain: '<S13>/MotorDirections' incorporates:
   *  Saturate: '<S13>/Saturation5'
   */
  motors_outport[1] = localP->MotorDirections_Gain[1] * (real32_T)localB->scale;

  /* Saturate: '<S13>/Saturation5' incorporates:
   *  Gain: '<S13>/MotorDirections'
   *  Gain: '<S13>/ThrustToMotorCommand'
   */
  localB->scale = -flightControlSystem_P.Vehicle.Motor.thrustToMotorCommand *
    localB->rtb_TorqueTotalThrustToThrustPe[2];
  if (localB->scale > localP->Saturation5_UpperSat) {
    localB->scale = localP->Saturation5_UpperSat;
  } else {
    if (localB->scale < localP->Saturation5_LowerSat) {
      localB->scale = localP->Saturation5_LowerSat;
    }
  }

  /* Gain: '<S13>/MotorDirections' incorporates:
   *  Saturate: '<S13>/Saturation5'
   */
  motors_outport[2] = localP->MotorDirections_Gain[2] * (real32_T)localB->scale;

  /* Saturate: '<S13>/Saturation5' incorporates:
   *  Gain: '<S13>/MotorDirections'
   *  Gain: '<S13>/ThrustToMotorCommand'
   */
  localB->scale = -flightControlSystem_P.Vehicle.Motor.thrustToMotorCommand *
    localB->rtb_TorqueTotalThrustToThrustPe[3];
  if (localB->scale > localP->Saturation5_UpperSat) {
    localB->scale = localP->Saturation5_UpperSat;
  } else {
    if (localB->scale < localP->Saturation5_LowerSat) {
      localB->scale = localP->Saturation5_LowerSat;
    }
  }

  /* Gain: '<S13>/MotorDirections' incorporates:
   *  Saturate: '<S13>/Saturation5'
   */
  motors_outport[3] = localP->MotorDirections_Gain[3] * (real32_T)localB->scale;

  /* DataTypeConversion: '<S5>/DTC4' */
  localB->DTC4[0] = motors_outport[0];
  localB->DTC4[1] = motors_outport[1];
  localB->DTC4[2] = motors_outport[2];
  localB->DTC4[3] = motors_outport[3];

  /* RelationalOperator: '<S36>/Compare' incorporates:
   *  Constant: '<S33>/Time constant'
   *  Constant: '<S36>/Constant'
   *  Sum: '<S33>/Sum1'
   */
  localB->Compare_e = (localP->LowPassFilterDiscreteorContinuous3_T
                       - localB->Probe_j[0] <= localP->Constant_Value_m);

  /* Constant: '<S37>/Constant' */
  localB->Constant_c = localP->LowPassFilterDiscreteorContinuous3_x0;

  /* DiscreteIntegrator: '<S38>/Integrator' */
  if (localB->Compare_e || (localDW->Integrator_PrevResetState_l != 0)) {
    localDW->Integrator_DSTATE_m[0] = localB->Constant_c;
    if (localDW->Integrator_DSTATE_m[0] >= localP->Integrator_UpperSat_l) {
      localDW->Integrator_DSTATE_m[0] = localP->Integrator_UpperSat_l;
    } else {
      if (localDW->Integrator_DSTATE_m[0] <= localP->Integrator_LowerSat_c) {
        localDW->Integrator_DSTATE_m[0] = localP->Integrator_LowerSat_c;
      }
    }

    localDW->Integrator_DSTATE_m[1] = localB->Constant_c;
    if (localDW->Integrator_DSTATE_m[1] >= localP->Integrator_UpperSat_l) {
      localDW->Integrator_DSTATE_m[1] = localP->Integrator_UpperSat_l;
    } else {
      if (localDW->Integrator_DSTATE_m[1] <= localP->Integrator_LowerSat_c) {
        localDW->Integrator_DSTATE_m[1] = localP->Integrator_LowerSat_c;
      }
    }

    localDW->Integrator_DSTATE_m[2] = localB->Constant_c;
    if (localDW->Integrator_DSTATE_m[2] >= localP->Integrator_UpperSat_l) {
      localDW->Integrator_DSTATE_m[2] = localP->Integrator_UpperSat_l;
    } else {
      if (localDW->Integrator_DSTATE_m[2] <= localP->Integrator_LowerSat_c) {
        localDW->Integrator_DSTATE_m[2] = localP->Integrator_LowerSat_c;
      }
    }
  }

  if (localDW->Integrator_DSTATE_m[0] >= localP->Integrator_UpperSat_l) {
    localDW->Integrator_DSTATE_m[0] = localP->Integrator_UpperSat_l;
  } else {
    if (localDW->Integrator_DSTATE_m[0] <= localP->Integrator_LowerSat_c) {
      localDW->Integrator_DSTATE_m[0] = localP->Integrator_LowerSat_c;
    }
  }

  if (localDW->Integrator_DSTATE_m[1] >= localP->Integrator_UpperSat_l) {
    localDW->Integrator_DSTATE_m[1] = localP->Integrator_UpperSat_l;
  } else {
    if (localDW->Integrator_DSTATE_m[1] <= localP->Integrator_LowerSat_c) {
      localDW->Integrator_DSTATE_m[1] = localP->Integrator_LowerSat_c;
    }
  }

  if (localDW->Integrator_DSTATE_m[2] >= localP->Integrator_UpperSat_l) {
    localDW->Integrator_DSTATE_m[2] = localP->Integrator_UpperSat_l;
  } else {
    if (localDW->Integrator_DSTATE_m[2] <= localP->Integrator_LowerSat_c) {
      localDW->Integrator_DSTATE_m[2] = localP->Integrator_LowerSat_c;
    }
  }

  /* Saturate: '<S38>/Saturation' incorporates:
   *  DiscreteIntegrator: '<S38>/Integrator'
   */
  if (localDW->Integrator_DSTATE_m[0] > localP->Saturation_UpperSat_j) {
    /* Saturate: '<S38>/Saturation' */
    localB->Saturation_i[0] = localP->Saturation_UpperSat_j;
  } else if (localDW->Integrator_DSTATE_m[0] < localP->Saturation_LowerSat_m) {
    /* Saturate: '<S38>/Saturation' */
    localB->Saturation_i[0] = localP->Saturation_LowerSat_m;
  } else {
    /* Saturate: '<S38>/Saturation' */
    localB->Saturation_i[0] = localDW->Integrator_DSTATE_m[0];
  }

  if (localDW->Integrator_DSTATE_m[1] > localP->Saturation_UpperSat_j) {
    /* Saturate: '<S38>/Saturation' */
    localB->Saturation_i[1] = localP->Saturation_UpperSat_j;
  } else if (localDW->Integrator_DSTATE_m[1] < localP->Saturation_LowerSat_m) {
    /* Saturate: '<S38>/Saturation' */
    localB->Saturation_i[1] = localP->Saturation_LowerSat_m;
  } else {
    /* Saturate: '<S38>/Saturation' */
    localB->Saturation_i[1] = localDW->Integrator_DSTATE_m[1];
  }

  if (localDW->Integrator_DSTATE_m[2] > localP->Saturation_UpperSat_j) {
    /* Saturate: '<S38>/Saturation' */
    localB->Saturation_i[2] = localP->Saturation_UpperSat_j;
  } else if (localDW->Integrator_DSTATE_m[2] < localP->Saturation_LowerSat_m) {
    /* Saturate: '<S38>/Saturation' */
    localB->Saturation_i[2] = localP->Saturation_LowerSat_m;
  } else {
    /* Saturate: '<S38>/Saturation' */
    localB->Saturation_i[2] = localDW->Integrator_DSTATE_m[2];
  }

  /* End of Saturate: '<S38>/Saturation' */

  /* MinMax: '<S33>/Max' incorporates:
   *  Constant: '<S33>/Time constant'
   */
  localB->scale = fmax(localB->Probe_j[0],
                       localP->LowPassFilterDiscreteorContinuous3_T);

  /* Fcn: '<S33>/Avoid Divide by Zero' */
  localB->scale += (real_T)(localB->scale == 0.0) * 2.2204460492503131e-16;

  /* Product: '<S20>/1//T' incorporates:
   *  DataTypeConversion: '<S16>/DTC2'
   *  Gain: '<S20>/K'
   *  MATLAB Function: '<S6>/L1 Adaptation Law'
   *  Sum: '<S20>/Sum1'
   */
  localB->uT[0] = (localP->LowPassFilterDiscreteorContinuous3_K * -localB->
                   sigma[1] - localB->Saturation_i[0]) * (1.0 / localB->scale);
  localB->uT[1] = (localP->LowPassFilterDiscreteorContinuous3_K * -localB->
                   sigma[2] - localB->Saturation_i[1]) * (1.0 / localB->scale);
  localB->uT[2] = (localP->LowPassFilterDiscreteorContinuous3_K * -localB->
                   sigma[3] - localB->Saturation_i[2]) * (1.0 / localB->scale);

  /* MinMax: '<S27>/Max' incorporates:
   *  Constant: '<S27>/Time constant'
   */
  localB->scale = fmax(localB->Probe_h[0],
                       localP->LowPassFilterDiscreteorContinuous2_T);

  /* Fcn: '<S27>/Avoid Divide by Zero' */
  localB->scale += (real_T)(localB->scale == 0.0) * 2.2204460492503131e-16;

  /* Product: '<S19>/1//T' incorporates:
   *  Gain: '<S19>/K'
   *  Sum: '<S19>/Sum1'
   */
  localB->uT_i[0] = (localP->LowPassFilterDiscreteorContinuous2_K *
                     localB->Saturation_i[0] - localB->Saturation_d[0]) * (1.0 /
    localB->scale);
  localB->uT_i[1] = (localP->LowPassFilterDiscreteorContinuous2_K *
                     localB->Saturation_i[1] - localB->Saturation_d[1]) * (1.0 /
    localB->scale);
  localB->uT_i[2] = (localP->LowPassFilterDiscreteorContinuous2_K *
                     localB->Saturation_i[2] - localB->Saturation_d[2]) * (1.0 /
    localB->scale);

  /* DataTypeConversion: '<S3>/DTC1' */
  localB->DTC1_g[0] = (real32_T)localB->xd[0];
  localB->DTC1_g[1] = (real32_T)localB->xd[1];
  localB->DTC1_g[2] = (real32_T)localB->xd[2];

  /* DataTypeConversion: '<S41>/Data Type Conversion1' */
  localB->DataTypeConversion1_g[0] = localB->p;
  localB->DataTypeConversion1_g[1] = localB->q;
  localB->DataTypeConversion1_g[2] = localB->r;

  /* DataTypeConversion: '<S119>/Conversion' */
  localB->Conversion_m[0] = localB->MemoryX_j[0];
  localB->Conversion_m[1] = localB->MemoryX_j[1];

  /* Reshape: '<S103>/Reshapeu' */
  localB->Reshapeu_e = localB->p;

  /* DataTypeConversion: '<S146>/Conversion' incorporates:
   *  Constant: '<S104>/KalmanGainL'
   */
  localB->Conversion_pu[0] = (real32_T)localP->KalmanGainL_Value_b[0];
  localB->Conversion_pu[1] = (real32_T)localP->KalmanGainL_Value_b[1];

  /* Outputs for Enabled SubSystem: '<S123>/MeasurementUpdate' */
  /* Constant: '<S103>/C' incorporates:
   *  Constant: '<S103>/D'
   */
  flightControlSystem_MeasurementUpdate(rtb_DataTypeConversionEnable,
    localB->Conversion_pu, localB->Reshapey_k, localP->C_Value_g,
    localB->Conversion_m, localP->D_Value_n, localB->Reshapeu_e,
    &localB->MeasurementUpdate_o, &localDW->MeasurementUpdate_o,
    &localP->MeasurementUpdate_o);

  /* End of Outputs for SubSystem: '<S123>/MeasurementUpdate' */

  /* Reshape: '<S123>/Reshape' incorporates:
   *  Constant: '<S103>/A'
   *  Constant: '<S103>/B'
   *  Product: '<S123>/A[k]*xhat[k|k-1]'
   *  Product: '<S123>/B[k]*u[k]'
   *  Product: '<S152>/Product3'
   *  Sum: '<S123>/Add'
   */
  localB->Reshape_n[0] = ((localP->A_Value_n4[0] * localB->Conversion_m[0] +
    localP->A_Value_n4[2] * localB->Conversion_m[1]) + localP->B_Value_p[0] *
    localB->Reshapeu_e) + localB->MeasurementUpdate_o.Product3[0];
  localB->Reshape_n[1] = ((localP->A_Value_n4[1] * localB->Conversion_m[0] +
    localP->A_Value_n4[3] * localB->Conversion_m[1]) + localP->B_Value_p[1] *
    localB->Reshapeu_e) + localB->MeasurementUpdate_o.Product3[1];

  /* DataTypeConversion: '<S67>/Conversion' */
  localB->Conversion_h[0] = localB->MemoryX_h[0];
  localB->Conversion_h[1] = localB->MemoryX_h[1];

  /* Reshape: '<S51>/Reshapeu' */
  localB->Reshapeu_l = localB->q;

  /* DataTypeConversion: '<S94>/Conversion' incorporates:
   *  Constant: '<S52>/KalmanGainL'
   */
  localB->Conversion_h2[0] = (real32_T)localP->KalmanGainL_Value_h[0];
  localB->Conversion_h2[1] = (real32_T)localP->KalmanGainL_Value_h[1];

  /* Outputs for Enabled SubSystem: '<S71>/MeasurementUpdate' */
  /* Constant: '<S51>/C' incorporates:
   *  Constant: '<S51>/D'
   */
  flightControlSystem_MeasurementUpdate(rtb_DataTypeConversionEnable_f,
    localB->Conversion_h2, localB->Reshapey_d, localP->C_Value_c,
    localB->Conversion_h, localP->D_Value_c, localB->Reshapeu_l,
    &localB->MeasurementUpdate, &localDW->MeasurementUpdate,
    &localP->MeasurementUpdate);

  /* End of Outputs for SubSystem: '<S71>/MeasurementUpdate' */

  /* Reshape: '<S71>/Reshape' incorporates:
   *  Constant: '<S51>/A'
   *  Constant: '<S51>/B'
   *  Product: '<S100>/Product3'
   *  Product: '<S71>/A[k]*xhat[k|k-1]'
   *  Product: '<S71>/B[k]*u[k]'
   *  Sum: '<S71>/Add'
   */
  localB->Reshape_a[0] = ((localP->A_Value_n[0] * localB->Conversion_h[0] +
    localP->A_Value_n[2] * localB->Conversion_h[1]) + localP->B_Value_o[0] *
    localB->Reshapeu_l) + localB->MeasurementUpdate.Product3[0];
  localB->Reshape_a[1] = ((localP->A_Value_n[1] * localB->Conversion_h[0] +
    localP->A_Value_n[3] * localB->Conversion_h[1]) + localP->B_Value_o[1] *
    localB->Reshapeu_l) + localB->MeasurementUpdate.Product3[1];

  /* MinMax: '<S21>/Max' incorporates:
   *  Constant: '<S21>/Time constant'
   */
  localB->scale = fmax(localB->Probe[0],
                       localP->LowPassFilterDiscreteorContinuous1_T);

  /* Product: '<S18>/1//T' incorporates:
   *  DataTypeConversion: '<S16>/DTC2'
   *  Fcn: '<S21>/Avoid Divide by Zero'
   *  Gain: '<S18>/K'
   *  MATLAB Function: '<S6>/L1 Adaptation Law'
   *  Sum: '<S18>/Sum1'
   */
  localB->uT_p = 1.0 / ((real_T)(localB->scale == 0.0) * 2.2204460492503131e-16
                        + localB->scale) *
    (localP->LowPassFilterDiscreteorContinuous1_K * -localB->sigma[0] -
     localB->Saturation);

  /* DataTypeConversion: '<S48>/single1' incorporates:
   *  Sum: '<S78>/Add'
   */
  rtb_single1 = localB->EnabledSubsystem.Product2[0] + localB->MemoryX_h[0];

  /* DataTypeConversion: '<S49>/Data Type Conversion1' incorporates:
   *  Sum: '<S130>/Add'
   */
  rtb_DataTypeConversion1_b = localB->EnabledSubsystem_m.Product2[0] +
    localB->MemoryX_j[0];

  /* Sum: '<S217>/FixPt Sum1' incorporates:
   *  Constant: '<S217>/FixPt Constant'
   */
  localB->FixPtSum1 = rtb_Output + localP->FixPtConstant_Value;

  /* Switch: '<S218>/FixPt Switch' */
  if (localB->FixPtSum1 > localP->WrapToZero_Threshold) {
    /* Switch: '<S218>/FixPt Switch' incorporates:
     *  Constant: '<S218>/Constant'
     */
    localB->FixPtSwitch = localP->Constant_Value_n;
  } else {
    /* Switch: '<S218>/FixPt Switch' */
    localB->FixPtSwitch = localB->FixPtSum1;
  }

  /* End of Switch: '<S218>/FixPt Switch' */

  /* Sum: '<S45>/Sum2' incorporates:
   *  DataTypeConversion: '<S45>/Data Type Conversion'
   */
  localB->Sum2_b = rtu_Sensors->HALSensors.HAL_pressure_SI.pressure -
    rtu_Sensors->SensorCalibration[6];
  for (localB->i = 0; localB->i < 36; localB->i++) {
    /* DataTypeConversion: '<S201>/Conversion' incorporates:
     *  Constant: '<S155>/CovarianceZ'
     */
    localB->Conversion_c[localB->i] = (real32_T)localP->CovarianceZ_Value
      [localB->i];
  }

  /* DataTypeConversion: '<S166>/Conversion' incorporates:
   *  Constant: '<S42>/P0'
   */
  memcpy(&localB->Conversion_g[0], &localP->P0_Value[0], 36U * sizeof(real32_T));

  /* DataTypeConversion: '<S97>/Conversion' incorporates:
   *  Constant: '<S52>/CovarianceZ'
   */
  localB->Conversion_i[0] = (real32_T)localP->CovarianceZ_Value_j[0];
  localB->Conversion_i[1] = (real32_T)localP->CovarianceZ_Value_j[1];
  localB->Conversion_i[2] = (real32_T)localP->CovarianceZ_Value_j[2];
  localB->Conversion_i[3] = (real32_T)localP->CovarianceZ_Value_j[3];

  /* DataTypeConversion: '<S62>/Conversion' incorporates:
   *  Constant: '<S51>/P0'
   */
  localB->Conversion_l[0] = localP->P0_Value_e[0];
  localB->Conversion_l[1] = localP->P0_Value_e[1];
  localB->Conversion_l[2] = localP->P0_Value_e[2];
  localB->Conversion_l[3] = localP->P0_Value_e[3];

  /* DataTypeConversion: '<S149>/Conversion' incorporates:
   *  Constant: '<S104>/CovarianceZ'
   */
  localB->Conversion_d[0] = (real32_T)localP->CovarianceZ_Value_d[0];
  localB->Conversion_d[1] = (real32_T)localP->CovarianceZ_Value_d[1];
  localB->Conversion_d[2] = (real32_T)localP->CovarianceZ_Value_d[2];
  localB->Conversion_d[3] = (real32_T)localP->CovarianceZ_Value_d[3];

  /* DataTypeConversion: '<S114>/Conversion' incorporates:
   *  Constant: '<S103>/P0'
   */
  localB->Conversion_lj[0] = localP->P0_Value_c[0];
  localB->Conversion_lj[1] = localP->P0_Value_c[1];
  localB->Conversion_lj[2] = localP->P0_Value_c[2];
  localB->Conversion_lj[3] = localP->P0_Value_c[3];

  /* DataTypeConversion: '<S96>/Conversion' */
  rtb_Conversion_j = 0.0F;

  /* DataTypeConversion: '<S148>/Conversion' */
  rtb_Conversion_lf = 0.0F;

  /* DataTypeConversion: '<S200>/Conversion' */
  rtb_Conversion_n = 0.0F;

  /* DataTypeConversion: '<S1>/Data Type Conversion' incorporates:
   *  Constant: '<S1>/Constant'
   */
  localB->scale = floor(localP->Constant_Value_a);
  if (rtIsNaN(localB->scale) || rtIsInf(localB->scale)) {
    localB->scale = 0.0;
  } else {
    localB->scale = fmod(localB->scale, 256.0);
  }

  /* DataTypeConversion: '<S1>/Data Type Conversion' */
  flag_outport = (uint8_T)(localB->scale < 0.0 ? (int32_T)(uint8_T)-(int8_T)
    (uint8_T)-localB->scale : (int32_T)(uint8_T)localB->scale);

  /* BusAssignment: '<S1>/Control Mode Update' */
  localB->ControlModeUpdate = *rtu_ReferenceValueServerCmds;

  /* BusAssignment: '<S1>/Control Mode Update' incorporates:
   *  Constant: '<S1>/controlModePosVsOrient'
   */
  localB->ControlModeUpdate.controlModePosVSOrient =
    localP->controlModePosVsOrient_Value;
}

/* Update for atomic system: '<Root>/Flight Control System' */
void flightControlSystem_FlightControlSystem_Update
  (B_FlightControlSystem_flightControlSystem_T *localB,
   DW_FlightControlSystem_flightControlSystem_T *localDW,
   P_FlightControlSystem_flightControlSystem_T *localP)
{
  int32_T i;

  /* Update for Delay: '<S44>/Delay' incorporates:
   *  DataTypeConversion: '<S44>/Data Type Conversion1'
   */
  for (i = 0; i < 9; i++) {
    localDW->Delay_DSTATE[i] = localB->DataTypeConversion1[i];
  }

  /* End of Update for Delay: '<S44>/Delay' */

  /* Update for DiscreteFir: '<S45>/FIR_IMUaccel' */
  /* Update circular buffer index */
  localDW->FIR_IMUaccel_circBuf--;
  if (localDW->FIR_IMUaccel_circBuf < 0) {
    localDW->FIR_IMUaccel_circBuf = 4;
  }

  /* Update circular buffer */
  localDW->FIR_IMUaccel_states[localDW->FIR_IMUaccel_circBuf] =
    localB->inverseIMU_gain[0];
  localDW->FIR_IMUaccel_states[localDW->FIR_IMUaccel_circBuf + 5] =
    localB->inverseIMU_gain[1];
  localDW->FIR_IMUaccel_states[localDW->FIR_IMUaccel_circBuf + 10] =
    localB->inverseIMU_gain[2];

  /* End of Update for DiscreteFir: '<S45>/FIR_IMUaccel' */

  /* Update for DiscreteTransferFcn: '<S45>/LPF Fcutoff = 40Hz1' */
  localDW->LPFFcutoff40Hz1_states = localDW->LPFFcutoff40Hz1_tmp;

  /* Update for DiscreteTransferFcn: '<S45>/LPF Fcutoff = 40Hz' */
  localDW->LPFFcutoff40Hz_states = localDW->LPFFcutoff40Hz_tmp;

  /* Update for DiscreteFilter: '<S45>/IIR_IMUgyro_r' */
  localDW->IIR_IMUgyro_r_states[4] = localDW->IIR_IMUgyro_r_states[3];
  localDW->IIR_IMUgyro_r_states[3] = localDW->IIR_IMUgyro_r_states[2];
  localDW->IIR_IMUgyro_r_states[2] = localDW->IIR_IMUgyro_r_states[1];
  localDW->IIR_IMUgyro_r_states[1] = localDW->IIR_IMUgyro_r_states[0];
  localDW->IIR_IMUgyro_r_states[0] = localDW->IIR_IMUgyro_r_tmp;

  /* Update for UnitDelay: '<S215>/Output' */
  localDW->Output_DSTATE = localB->FixPtSwitch;

  /* Update for Delay: '<S42>/MemoryX' */
  localDW->icLoad = 0U;

  /* Update for Delay: '<S103>/MemoryX' */
  localDW->icLoad_p = 0U;

  /* Update for Delay: '<S51>/MemoryX' */
  localDW->icLoad_i = 0U;

  /* Update for Delay: '<S103>/MemoryX' */
  localDW->MemoryX_DSTATE_e[0] = localB->Reshape_n[0];

  /* Update for Delay: '<S51>/MemoryX' */
  localDW->MemoryX_DSTATE_p[0] = localB->Reshape_a[0];

  /* Update for Delay: '<S103>/MemoryX' */
  localDW->MemoryX_DSTATE_e[1] = localB->Reshape_n[1];

  /* Update for Delay: '<S51>/MemoryX' */
  localDW->MemoryX_DSTATE_p[1] = localB->Reshape_a[1];
  for (i = 0; i < 6; i++) {
    /* Update for Delay: '<S42>/MemoryX' */
    localDW->MemoryX_DSTATE[i] = localB->Reshape[i];

    /* Update for Delay: '<S17>/Delay2' */
    localDW->Delay2_DSTATE[i] = localB->DTC1[i];
  }

  /* Update for DiscreteIntegrator: '<S26>/Integrator' */
  localDW->Integrator_DSTATE += localP->Integrator_gainval * localB->uT_p;
  if (localDW->Integrator_DSTATE >= localP->Integrator_UpperSat) {
    localDW->Integrator_DSTATE = localP->Integrator_UpperSat;
  } else {
    if (localDW->Integrator_DSTATE <= localP->Integrator_LowerSat) {
      localDW->Integrator_DSTATE = localP->Integrator_LowerSat;
    }
  }

  localDW->Integrator_PrevResetState = (int8_T)localB->Compare;

  /* End of Update for DiscreteIntegrator: '<S26>/Integrator' */

  /* Update for DiscreteIntegrator: '<S32>/Integrator' */
  localDW->Integrator_PrevResetState_o = (int8_T)localB->Compare_a;
  localDW->Integrator_DSTATE_f[0] += localP->Integrator_gainval_d * localB->
    uT_i[0];
  if (localDW->Integrator_DSTATE_f[0] >= localP->Integrator_UpperSat_o) {
    localDW->Integrator_DSTATE_f[0] = localP->Integrator_UpperSat_o;
  } else {
    if (localDW->Integrator_DSTATE_f[0] <= localP->Integrator_LowerSat_p) {
      localDW->Integrator_DSTATE_f[0] = localP->Integrator_LowerSat_p;
    }
  }

  /* Update for DiscreteIntegrator: '<S38>/Integrator' */
  localDW->Integrator_DSTATE_m[0] += localP->Integrator_gainval_a * localB->uT[0];
  if (localDW->Integrator_DSTATE_m[0] >= localP->Integrator_UpperSat_l) {
    localDW->Integrator_DSTATE_m[0] = localP->Integrator_UpperSat_l;
  } else {
    if (localDW->Integrator_DSTATE_m[0] <= localP->Integrator_LowerSat_c) {
      localDW->Integrator_DSTATE_m[0] = localP->Integrator_LowerSat_c;
    }
  }

  /* Update for DiscreteIntegrator: '<S32>/Integrator' */
  localDW->Integrator_DSTATE_f[1] += localP->Integrator_gainval_d * localB->
    uT_i[1];
  if (localDW->Integrator_DSTATE_f[1] >= localP->Integrator_UpperSat_o) {
    localDW->Integrator_DSTATE_f[1] = localP->Integrator_UpperSat_o;
  } else {
    if (localDW->Integrator_DSTATE_f[1] <= localP->Integrator_LowerSat_p) {
      localDW->Integrator_DSTATE_f[1] = localP->Integrator_LowerSat_p;
    }
  }

  /* Update for DiscreteIntegrator: '<S38>/Integrator' */
  localDW->Integrator_DSTATE_m[1] += localP->Integrator_gainval_a * localB->uT[1];
  if (localDW->Integrator_DSTATE_m[1] >= localP->Integrator_UpperSat_l) {
    localDW->Integrator_DSTATE_m[1] = localP->Integrator_UpperSat_l;
  } else {
    if (localDW->Integrator_DSTATE_m[1] <= localP->Integrator_LowerSat_c) {
      localDW->Integrator_DSTATE_m[1] = localP->Integrator_LowerSat_c;
    }
  }

  /* Update for DiscreteIntegrator: '<S32>/Integrator' */
  localDW->Integrator_DSTATE_f[2] += localP->Integrator_gainval_d * localB->
    uT_i[2];
  if (localDW->Integrator_DSTATE_f[2] >= localP->Integrator_UpperSat_o) {
    localDW->Integrator_DSTATE_f[2] = localP->Integrator_UpperSat_o;
  } else {
    if (localDW->Integrator_DSTATE_f[2] <= localP->Integrator_LowerSat_p) {
      localDW->Integrator_DSTATE_f[2] = localP->Integrator_LowerSat_p;
    }
  }

  /* Update for DiscreteIntegrator: '<S38>/Integrator' */
  localDW->Integrator_DSTATE_m[2] += localP->Integrator_gainval_a * localB->uT[2];
  if (localDW->Integrator_DSTATE_m[2] >= localP->Integrator_UpperSat_l) {
    localDW->Integrator_DSTATE_m[2] = localP->Integrator_UpperSat_l;
  } else {
    if (localDW->Integrator_DSTATE_m[2] <= localP->Integrator_LowerSat_c) {
      localDW->Integrator_DSTATE_m[2] = localP->Integrator_LowerSat_c;
    }
  }

  localDW->Integrator_PrevResetState_l = (int8_T)localB->Compare_e;
}

/* Termination for atomic system: '<Root>/Flight Control System' */
void flightControlSystem_FlightControlSystem_Term(RT_MODEL_flightControlSystem_T
  * const flightControlSystem_M, DW_FlightControlSystem_flightControlSystem_T
  *localDW)
{
  char_T *sErr;

  /* Terminate for S-Function (sdspFromNetwork): '<S4>/UDP Receive1' */
  sErr = GetErrorBuffer(&localDW->UDPReceive1_NetworkLib[0U]);
  LibTerminate(&localDW->UDPReceive1_NetworkLib[0U]);
  if (*sErr != 0) {
    rtmSetErrorStatus(flightControlSystem_M, sErr);
    rtmSetStopRequested(flightControlSystem_M, 1);
  }

  LibDestroy(&localDW->UDPReceive1_NetworkLib[0U], 0);
  DestroyUDPInterface(&localDW->UDPReceive1_NetworkLib[0U]);

  /* End of Terminate for S-Function (sdspFromNetwork): '<S4>/UDP Receive1' */
}

/* Model step function */
void flightControlSystem_step(void)
{
  /* Outputs for Atomic SubSystem: '<Root>/Flight Control System' */

  /* Inport: '<Root>/AC cmd' incorporates:
   *  Inport: '<Root>/Sensors'
   */
  flightControlSystem_FlightControlSystem(flightControlSystem_M, &cmd_inport,
    &sensor_inport, &flightControlSystem_B.FlightControlSystem,
    &flightControlSystem_DW.FlightControlSystem,
    &flightControlSystem_P.FlightControlSystem,
    &flightControlSystem_PrevZCX.FlightControlSystem);

  /* End of Outputs for SubSystem: '<Root>/Flight Control System' */

  /* Outport: '<Root>/Actuators' */
  flightControlSystem_Y.Actuators[0] = motors_outport[0];
  flightControlSystem_Y.Actuators[1] = motors_outport[1];
  flightControlSystem_Y.Actuators[2] = motors_outport[2];
  flightControlSystem_Y.Actuators[3] = motors_outport[3];

  /* Outport: '<Root>/Flag' */
  flightControlSystem_Y.Flag = flag_outport;

  /* Matfile logging */
  rt_UpdateTXYLogVars(flightControlSystem_M->rtwLogInfo,
                      (&flightControlSystem_M->Timing.taskTime0));

  /* Update for Atomic SubSystem: '<Root>/Flight Control System' */
  flightControlSystem_FlightControlSystem_Update
    (&flightControlSystem_B.FlightControlSystem,
     &flightControlSystem_DW.FlightControlSystem,
     &flightControlSystem_P.FlightControlSystem);

  /* End of Update for SubSystem: '<Root>/Flight Control System' */

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.005s, 0.0s] */
    if ((rtmGetTFinal(flightControlSystem_M)!=-1) &&
        !((rtmGetTFinal(flightControlSystem_M)-
           flightControlSystem_M->Timing.taskTime0) >
          flightControlSystem_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(flightControlSystem_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++flightControlSystem_M->Timing.clockTick0)) {
    ++flightControlSystem_M->Timing.clockTickH0;
  }

  flightControlSystem_M->Timing.taskTime0 =
    flightControlSystem_M->Timing.clockTick0 *
    flightControlSystem_M->Timing.stepSize0 +
    flightControlSystem_M->Timing.clockTickH0 *
    flightControlSystem_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void flightControlSystem_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  flightControlSystem_P.FlightControlSystem.Saturation_UpperSat = rtInf;
  flightControlSystem_P.FlightControlSystem.Saturation_LowerSat = rtMinusInf;
  flightControlSystem_P.FlightControlSystem.Saturation_UpperSat_d = rtInf;
  flightControlSystem_P.FlightControlSystem.Saturation_LowerSat_f = rtMinusInf;
  flightControlSystem_P.FlightControlSystem.Saturation_UpperSat_j = rtInf;
  flightControlSystem_P.FlightControlSystem.Saturation_LowerSat_m = rtMinusInf;

  /* initialize real-time model */
  (void) memset((void *)flightControlSystem_M, 0,
                sizeof(RT_MODEL_flightControlSystem_T));
  rtmSetTFinal(flightControlSystem_M, -1);
  flightControlSystem_M->Timing.stepSize0 = 0.005;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    flightControlSystem_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    /*
     * Set pointers to the data and signal info each state
     */
    {
      static int_T rt_LoggedStateWidths[] = {
        6,
        1,
        3,
        3,
        9,
        15,
        1,
        1,
        5,
        6,
        2,
        2,
        1,
        1
      };

      static int_T rt_LoggedStateNumDimensions[] = {
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1
      };

      static int_T rt_LoggedStateDimensions[] = {
        6,
        1,
        3,
        3,
        9,
        15,
        1,
        1,
        5,
        6,
        2,
        2,
        1,
        1
      };

      static boolean_T rt_LoggedStateIsVarDims[] = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0
      };

      static BuiltInDTypeId rt_LoggedStateDataTypeIds[] = {
        SS_DOUBLE,
        SS_DOUBLE,
        SS_DOUBLE,
        SS_DOUBLE,
        SS_SINGLE,
        SS_SINGLE,
        SS_SINGLE,
        SS_SINGLE,
        SS_SINGLE,
        SS_SINGLE,
        SS_SINGLE,
        SS_SINGLE,
        SS_INT32,
        SS_UINT32
      };

      static int_T rt_LoggedStateComplexSignals[] = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0
      };

      static RTWPreprocessingFcnPtr rt_LoggingStatePreprocessingFcnPtrs[] = {
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL)
      };

      static const char_T *rt_LoggedStateLabels[] = {
        "DSTATE",
        "DSTATE",
        "DSTATE",
        "DSTATE",
        "DSTATE",
        "states",
        "states",
        "states",
        "states",
        "DSTATE",
        "DSTATE",
        "DSTATE",
        "circBuf",
        "DSTATE"
      };

      static const char_T *rt_LoggedStateBlockNames[] = {
        "flightControlSystem/Flight Control System/Controller/L1 adaptive controller/StatePredictor/Delay2",
        "flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter\n(Discrete or Continuous)1/Integrator\n(Discrete or Continuous)/Discrete/Integrator",
        "flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter\n(Discrete or Continuous)2/Integrator\n(Discrete or Continuous)/Discrete/Integrator",
        "flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter\n(Discrete or Continuous)3/Integrator\n(Discrete or Continuous)/Discrete/Integrator",
        "flightControlSystem/Flight Control System/State Estimator/Mahony Filter/Delay",
        "flightControlSystem/Flight Control System/State Estimator/SensorPreprocessing/FIR_IMUaccel",
        "flightControlSystem/Flight Control System/State Estimator/SensorPreprocessing/LPF Fcutoff = 40Hz1",
        "flightControlSystem/Flight Control System/State Estimator/SensorPreprocessing/LPF Fcutoff = 40Hz",
        "flightControlSystem/Flight Control System/State Estimator/SensorPreprocessing/IIR_IMUgyro_r",
        "flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/MemoryX",
        "flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/MemoryX",
        "flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/MemoryX",
        "flightControlSystem/Flight Control System/State Estimator/SensorPreprocessing/FIR_IMUaccel",
        "flightControlSystem/Flight Control System/State Estimator/SensorPreprocessing/Temperature Compensation/Counter\nFree-Running/Output"
      };

      static const char_T *rt_LoggedStateNames[] = {
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        ""
      };

      static boolean_T rt_LoggedStateCrossMdlRef[] = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0
      };

      static RTWLogDataTypeConvert rt_RTWLogDataTypeConvert[] = {
        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_SINGLE, SS_SINGLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_SINGLE, SS_SINGLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_SINGLE, SS_SINGLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_SINGLE, SS_SINGLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_SINGLE, SS_SINGLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_SINGLE, SS_SINGLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_SINGLE, SS_SINGLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_SINGLE, SS_SINGLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_INT32, SS_INT32, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_UINT32, SS_UINT32, 0, 0, 0, 1.0, 0, 0.0 }
      };

      static RTWLogSignalInfo rt_LoggedStateSignalInfo = {
        14,
        rt_LoggedStateWidths,
        rt_LoggedStateNumDimensions,
        rt_LoggedStateDimensions,
        rt_LoggedStateIsVarDims,
        (NULL),
        (NULL),
        rt_LoggedStateDataTypeIds,
        rt_LoggedStateComplexSignals,
        (NULL),
        rt_LoggingStatePreprocessingFcnPtrs,

        { rt_LoggedStateLabels },
        (NULL),
        (NULL),
        (NULL),

        { rt_LoggedStateBlockNames },

        { rt_LoggedStateNames },
        rt_LoggedStateCrossMdlRef,
        rt_RTWLogDataTypeConvert
      };

      static void * rt_LoggedStateSignalPtrs[14];
      rtliSetLogXSignalPtrs(flightControlSystem_M->rtwLogInfo,
                            (LogSignalPtrsType) rt_LoggedStateSignalPtrs);
      rtliSetLogXSignalInfo(flightControlSystem_M->rtwLogInfo,
                            &rt_LoggedStateSignalInfo);
      rt_LoggedStateSignalPtrs[0] = (void*)
        flightControlSystem_DW.FlightControlSystem.Delay2_DSTATE;
      rt_LoggedStateSignalPtrs[1] = (void*)
        &flightControlSystem_DW.FlightControlSystem.Integrator_DSTATE;
      rt_LoggedStateSignalPtrs[2] = (void*)
        flightControlSystem_DW.FlightControlSystem.Integrator_DSTATE_f;
      rt_LoggedStateSignalPtrs[3] = (void*)
        flightControlSystem_DW.FlightControlSystem.Integrator_DSTATE_m;
      rt_LoggedStateSignalPtrs[4] = (void*)
        flightControlSystem_DW.FlightControlSystem.Delay_DSTATE;
      rt_LoggedStateSignalPtrs[5] = (void*)
        flightControlSystem_DW.FlightControlSystem.FIR_IMUaccel_states;
      rt_LoggedStateSignalPtrs[6] = (void*)
        &flightControlSystem_DW.FlightControlSystem.LPFFcutoff40Hz1_states;
      rt_LoggedStateSignalPtrs[7] = (void*)
        &flightControlSystem_DW.FlightControlSystem.LPFFcutoff40Hz_states;
      rt_LoggedStateSignalPtrs[8] = (void*)
        flightControlSystem_DW.FlightControlSystem.IIR_IMUgyro_r_states;
      rt_LoggedStateSignalPtrs[9] = (void*)
        flightControlSystem_DW.FlightControlSystem.MemoryX_DSTATE;
      rt_LoggedStateSignalPtrs[10] = (void*)
        flightControlSystem_DW.FlightControlSystem.MemoryX_DSTATE_e;
      rt_LoggedStateSignalPtrs[11] = (void*)
        flightControlSystem_DW.FlightControlSystem.MemoryX_DSTATE_p;
      rt_LoggedStateSignalPtrs[12] = (void*)
        &flightControlSystem_DW.FlightControlSystem.FIR_IMUaccel_circBuf;
      rt_LoggedStateSignalPtrs[13] = (void*)
        &flightControlSystem_DW.FlightControlSystem.Output_DSTATE;
    }

    rtliSetLogT(flightControlSystem_M->rtwLogInfo, "tout");
    rtliSetLogX(flightControlSystem_M->rtwLogInfo, "xout");
    rtliSetLogXFinal(flightControlSystem_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(flightControlSystem_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(flightControlSystem_M->rtwLogInfo, 2);
    rtliSetLogMaxRows(flightControlSystem_M->rtwLogInfo, 1);
    rtliSetLogDecimation(flightControlSystem_M->rtwLogInfo, 1);
    rtliSetLogY(flightControlSystem_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(flightControlSystem_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(flightControlSystem_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &flightControlSystem_B), 0,
                sizeof(B_flightControlSystem_T));

  /* exported global signals */
  motors_outport[0] = 0.0F;
  motors_outport[1] = 0.0F;
  motors_outport[2] = 0.0F;
  motors_outport[3] = 0.0F;
  flag_outport = 0U;

  /* states (dwork) */
  (void) memset((void *)&flightControlSystem_DW, 0,
                sizeof(DW_flightControlSystem_T));

  /* external inputs */
  (void)memset(&cmd_inport, 0, sizeof(CommandBus));
  (void)memset(&sensor_inport, 0, sizeof(SensorsBus));

  /* external outputs */
  (void) memset((void *)&flightControlSystem_Y, 0,
                sizeof(ExtY_flightControlSystem_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(flightControlSystem_M->rtwLogInfo, 0.0,
    rtmGetTFinal(flightControlSystem_M), flightControlSystem_M->Timing.stepSize0,
    (&rtmGetErrorStatus(flightControlSystem_M)));

  /* Start for Atomic SubSystem: '<Root>/Flight Control System' */
  flightControlSystem_FlightControlSystem_Start(flightControlSystem_M,
    &flightControlSystem_B.FlightControlSystem,
    &flightControlSystem_DW.FlightControlSystem,
    &flightControlSystem_P.FlightControlSystem);

  /* End of Start for SubSystem: '<Root>/Flight Control System' */
  flightControlSystem_PrevZCX.FlightControlSystem.TriggeredSubsystem_Trig_ZCE =
    UNINITIALIZED_ZCSIG;

  /* SystemInitialize for Atomic SubSystem: '<Root>/Flight Control System' */
  flightControlSystem_FlightControlSystem_Init
    (&flightControlSystem_B.FlightControlSystem,
     &flightControlSystem_DW.FlightControlSystem,
     &flightControlSystem_P.FlightControlSystem);

  /* End of SystemInitialize for SubSystem: '<Root>/Flight Control System' */
}

/* Model terminate function */
void flightControlSystem_terminate(void)
{
  /* Terminate for Atomic SubSystem: '<Root>/Flight Control System' */
  flightControlSystem_FlightControlSystem_Term(flightControlSystem_M,
    &flightControlSystem_DW.FlightControlSystem);

  /* End of Terminate for SubSystem: '<Root>/Flight Control System' */
}
