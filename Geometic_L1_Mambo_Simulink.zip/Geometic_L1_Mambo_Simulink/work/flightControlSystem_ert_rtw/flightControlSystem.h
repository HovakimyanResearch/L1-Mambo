/*
 * flightControlSystem.h
 *
 * Code generation for model "flightControlSystem".
 *
 * Model version              : 1.73
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Wed Feb 16 01:14:32 2022
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: ARM Compatible->ARM 9
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_flightControlSystem_h_
#define RTW_HEADER_flightControlSystem_h_
#include <math.h>
#include <string.h>
#include <float.h>
#include <stddef.h>
#ifndef flightControlSystem_COMMON_INCLUDES_
#define flightControlSystem_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#include "DAHostLib_Network.h"
#endif                                /* flightControlSystem_COMMON_INCLUDES_ */

#include "flightControlSystem_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "MW_target_hardware_resources.h"
#include "rt_nonfinite.h"
#include "rt_defines.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

/* Block signals for system '<S71>/MeasurementUpdate' */
typedef struct {
  real32_T Product3[2];                /* '<S100>/Product3' */
} B_MeasurementUpdate_flightControlSystem_T;

/* Block states (default storage) for system '<S71>/MeasurementUpdate' */
typedef struct {
  boolean_T MeasurementUpdate_MODE;    /* '<S71>/MeasurementUpdate' */
} DW_MeasurementUpdate_flightControlSystem_T;

/* Block signals for system '<S78>/Enabled Subsystem' */
typedef struct {
  real32_T Product2[2];                /* '<S102>/Product2' */
} B_EnabledSubsystem_flightControlSystem_T;

/* Block states (default storage) for system '<S78>/Enabled Subsystem' */
typedef struct {
  boolean_T EnabledSubsystem_MODE;     /* '<S78>/Enabled Subsystem' */
} DW_EnabledSubsystem_flightControlSystem_T;

/* Block signals for system '<Root>/Flight Control System' */
typedef struct {
  real32_T fv[36];
  real32_T b[36];
  real32_T b_m[36];
  real32_T Conversion_c[36];           /* '<S201>/Conversion' */
  real32_T Conversion_g[36];           /* '<S166>/Conversion' */
  real32_T c_a[24];
  real_T Rd[9];                        /* '<S8>/Rd' */
  real_T dv[9];
  real_T b_x[9];
  real32_T Conversion_b[18];           /* '<S198>/Conversion' */
  real32_T Conversion[18];             /* '<S199>/Conversion' */
  real32_T TorqueTotalThrustToThrustPerMotor[16];
                                 /* '<S10>/TorqueTotalThrustToThrustPerMotor' */
  real_T f[8];
  real_T g[8];
  real_T h[8];
  real_T i_data[7];
  real_T j_data[7];
  real_T tmp_data[7];
  real32_T d_a[12];
  real_T n_data[6];
  real_T DTC3[6];                      /* '<S6>/DTC3' */
  real_T tmp_data_c[6];
  CommandBus ControlModeUpdate;        /* '<S1>/Control Mode Update' */
  real32_T Rw[9];
  real32_T dcmm[9];
  real32_T Delay[9];                   /* '<S44>/Delay' */
  real32_T y_a[9];                     /* '<S44>/MATLAB Function' */
  real32_T R[9];                       /* '<S2>/MATLAB Function2' */
  real32_T fv1[9];
  real32_T rtb_Delay_k[9];
  real_T UDPReceive1_o1[4];            /* '<S4>/UDP Receive1' */
  real_T rtb_TorqueTotalThrustToThrustPe[4];
  real_T xd[3];                        /* '<S3>/MATLAB Function' */
  real_T xd_1dot[3];                   /* '<S3>/MATLAB Function' */
  real_T xd_2dot[3];                   /* '<S3>/MATLAB Function' */
  real_T a[3];
  real_T a_c[3];
  real_T Saturation_d[3];              /* '<S32>/Saturation' */
  real_T Saturation_i[3];              /* '<S38>/Saturation' */
  real32_T Add[6];                     /* '<S182>/Add' */
  real32_T sigma[6];                   /* '<S6>/L1 Adaptation Law' */
  real32_T fv2[6];
  real32_T c[6];
  real32_T c_a_b[6];
  real32_T fv3[6];
  real32_T Conversion_e[6];            /* '<S171>/Conversion' */
  real32_T DataTypeConversion[4];      /* '<S4>/Data Type Conversion' */
  real32_T Conversion_lj[4];           /* '<S114>/Conversion' */
  real32_T Conversion_d[4];            /* '<S149>/Conversion' */
  real32_T Conversion_l[4];            /* '<S62>/Conversion' */
  real32_T Conversion_i[4];            /* '<S97>/Conversion' */
  real32_T DTC4[4];                    /* '<S5>/DTC4' */
  real_T Probe[2];                     /* '<S21>/Probe' */
  real32_T ct[3];
  real32_T st[3];
  real32_T Reshapey[3];                /* '<S42>/Reshapey' */
  real32_T DTC1_g[3];                  /* '<S3>/DTC1' */
  real32_T DataTypeConversion1_g[3];   /* '<S41>/Data Type Conversion1' */
  int32_T tmp_size[3];
  int32_T tmp_size_p[3];
  int32_T tmp_size_c[3];
  int32_T tmp_size_f[3];
  int32_T sy_size[3];
  real_T Constant;                     /* '<S25>/Constant' */
  real_T Probe_h[2];                   /* '<S27>/Probe' */
  real_T Constant_k;                   /* '<S31>/Constant' */
  real_T DTC1[6];                      /* '<S17>/DTC1' */
  real_T Probe_j[2];                   /* '<S33>/Probe' */
  real_T Constant_c;                   /* '<S37>/Constant' */
  real_T uT[3];                        /* '<S20>/1//T' */
  real_T uT_i[3];                      /* '<S19>/1//T' */
  real_T uT_p;                         /* '<S18>/1//T' */
  real_T scale;
  real_T t;
  real_T DigitalClock;                 /* '<S3>/Digital Clock' */
  real_T x_tmp;
  real_T rtb_xd_2dot_p;
  real_T rtb_b1d_idx_2;
  real_T rtb_Add_idx_0;
  real_T rtb_Add_idx_0_l;
  real_T rtb_Add_idx_1;
  real_T rtb_Add_idx_1_j;
  real_T rtb_Add_idx_2;
  real_T rtb_Add_idx_2_d;
  real_T a_tmp;
  real_T Saturation;                   /* '<S26>/Saturation' */
  real_T absx11;
  real_T absx21;
  real_T absx31;
  real32_T Conversion_h2[2];           /* '<S94>/Conversion' */
  real32_T MemoryX_h[2];               /* '<S51>/MemoryX' */
  real32_T Conversion_h[2];            /* '<S67>/Conversion' */
  real32_T Conversion_pu[2];           /* '<S146>/Conversion' */
  real32_T MemoryX_j[2];               /* '<S103>/MemoryX' */
  real32_T Conversion_m[2];            /* '<S119>/Conversion' */
  real32_T Conversion_pl[2];           /* '<S95>/Conversion' */
  real32_T Conversion_p[2];            /* '<S147>/Conversion' */
  int32_T i_size[2];
  int32_T j_size[2];
  int32_T tmp_size_m[2];
  int32_T tmp_size_n[2];
  real32_T Gain1;                      /* '<S4>/Gain1' */
  real32_T Gain;                       /* '<S4>/Gain' */
  real32_T inverseIMU_gain[6];         /* '<S45>/inverseIMU_gain' */
  real32_T FIR_IMUaccel[3];            /* '<S45>/FIR_IMUaccel' */
  real32_T p;                          /* '<S45>/LPF Fcutoff = 40Hz1' */
  real32_T q;                          /* '<S45>/LPF Fcutoff = 40Hz' */
  real32_T DataTypeConversion1[9];     /* '<S44>/Data Type Conversion1' */
  real32_T TrigonometricFunction;      /* '<S49>/Trigonometric Function' */
  real32_T TrigonometricFunction1;     /* '<S48>/Trigonometric Function1' */
  real32_T Reshape[6];                 /* '<S175>/Reshape' */
  real32_T Reshape_n[2];               /* '<S123>/Reshape' */
  real32_T Reshape_a[2];               /* '<S71>/Reshape' */
  real32_T In1;                        /* '<S216>/In1' */
  real32_T acc[3];                     /* '<S4>/MATLAB Function' */
  real32_T Product2[6];                /* '<S206>/Product2' */
  real32_T Product3[6];                /* '<S204>/Product3' */
  real32_T sy;
  real32_T y;
  real32_T DataTypeConversion_p;       /* '<S49>/Data Type Conversion' */
  real32_T Gain1_g;                    /* '<S5>/Gain1' */
  real32_T r;                          /* '<S212>/Subtract1' */
  real32_T rtb_Add_l;
  real32_T rtb_Add_d;
  real32_T rtb_Add_dy;
  real32_T rtb_Add_lx;
  real32_T tmp_data_o;
  real32_T tmp_data_b;
  real32_T tmp_data_n;
  real32_T tmp_data_bs;
  real32_T rtb_y_idx_0;
  real32_T rtb_y_idx_1;
  real32_T unnamed_idx_0;
  real32_T unnamed_idx_1;
  real32_T unnamed_idx_2;
  real32_T f_l;
  real32_T f1;
  real32_T st_tmp;
  real32_T st_tmp_h;
  real32_T st_tmp_b;
  real32_T f2;
  real32_T f3;
  real32_T f4;
  real32_T st_tmp_d;
  real32_T Reshapeu_l;                 /* '<S51>/Reshapeu' */
  real32_T Reshapeu_e;                 /* '<S103>/Reshapeu' */
  real32_T Reshapey_d;                 /* '<S51>/Reshapey' */
  real32_T Reshapey_k;                 /* '<S103>/Reshapey' */
  real32_T Sum2_b;                     /* '<S45>/Sum2' */
  int32_T samplesRead;
  int32_T j;
  int32_T i;
  int32_T Rw_tmp;
  int32_T rtb_Delay_tmp;
  int32_T b_tmp;
  uint32_T FixPtSwitch;                /* '<S218>/FixPt Switch' */
  uint32_T FixPtSum1;                  /* '<S217>/FixPt Sum1' */
  uint16_T UDPReceive1_o2;             /* '<S4>/UDP Receive1' */
  int16_T LogicalOperator;             /* '<S41>/Logical Operator' */
  boolean_T Compare;                   /* '<S24>/Compare' */
  boolean_T Compare_a;                 /* '<S30>/Compare' */
  boolean_T Compare_e;                 /* '<S36>/Compare' */
  B_EnabledSubsystem_flightControlSystem_T EnabledSubsystem_m;/* '<S130>/Enabled Subsystem' */
  B_MeasurementUpdate_flightControlSystem_T MeasurementUpdate_o;/* '<S123>/MeasurementUpdate' */
  B_EnabledSubsystem_flightControlSystem_T EnabledSubsystem;/* '<S78>/Enabled Subsystem' */
  B_MeasurementUpdate_flightControlSystem_T MeasurementUpdate;/* '<S71>/MeasurementUpdate' */
} B_FlightControlSystem_flightControlSystem_T;

/* Block states (default storage) for system '<Root>/Flight Control System' */
typedef struct {
  real_T Delay2_DSTATE[6];             /* '<S17>/Delay2' */
  real_T Integrator_DSTATE;            /* '<S26>/Integrator' */
  real_T Integrator_DSTATE_f[3];       /* '<S32>/Integrator' */
  real_T Integrator_DSTATE_m[3];       /* '<S38>/Integrator' */
  real_T UDPReceive1_NetworkLib[137];  /* '<S4>/UDP Receive1' */
  real32_T Delay_DSTATE[9];            /* '<S44>/Delay' */
  real32_T FIR_IMUaccel_states[15];    /* '<S45>/FIR_IMUaccel' */
  real32_T LPFFcutoff40Hz1_states;     /* '<S45>/LPF Fcutoff = 40Hz1' */
  real32_T LPFFcutoff40Hz_states;      /* '<S45>/LPF Fcutoff = 40Hz' */
  real32_T IIR_IMUgyro_r_states[5];    /* '<S45>/IIR_IMUgyro_r' */
  real32_T MemoryX_DSTATE[6];          /* '<S42>/MemoryX' */
  real32_T MemoryX_DSTATE_e[2];        /* '<S103>/MemoryX' */
  real32_T MemoryX_DSTATE_p[2];        /* '<S51>/MemoryX' */
  int32_T FIR_IMUaccel_circBuf;        /* '<S45>/FIR_IMUaccel' */
  uint32_T Output_DSTATE;              /* '<S215>/Output' */
  real32_T LPFFcutoff40Hz1_tmp;        /* '<S45>/LPF Fcutoff = 40Hz1' */
  real32_T LPFFcutoff40Hz_tmp;         /* '<S45>/LPF Fcutoff = 40Hz' */
  real32_T IIR_IMUgyro_r_tmp;          /* '<S45>/IIR_IMUgyro_r' */
  int8_T Integrator_PrevResetState;    /* '<S26>/Integrator' */
  int8_T Integrator_PrevResetState_o;  /* '<S32>/Integrator' */
  int8_T Integrator_PrevResetState_l;  /* '<S38>/Integrator' */
  uint8_T icLoad;                      /* '<S42>/MemoryX' */
  uint8_T icLoad_p;                    /* '<S103>/MemoryX' */
  uint8_T icLoad_i;                    /* '<S51>/MemoryX' */
  boolean_T EnabledSubsystem_MODE;     /* '<S182>/Enabled Subsystem' */
  boolean_T MeasurementUpdate_MODE;    /* '<S175>/MeasurementUpdate' */
  DW_EnabledSubsystem_flightControlSystem_T EnabledSubsystem_m;/* '<S130>/Enabled Subsystem' */
  DW_MeasurementUpdate_flightControlSystem_T MeasurementUpdate_o;/* '<S123>/MeasurementUpdate' */
  DW_EnabledSubsystem_flightControlSystem_T EnabledSubsystem;/* '<S78>/Enabled Subsystem' */
  DW_MeasurementUpdate_flightControlSystem_T MeasurementUpdate;/* '<S71>/MeasurementUpdate' */
} DW_FlightControlSystem_flightControlSystem_T;

/* Zero-crossing (trigger) state for system '<Root>/Flight Control System' */
typedef struct {
  ZCSigState TriggeredSubsystem_Trig_ZCE;/* '<S212>/Triggered Subsystem' */
} ZCE_FlightControlSystem_flightControlSystem_T;

/* Block signals (default storage) */
typedef struct {
  B_FlightControlSystem_flightControlSystem_T FlightControlSystem;/* '<Root>/Flight Control System' */
} B_flightControlSystem_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  DW_FlightControlSystem_flightControlSystem_T FlightControlSystem;/* '<Root>/Flight Control System' */
} DW_flightControlSystem_T;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCE_FlightControlSystem_flightControlSystem_T FlightControlSystem;/* '<Root>/Flight Control System' */
} PrevZCX_flightControlSystem_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real32_T Actuators[4];               /* '<Root>/Actuators' */
  uint8_T Flag;                        /* '<Root>/Flag' */
} ExtY_flightControlSystem_T;

/* Parameters for system: '<S71>/MeasurementUpdate' */
struct P_MeasurementUpdate_flightControlSystem_T_ {
  real32_T Lykyhatkk1_Y0;              /* Computed Parameter: Lykyhatkk1_Y0
                                        * Referenced by: '<S100>/L*(y[k]-yhat[k|k-1])'
                                        */
};

/* Parameters for system: '<S78>/Enabled Subsystem' */
struct P_EnabledSubsystem_flightControlSystem_T_ {
  real32_T deltax_Y0;                  /* Computed Parameter: deltax_Y0
                                        * Referenced by: '<S102>/deltax'
                                        */
};

/* Parameters for system: '<Root>/Flight Control System' */
struct P_FlightControlSystem_flightControlSystem_T_ {
  real_T LowPassFilterDiscreteorContinuous3_K;
                         /* Mask Parameter: LowPassFilterDiscreteorContinuous3_K
                          * Referenced by: '<S20>/K'
                          */
  real_T LowPassFilterDiscreteorContinuous2_K;
                         /* Mask Parameter: LowPassFilterDiscreteorContinuous2_K
                          * Referenced by: '<S19>/K'
                          */
  real_T LowPassFilterDiscreteorContinuous1_K;
                         /* Mask Parameter: LowPassFilterDiscreteorContinuous1_K
                          * Referenced by: '<S18>/K'
                          */
  real_T LowPassFilterDiscreteorContinuous1_T;
                         /* Mask Parameter: LowPassFilterDiscreteorContinuous1_T
                          * Referenced by: '<S21>/Time constant'
                          */
  real_T LowPassFilterDiscreteorContinuous2_T;
                         /* Mask Parameter: LowPassFilterDiscreteorContinuous2_T
                          * Referenced by: '<S27>/Time constant'
                          */
  real_T LowPassFilterDiscreteorContinuous3_T;
                         /* Mask Parameter: LowPassFilterDiscreteorContinuous3_T
                          * Referenced by: '<S33>/Time constant'
                          */
  real_T LowPassFilterDiscreteorContinuous1_x0;
                        /* Mask Parameter: LowPassFilterDiscreteorContinuous1_x0
                         * Referenced by: '<S25>/Constant'
                         */
  real_T LowPassFilterDiscreteorContinuous2_x0;
                        /* Mask Parameter: LowPassFilterDiscreteorContinuous2_x0
                         * Referenced by: '<S31>/Constant'
                         */
  real_T LowPassFilterDiscreteorContinuous3_x0;
                        /* Mask Parameter: LowPassFilterDiscreteorContinuous3_x0
                         * Referenced by: '<S37>/Constant'
                         */
  real32_T CompareToConstant_const;   /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S46>/Constant'
                                       */
  real32_T CompareToConstant1_const; /* Mask Parameter: CompareToConstant1_const
                                      * Referenced by: '<S47>/Constant'
                                      */
  uint32_T WrapToZero_Threshold;       /* Mask Parameter: WrapToZero_Threshold
                                        * Referenced by: '<S218>/FixPt Switch'
                                        */
  uint32_T CompareToConstant_const_p;
                                    /* Mask Parameter: CompareToConstant_const_p
                                     * Referenced by: '<S214>/Constant'
                                     */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S212>/Constant'
                                        */
  real_T KalmanGainM_Value[18];        /* Expression: pInitialization.M
                                        * Referenced by: '<S155>/KalmanGainM'
                                        */
  real_T KalmanGainL_Value[18];        /* Expression: pInitialization.L
                                        * Referenced by: '<S155>/KalmanGainL'
                                        */
  real_T Constant_Value_e;             /* Expression: 2
                                        * Referenced by: '<S3>/Constant'
                                        */
  real_T KalmanGainM_Value_p[2];       /* Expression: pInitialization.M
                                        * Referenced by: '<S104>/KalmanGainM'
                                        */
  real_T KalmanGainM_Value_j[2];       /* Expression: pInitialization.M
                                        * Referenced by: '<S52>/KalmanGainM'
                                        */
  real_T Delay2_InitialCondition;      /* Expression: 0.0
                                        * Referenced by: '<S17>/Delay2'
                                        */
  real_T Constant_Value_c;             /* Expression: 0
                                        * Referenced by: '<S24>/Constant'
                                        */
  real_T Integrator_gainval;           /* Computed Parameter: Integrator_gainval
                                        * Referenced by: '<S26>/Integrator'
                                        */
  real_T Integrator_UpperSat;          /* Expression: antiwindupUpperLimit
                                        * Referenced by: '<S26>/Integrator'
                                        */
  real_T Integrator_LowerSat;          /* Expression: antiwindupLowerLimit
                                        * Referenced by: '<S26>/Integrator'
                                        */
  real_T Saturation_UpperSat;          /* Expression: windupUpperLimit
                                        * Referenced by: '<S26>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: windupLowerLimit
                                        * Referenced by: '<S26>/Saturation'
                                        */
  real_T Constant_Value_k;             /* Expression: 0
                                        * Referenced by: '<S30>/Constant'
                                        */
  real_T Integrator_gainval_d;       /* Computed Parameter: Integrator_gainval_d
                                      * Referenced by: '<S32>/Integrator'
                                      */
  real_T Integrator_UpperSat_o;        /* Expression: antiwindupUpperLimit
                                        * Referenced by: '<S32>/Integrator'
                                        */
  real_T Integrator_LowerSat_p;        /* Expression: antiwindupLowerLimit
                                        * Referenced by: '<S32>/Integrator'
                                        */
  real_T Saturation_UpperSat_d;        /* Expression: windupUpperLimit
                                        * Referenced by: '<S32>/Saturation'
                                        */
  real_T Saturation_LowerSat_f;        /* Expression: windupLowerLimit
                                        * Referenced by: '<S32>/Saturation'
                                        */
  real_T Constant_Value_g;             /* Expression: 0
                                        * Referenced by: '<S15>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S15>/Constant1'
                                        */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<S15>/Switch'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0
                                        * Referenced by: '<S15>/Switch1'
                                        */
  real_T Constant_Value_m;             /* Expression: 0
                                        * Referenced by: '<S36>/Constant'
                                        */
  real_T Integrator_gainval_a;       /* Computed Parameter: Integrator_gainval_a
                                      * Referenced by: '<S38>/Integrator'
                                      */
  real_T Integrator_UpperSat_l;        /* Expression: antiwindupUpperLimit
                                        * Referenced by: '<S38>/Integrator'
                                        */
  real_T Integrator_LowerSat_c;        /* Expression: antiwindupLowerLimit
                                        * Referenced by: '<S38>/Integrator'
                                        */
  real_T Saturation_UpperSat_j;        /* Expression: windupUpperLimit
                                        * Referenced by: '<S38>/Saturation'
                                        */
  real_T Saturation_LowerSat_m;        /* Expression: windupLowerLimit
                                        * Referenced by: '<S38>/Saturation'
                                        */
  real_T KalmanGainL_Value_b[2];       /* Expression: pInitialization.L
                                        * Referenced by: '<S104>/KalmanGainL'
                                        */
  real_T KalmanGainL_Value_h[2];       /* Expression: pInitialization.L
                                        * Referenced by: '<S52>/KalmanGainL'
                                        */
  real_T CovarianceZ_Value[36];        /* Expression: pInitialization.Z
                                        * Referenced by: '<S155>/CovarianceZ'
                                        */
  real_T CovarianceZ_Value_j[4];       /* Expression: pInitialization.Z
                                        * Referenced by: '<S52>/CovarianceZ'
                                        */
  real_T CovarianceZ_Value_d[4];       /* Expression: pInitialization.Z
                                        * Referenced by: '<S104>/CovarianceZ'
                                        */
  real_T Constant_Value_a;             /* Expression: 0
                                        * Referenced by: '<S1>/Constant'
                                        */
  int32_T UDPReceive1_Port;            /* Computed Parameter: UDPReceive1_Port
                                        * Referenced by: '<S4>/UDP Receive1'
                                        */
  real32_T Lykyhatkk1_Y0;              /* Computed Parameter: Lykyhatkk1_Y0
                                        * Referenced by: '<S204>/L*(y[k]-yhat[k|k-1])'
                                        */
  real32_T deltax_Y0;                  /* Computed Parameter: deltax_Y0
                                        * Referenced by: '<S206>/deltax'
                                        */
  real32_T Gain_Gain;                  /* Computed Parameter: Gain_Gain
                                        * Referenced by: '<S212>/Gain'
                                        */
  real32_T Out1_Y0;                    /* Computed Parameter: Out1_Y0
                                        * Referenced by: '<S216>/Out1'
                                        */
  real32_T A_Value[36];                /* Computed Parameter: A_Value
                                        * Referenced by: '<S42>/A'
                                        */
  real32_T C_Value[18];                /* Computed Parameter: C_Value
                                        * Referenced by: '<S42>/C'
                                        */
  real32_T B_Value[18];                /* Computed Parameter: B_Value
                                        * Referenced by: '<S42>/B'
                                        */
  real32_T TorqueTotalThrustToThrustPerMotor_Value[16];/* Expression: Controller.Q2Ts
                                                        * Referenced by: '<S10>/TorqueTotalThrustToThrustPerMotor'
                                                        */
  real32_T Delay_InitialCondition[9];
                                   /* Computed Parameter: Delay_InitialCondition
                                    * Referenced by: '<S44>/Delay'
                                    */
  real32_T Gain1_Gain;                 /* Computed Parameter: Gain1_Gain
                                        * Referenced by: '<S4>/Gain1'
                                        */
  real32_T Gain_Gain_m;                /* Computed Parameter: Gain_Gain_m
                                        * Referenced by: '<S4>/Gain'
                                        */
  real32_T Assumingthatthepreflightcalibrationwasdoneatlevelorientation_Bi[6];
  /* Computed Parameter: Assumingthatthepreflightcalibrationwasdoneatlevelorientation_Bi
   * Referenced by: '<S45>/Assuming that the  preflight calibration was done at level orientation'
   */
  real32_T inverseIMU_gain_Gain[6];  /* Computed Parameter: inverseIMU_gain_Gain
                                      * Referenced by: '<S45>/inverseIMU_gain'
                                      */
  real32_T FIR_IMUaccel_InitialStates;
                               /* Computed Parameter: FIR_IMUaccel_InitialStates
                                * Referenced by: '<S45>/FIR_IMUaccel'
                                */
  real32_T FIR_IMUaccel_Coefficients[6];
                                /* Computed Parameter: FIR_IMUaccel_Coefficients
                                 * Referenced by: '<S45>/FIR_IMUaccel'
                                 */
  real32_T Gain3_Gain;                 /* Computed Parameter: Gain3_Gain
                                        * Referenced by: '<S44>/Gain3'
                                        */
  real32_T LPFFcutoff40Hz1_NumCoef[2];
                                  /* Computed Parameter: LPFFcutoff40Hz1_NumCoef
                                   * Referenced by: '<S45>/LPF Fcutoff = 40Hz1'
                                   */
  real32_T LPFFcutoff40Hz1_DenCoef[2];
                                  /* Computed Parameter: LPFFcutoff40Hz1_DenCoef
                                   * Referenced by: '<S45>/LPF Fcutoff = 40Hz1'
                                   */
  real32_T LPFFcutoff40Hz1_InitialStates;
                            /* Computed Parameter: LPFFcutoff40Hz1_InitialStates
                             * Referenced by: '<S45>/LPF Fcutoff = 40Hz1'
                             */
  real32_T LPFFcutoff40Hz_NumCoef[2];
                                   /* Computed Parameter: LPFFcutoff40Hz_NumCoef
                                    * Referenced by: '<S45>/LPF Fcutoff = 40Hz'
                                    */
  real32_T LPFFcutoff40Hz_DenCoef[2];
                                   /* Computed Parameter: LPFFcutoff40Hz_DenCoef
                                    * Referenced by: '<S45>/LPF Fcutoff = 40Hz'
                                    */
  real32_T LPFFcutoff40Hz_InitialStates;
                             /* Computed Parameter: LPFFcutoff40Hz_InitialStates
                              * Referenced by: '<S45>/LPF Fcutoff = 40Hz'
                              */
  real32_T IIR_IMUgyro_r_NumCoef[6];/* Computed Parameter: IIR_IMUgyro_r_NumCoef
                                     * Referenced by: '<S45>/IIR_IMUgyro_r'
                                     */
  real32_T IIR_IMUgyro_r_DenCoef[6];/* Computed Parameter: IIR_IMUgyro_r_DenCoef
                                     * Referenced by: '<S45>/IIR_IMUgyro_r'
                                     */
  real32_T IIR_IMUgyro_r_InitialStates;
                              /* Computed Parameter: IIR_IMUgyro_r_InitialStates
                               * Referenced by: '<S45>/IIR_IMUgyro_r'
                               */
  real32_T D_Value[9];                 /* Computed Parameter: D_Value
                                        * Referenced by: '<S42>/D'
                                        */
  real32_T X0_Value[6];                /* Computed Parameter: X0_Value
                                        * Referenced by: '<S42>/X0'
                                        */
  real32_T X0_Value_f[2];              /* Computed Parameter: X0_Value_f
                                        * Referenced by: '<S103>/X0'
                                        */
  real32_T Constant_Value_l;           /* Computed Parameter: Constant_Value_l
                                        * Referenced by: '<S50>/Constant'
                                        */
  real32_T C_Value_g[2];               /* Computed Parameter: C_Value_g
                                        * Referenced by: '<S103>/C'
                                        */
  real32_T X0_Value_j[2];              /* Computed Parameter: X0_Value_j
                                        * Referenced by: '<S51>/X0'
                                        */
  real32_T Gain2_Gain;                 /* Computed Parameter: Gain2_Gain
                                        * Referenced by: '<S48>/Gain2'
                                        */
  real32_T C_Value_c[2];               /* Computed Parameter: C_Value_c
                                        * Referenced by: '<S51>/C'
                                        */
  real32_T Constant_Value_h;           /* Computed Parameter: Constant_Value_h
                                        * Referenced by: '<S41>/Constant'
                                        */
  real32_T Gain1_Gain_i;               /* Computed Parameter: Gain1_Gain_i
                                        * Referenced by: '<S5>/Gain1'
                                        */
  real32_T Saturation5_UpperSat;     /* Computed Parameter: Saturation5_UpperSat
                                      * Referenced by: '<S13>/Saturation5'
                                      */
  real32_T Saturation5_LowerSat;       /* Expression: Vehicle.Motor.minLimit
                                        * Referenced by: '<S13>/Saturation5'
                                        */
  real32_T MotorDirections_Gain[4];  /* Computed Parameter: MotorDirections_Gain
                                      * Referenced by: '<S13>/MotorDirections'
                                      */
  real32_T A_Value_n[4];               /* Computed Parameter: A_Value_n
                                        * Referenced by: '<S51>/A'
                                        */
  real32_T A_Value_n4[4];              /* Computed Parameter: A_Value_n4
                                        * Referenced by: '<S103>/A'
                                        */
  real32_T B_Value_p[2];               /* Computed Parameter: B_Value_p
                                        * Referenced by: '<S103>/B'
                                        */
  real32_T D_Value_n;                  /* Computed Parameter: D_Value_n
                                        * Referenced by: '<S103>/D'
                                        */
  real32_T B_Value_o[2];               /* Computed Parameter: B_Value_o
                                        * Referenced by: '<S51>/B'
                                        */
  real32_T D_Value_c;                  /* Computed Parameter: D_Value_c
                                        * Referenced by: '<S51>/D'
                                        */
  real32_T P0_Value[36];               /* Computed Parameter: P0_Value
                                        * Referenced by: '<S42>/P0'
                                        */
  real32_T G_Value[36];                /* Computed Parameter: G_Value
                                        * Referenced by: '<S42>/G'
                                        */
  real32_T Q_Value[36];                /* Computed Parameter: Q_Value
                                        * Referenced by: '<S42>/Q'
                                        */
  real32_T H_Value[18];                /* Computed Parameter: H_Value
                                        * Referenced by: '<S42>/H'
                                        */
  real32_T N_Value[18];                /* Computed Parameter: N_Value
                                        * Referenced by: '<S42>/N'
                                        */
  real32_T R_Value[9];                 /* Computed Parameter: R_Value
                                        * Referenced by: '<S42>/R'
                                        */
  real32_T P0_Value_e[4];              /* Computed Parameter: P0_Value_e
                                        * Referenced by: '<S51>/P0'
                                        */
  real32_T G_Value_n[4];               /* Computed Parameter: G_Value_n
                                        * Referenced by: '<S51>/G'
                                        */
  real32_T Q_Value_c[4];               /* Computed Parameter: Q_Value_c
                                        * Referenced by: '<S51>/Q'
                                        */
  real32_T P0_Value_c[4];              /* Computed Parameter: P0_Value_c
                                        * Referenced by: '<S103>/P0'
                                        */
  real32_T G_Value_nz[4];              /* Computed Parameter: G_Value_nz
                                        * Referenced by: '<S103>/G'
                                        */
  real32_T Q_Value_l[4];               /* Computed Parameter: Q_Value_l
                                        * Referenced by: '<S103>/Q'
                                        */
  real32_T H_Value_e[2];               /* Computed Parameter: H_Value_e
                                        * Referenced by: '<S51>/H'
                                        */
  real32_T N_Value_d[2];               /* Computed Parameter: N_Value_d
                                        * Referenced by: '<S51>/N'
                                        */
  real32_T H_Value_j[2];               /* Computed Parameter: H_Value_j
                                        * Referenced by: '<S103>/H'
                                        */
  real32_T N_Value_f[2];               /* Computed Parameter: N_Value_f
                                        * Referenced by: '<S103>/N'
                                        */
  real32_T R_Value_j;                  /* Computed Parameter: R_Value_j
                                        * Referenced by: '<S51>/R'
                                        */
  real32_T R_Value_o;                  /* Computed Parameter: R_Value_o
                                        * Referenced by: '<S103>/R'
                                        */
  uint32_T Output_InitialCondition;
                                  /* Computed Parameter: Output_InitialCondition
                                   * Referenced by: '<S215>/Output'
                                   */
  uint32_T FixPtConstant_Value;       /* Computed Parameter: FixPtConstant_Value
                                       * Referenced by: '<S217>/FixPt Constant'
                                       */
  uint32_T Constant_Value_n;           /* Computed Parameter: Constant_Value_n
                                        * Referenced by: '<S218>/Constant'
                                        */
  boolean_T Enable_Value;              /* Expression: true()
                                        * Referenced by: '<S42>/Enable'
                                        */
  boolean_T controlModePosVsOrient_Value;
                             /* Computed Parameter: controlModePosVsOrient_Value
                              * Referenced by: '<S1>/controlModePosVsOrient'
                              */
  uint8_T Disabletemperaturecompensation_CurrentSetting;
            /* Computed Parameter: Disabletemperaturecompensation_CurrentSetting
             * Referenced by: '<S212>/Disable temperature compensation'
             */
  P_EnabledSubsystem_flightControlSystem_T EnabledSubsystem_m;/* '<S130>/Enabled Subsystem' */
  P_MeasurementUpdate_flightControlSystem_T MeasurementUpdate_o;/* '<S123>/MeasurementUpdate' */
  P_EnabledSubsystem_flightControlSystem_T EnabledSubsystem;/* '<S78>/Enabled Subsystem' */
  P_MeasurementUpdate_flightControlSystem_T MeasurementUpdate;/* '<S71>/MeasurementUpdate' */
};

/* Parameters (default storage) */
struct P_flightControlSystem_T_ {
  struct_OSJpyIZcrpXqReVWwh9iuG Vehicle;/* Variable: Vehicle
                                         * Referenced by: '<S13>/ThrustToMotorCommand'
                                         */
  real_T As[36];                       /* Variable: As
                                        * Referenced by: '<S17>/L1 State Predictor'
                                        */
  real_T J[9];                         /* Variable: J
                                        * Referenced by:
                                        *   '<S5>/Moment controller'
                                        *   '<S6>/L1 Adaptation Law'
                                        *   '<S17>/L1 State Predictor'
                                        */
  real_T Ts;                           /* Variable: Ts
                                        * Referenced by: '<S17>/L1 State Predictor'
                                        */
  real_T adaptationgain[36];           /* Variable: adaptationgain
                                        * Referenced by: '<S6>/L1 Adaptation Law'
                                        */
  real_T gravity;                      /* Variable: gravity
                                        * Referenced by: '<S8>/Force controller  (MATLAB Function)'
                                        */
  real_T kOmega[9];                    /* Variable: kOmega
                                        * Referenced by: '<S5>/Moment controller'
                                        */
  real_T kR[9];                        /* Variable: kR
                                        * Referenced by: '<S5>/Moment controller'
                                        */
  real_T kv[9];                        /* Variable: kv
                                        * Referenced by: '<S8>/Force controller  (MATLAB Function)'
                                        */
  real_T kx[9];                        /* Variable: kx
                                        * Referenced by: '<S8>/Force controller  (MATLAB Function)'
                                        */
  real_T m;                            /* Variable: m
                                        * Referenced by: '<S6>/L1 Adaptation Law'
                                        */
  real_T mass;                         /* Variable: mass
                                        * Referenced by:
                                        *   '<S8>/Force controller  (MATLAB Function)'
                                        *   '<S17>/L1 State Predictor'
                                        */
  real_T polytraj[198];                /* Variable: polytraj
                                        * Referenced by: '<S3>/MATLAB Function'
                                        */
  P_FlightControlSystem_flightControlSystem_T FlightControlSystem;/* '<Root>/Flight Control System' */
};

/* Real-time Model Data Structure */
struct tag_RTM_flightControlSystem_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_flightControlSystem_T flightControlSystem_P;

/* Block signals (default storage) */
extern B_flightControlSystem_T flightControlSystem_B;

/* Block states (default storage) */
extern DW_flightControlSystem_T flightControlSystem_DW;

/* Zero-crossing (trigger) state */
extern PrevZCX_flightControlSystem_T flightControlSystem_PrevZCX;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_flightControlSystem_T flightControlSystem_Y;

/*
 * Exported Global Signals
 *
 * Note: Exported global signals are block signals with an exported global
 * storage class designation.  Code generation will declare the memory for
 * these signals and export their symbols.
 *
 */
extern CommandBus cmd_inport;          /* '<Root>/AC cmd' */
extern SensorsBus sensor_inport;       /* '<Root>/Sensors' */
extern real32_T motors_outport[4];     /* '<S13>/MotorDirections' */
extern uint8_T flag_outport;           /* '<S1>/Data Type Conversion' */

/* Model entry point functions */
extern void flightControlSystem_initialize(void);
extern void flightControlSystem_step(void);
extern void flightControlSystem_terminate(void);

/* Real-time Model object */
extern RT_MODEL_flightControlSystem_T *const flightControlSystem_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'flightControlSystem'
 * '<S1>'   : 'flightControlSystem/Flight Control System'
 * '<S2>'   : 'flightControlSystem/Flight Control System/Controller'
 * '<S3>'   : 'flightControlSystem/Flight Control System/Desired Trajectory'
 * '<S4>'   : 'flightControlSystem/Flight Control System/State Estimator'
 * '<S5>'   : 'flightControlSystem/Flight Control System/Controller/Geometric controller(Baseline controller)'
 * '<S6>'   : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller'
 * '<S7>'   : 'flightControlSystem/Flight Control System/Controller/MATLAB Function2'
 * '<S8>'   : 'flightControlSystem/Flight Control System/Controller/Geometric controller(Baseline controller)/Force controller'
 * '<S9>'   : 'flightControlSystem/Flight Control System/Controller/Geometric controller(Baseline controller)/Moment controller'
 * '<S10>'  : 'flightControlSystem/Flight Control System/Controller/Geometric controller(Baseline controller)/TorqueTotalThrustToThrustPerMotor'
 * '<S11>'  : 'flightControlSystem/Flight Control System/Controller/Geometric controller(Baseline controller)/Force controller/Force controller  (MATLAB Function)'
 * '<S12>'  : 'flightControlSystem/Flight Control System/Controller/Geometric controller(Baseline controller)/Force controller/Rd'
 * '<S13>'  : 'flightControlSystem/Flight Control System/Controller/Geometric controller(Baseline controller)/TorqueTotalThrustToThrustPerMotor/thrustsToMotorCommands'
 * '<S14>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/L1 Adaptation Law'
 * '<S15>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/L1 On//Off Switch'
 * '<S16>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters'
 * '<S17>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/StatePredictor'
 * '<S18>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)1'
 * '<S19>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)2'
 * '<S20>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)3'
 * '<S21>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)1/Enable//disable time constant'
 * '<S22>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)1/Initialization'
 * '<S23>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)1/Integrator (Discrete or Continuous)'
 * '<S24>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)1/Enable//disable time constant/Compare To Zero'
 * '<S25>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)1/Initialization/Init_param'
 * '<S26>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)1/Integrator (Discrete or Continuous)/Discrete'
 * '<S27>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)2/Enable//disable time constant'
 * '<S28>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)2/Initialization'
 * '<S29>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)2/Integrator (Discrete or Continuous)'
 * '<S30>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)2/Enable//disable time constant/Compare To Zero'
 * '<S31>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)2/Initialization/Init_param'
 * '<S32>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)2/Integrator (Discrete or Continuous)/Discrete'
 * '<S33>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)3/Enable//disable time constant'
 * '<S34>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)3/Initialization'
 * '<S35>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)3/Integrator (Discrete or Continuous)'
 * '<S36>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)3/Enable//disable time constant/Compare To Zero'
 * '<S37>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)3/Initialization/Init_param'
 * '<S38>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/Low-Pass Filters/Low-Pass Filter (Discrete or Continuous)3/Integrator (Discrete or Continuous)/Discrete'
 * '<S39>'  : 'flightControlSystem/Flight Control System/Controller/L1 adaptive controller/StatePredictor/L1 State Predictor'
 * '<S40>'  : 'flightControlSystem/Flight Control System/Desired Trajectory/MATLAB Function'
 * '<S41>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator'
 * '<S42>'  : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1'
 * '<S43>'  : 'flightControlSystem/Flight Control System/State Estimator/MATLAB Function'
 * '<S44>'  : 'flightControlSystem/Flight Control System/State Estimator/Mahony Filter'
 * '<S45>'  : 'flightControlSystem/Flight Control System/State Estimator/SensorPreprocessing'
 * '<S46>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Compare To Constant'
 * '<S47>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Compare To Constant1'
 * '<S48>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman'
 * '<S49>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman'
 * '<S50>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/norm(accelerometer)'
 * '<S51>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter'
 * '<S52>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/CalculatePL'
 * '<S53>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/CalculateYhat'
 * '<S54>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/CovarianceOutputConfigurator'
 * '<S55>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/DataTypeConversionA'
 * '<S56>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/DataTypeConversionB'
 * '<S57>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/DataTypeConversionC'
 * '<S58>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/DataTypeConversionD'
 * '<S59>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/DataTypeConversionG'
 * '<S60>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/DataTypeConversionH'
 * '<S61>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/DataTypeConversionN'
 * '<S62>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/DataTypeConversionP'
 * '<S63>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/DataTypeConversionP0'
 * '<S64>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/DataTypeConversionQ'
 * '<S65>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/DataTypeConversionR'
 * '<S66>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/DataTypeConversionReset'
 * '<S67>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/DataTypeConversionX'
 * '<S68>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/DataTypeConversionX0'
 * '<S69>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/DataTypeConversionu'
 * '<S70>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/MemoryP'
 * '<S71>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/Observer'
 * '<S72>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/ReducedQRN'
 * '<S73>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/Reset'
 * '<S74>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/Reshapeyhat'
 * '<S75>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/ScalarExpansionP0'
 * '<S76>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/ScalarExpansionQ'
 * '<S77>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/ScalarExpansionR'
 * '<S78>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/UseCurrentEstimator'
 * '<S79>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/checkA'
 * '<S80>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/checkB'
 * '<S81>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/checkC'
 * '<S82>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/checkD'
 * '<S83>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/checkEnable'
 * '<S84>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/checkG'
 * '<S85>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/checkH'
 * '<S86>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/checkN'
 * '<S87>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/checkP0'
 * '<S88>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/checkQ'
 * '<S89>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/checkR'
 * '<S90>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/checkReset'
 * '<S91>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/checkX0'
 * '<S92>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/checku'
 * '<S93>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/checky'
 * '<S94>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/CalculatePL/DataTypeConversionL'
 * '<S95>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/CalculatePL/DataTypeConversionM'
 * '<S96>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/CalculatePL/DataTypeConversionP'
 * '<S97>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/CalculatePL/DataTypeConversionZ'
 * '<S98>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/CalculatePL/Ground'
 * '<S99>'  : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/CalculateYhat/Ground'
 * '<S100>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/Observer/MeasurementUpdate'
 * '<S101>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/ReducedQRN/Ground'
 * '<S102>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Pitch_Kalman/Kalman Filter/UseCurrentEstimator/Enabled Subsystem'
 * '<S103>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter'
 * '<S104>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/CalculatePL'
 * '<S105>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/CalculateYhat'
 * '<S106>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/CovarianceOutputConfigurator'
 * '<S107>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/DataTypeConversionA'
 * '<S108>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/DataTypeConversionB'
 * '<S109>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/DataTypeConversionC'
 * '<S110>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/DataTypeConversionD'
 * '<S111>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/DataTypeConversionG'
 * '<S112>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/DataTypeConversionH'
 * '<S113>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/DataTypeConversionN'
 * '<S114>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/DataTypeConversionP'
 * '<S115>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/DataTypeConversionP0'
 * '<S116>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/DataTypeConversionQ'
 * '<S117>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/DataTypeConversionR'
 * '<S118>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/DataTypeConversionReset'
 * '<S119>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/DataTypeConversionX'
 * '<S120>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/DataTypeConversionX0'
 * '<S121>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/DataTypeConversionu'
 * '<S122>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/MemoryP'
 * '<S123>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/Observer'
 * '<S124>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/ReducedQRN'
 * '<S125>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/Reset'
 * '<S126>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/Reshapeyhat'
 * '<S127>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/ScalarExpansionP0'
 * '<S128>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/ScalarExpansionQ'
 * '<S129>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/ScalarExpansionR'
 * '<S130>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/UseCurrentEstimator'
 * '<S131>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/checkA'
 * '<S132>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/checkB'
 * '<S133>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/checkC'
 * '<S134>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/checkD'
 * '<S135>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/checkEnable'
 * '<S136>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/checkG'
 * '<S137>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/checkH'
 * '<S138>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/checkN'
 * '<S139>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/checkP0'
 * '<S140>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/checkQ'
 * '<S141>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/checkR'
 * '<S142>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/checkReset'
 * '<S143>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/checkX0'
 * '<S144>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/checku'
 * '<S145>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/checky'
 * '<S146>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/CalculatePL/DataTypeConversionL'
 * '<S147>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/CalculatePL/DataTypeConversionM'
 * '<S148>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/CalculatePL/DataTypeConversionP'
 * '<S149>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/CalculatePL/DataTypeConversionZ'
 * '<S150>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/CalculatePL/Ground'
 * '<S151>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/CalculateYhat/Ground'
 * '<S152>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/Observer/MeasurementUpdate'
 * '<S153>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/ReducedQRN/Ground'
 * '<S154>' : 'flightControlSystem/Flight Control System/State Estimator/Attitude Estimator/Roll_Kalman/Kalman Filter/UseCurrentEstimator/Enabled Subsystem'
 * '<S155>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/CalculatePL'
 * '<S156>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/CalculateYhat'
 * '<S157>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/CovarianceOutputConfigurator'
 * '<S158>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionA'
 * '<S159>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionB'
 * '<S160>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionC'
 * '<S161>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionD'
 * '<S162>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionEnable'
 * '<S163>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionG'
 * '<S164>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionH'
 * '<S165>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionN'
 * '<S166>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionP'
 * '<S167>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionP0'
 * '<S168>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionQ'
 * '<S169>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionR'
 * '<S170>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionReset'
 * '<S171>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionX'
 * '<S172>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionX0'
 * '<S173>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/DataTypeConversionu'
 * '<S174>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/MemoryP'
 * '<S175>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/Observer'
 * '<S176>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/ReducedQRN'
 * '<S177>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/Reset'
 * '<S178>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/Reshapeyhat'
 * '<S179>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/ScalarExpansionP0'
 * '<S180>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/ScalarExpansionQ'
 * '<S181>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/ScalarExpansionR'
 * '<S182>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/UseCurrentEstimator'
 * '<S183>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/checkA'
 * '<S184>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/checkB'
 * '<S185>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/checkC'
 * '<S186>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/checkD'
 * '<S187>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/checkEnable'
 * '<S188>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/checkG'
 * '<S189>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/checkH'
 * '<S190>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/checkN'
 * '<S191>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/checkP0'
 * '<S192>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/checkQ'
 * '<S193>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/checkR'
 * '<S194>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/checkReset'
 * '<S195>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/checkX0'
 * '<S196>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/checku'
 * '<S197>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/checky'
 * '<S198>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/CalculatePL/DataTypeConversionL'
 * '<S199>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/CalculatePL/DataTypeConversionM'
 * '<S200>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/CalculatePL/DataTypeConversionP'
 * '<S201>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/CalculatePL/DataTypeConversionZ'
 * '<S202>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/CalculatePL/Ground'
 * '<S203>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/CalculateYhat/Ground'
 * '<S204>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/Observer/MeasurementUpdate'
 * '<S205>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/ReducedQRN/Ground'
 * '<S206>' : 'flightControlSystem/Flight Control System/State Estimator/Kalman Filter1/UseCurrentEstimator/Enabled Subsystem'
 * '<S207>' : 'flightControlSystem/Flight Control System/State Estimator/Mahony Filter/MATLAB Function'
 * '<S208>' : 'flightControlSystem/Flight Control System/State Estimator/Mahony Filter/MATLAB Function1'
 * '<S209>' : 'flightControlSystem/Flight Control System/State Estimator/Mahony Filter/MATLAB Function2'
 * '<S210>' : 'flightControlSystem/Flight Control System/State Estimator/Mahony Filter/MATLAB Function3'
 * '<S211>' : 'flightControlSystem/Flight Control System/State Estimator/Mahony Filter/MATLAB Function4'
 * '<S212>' : 'flightControlSystem/Flight Control System/State Estimator/SensorPreprocessing/Temperature Compensation'
 * '<S213>' : 'flightControlSystem/Flight Control System/State Estimator/SensorPreprocessing/sensordata_group'
 * '<S214>' : 'flightControlSystem/Flight Control System/State Estimator/SensorPreprocessing/Temperature Compensation/Compare To Constant'
 * '<S215>' : 'flightControlSystem/Flight Control System/State Estimator/SensorPreprocessing/Temperature Compensation/Counter Free-Running'
 * '<S216>' : 'flightControlSystem/Flight Control System/State Estimator/SensorPreprocessing/Temperature Compensation/Triggered Subsystem'
 * '<S217>' : 'flightControlSystem/Flight Control System/State Estimator/SensorPreprocessing/Temperature Compensation/Counter Free-Running/Increment Real World'
 * '<S218>' : 'flightControlSystem/Flight Control System/State Estimator/SensorPreprocessing/Temperature Compensation/Counter Free-Running/Wrap To Zero'
 */
#endif                                 /* RTW_HEADER_flightControlSystem_h_ */
